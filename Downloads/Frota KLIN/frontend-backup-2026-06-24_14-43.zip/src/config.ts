export const RENDER_API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001/api';
