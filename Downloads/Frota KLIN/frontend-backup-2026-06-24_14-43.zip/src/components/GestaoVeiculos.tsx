import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import type { Veiculo } from '../types';
import { Search, Truck } from 'lucide-react';

// --- HOOKS ATÔMICOS ---
import { useVeiculos, useDeleteVeiculo } from '../hooks/useVeiculos';

// --- DESIGN SYSTEM KLIN ---
import { PageHeader } from './ui/PageHeader';
import { Input } from './ui/Input';
import { DataTable } from './ui/DataTable';
import { Switch } from './ui/Switch';
import { Badge } from './ui/Badge';
import { DropdownAcoes } from './ui/DropdownAcoes';
import { Modal } from './ui/Modal';
import { Skeleton } from './ui/Skeleton';
import { SkeletonTable } from './skeletons/SkeletonTable';
import { ConfirmModal } from './ui/ConfirmModal';
import { EmptyState } from './ui/EmptyState';
import { useFiltragemVeiculos } from '../hooks/useFiltragemVeiculos';
import React, { Suspense } from 'react';
import { PullToRefresh } from './ui/PullToRefresh';
import { SmartFAB } from './ui/SmartFAB';

// --- FORMS (LAZY LOADED) ---
const FormCadastrarVeiculo = React.lazy(() => import('./forms/FormCadastrarVeiculo').then(module => ({ default: module.FormCadastrarVeiculo })));
const FormEditarVeiculo = React.lazy(() => import('./forms/FormEditarVeiculo').then(module => ({ default: module.FormEditarVeiculo })));

export function GestaoVeiculos() {
  const navigate = useNavigate();

  // Estados de Controle
  const [isCadastroOpen, setIsCadastroOpen] = useState(false);
  const [veiculoParaEditar, setVeiculoParaEditar] = useState<Veiculo | null>(null);
  const [veiculoParaExcluir, setVeiculoParaExcluir] = useState<string | null>(null);

  // 📡 BUSCA INDEPENDENTE COM CACHE
  const { data: veiculos = [], isLoading, refetch } = useVeiculos();

  // --- CONTROLE DE SWITCH DE ATIVOS ---
  const [apenasAtivos, setApenasAtivos] = useState(false);

  // --- FILTRAGEM (HOOK REUTILIZÁVEL) ---
  const { busca, setBusca, veiculosFiltrados } = useFiltragemVeiculos(veiculos as Veiculo[]);

  // Aplica o filtro extra localmente
  const veiculosFinais = apenasAtivos
    ? veiculosFiltrados.filter(v => v.status === 'ATIVO')
    : veiculosFiltrados;

  // --- ACTIONS ---
  const { mutateAsync: deleteVeiculo } = useDeleteVeiculo();

  const handleExecuteDelete = async () => {
    if (!veiculoParaExcluir) return;

    try {
      await deleteVeiculo(veiculoParaExcluir);
    } catch (error) {
      if (import.meta.env.DEV) console.error('[DELETE_VEICULO_ERROR]', error);
    } finally {
      setVeiculoParaExcluir(null);
    }
  };

  // Helper para Badges de Status Premium
  const getStatusBadge = (status: string) => {
    const map: Record<string, "success" | "warning" | "neutral" | "danger"> = {
      'ATIVO': 'success',
      'EM_MANUTENCAO': 'warning',
      'INATIVO': 'neutral',
      'QUEBRADO': 'danger'
    };
    const variant = map[status] || 'neutral';
    return <Badge variant={variant} className="shadow-sm">{status.replace(/_/g, ' ')}</Badge>;
  };

  return (
    <PullToRefresh onRefresh={async () => { await refetch(); }}>
      <div className="space-y-6 sm:space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-10">

        {/* 1. CABEÇALHO PADRÃO PREMIUM */}
      <PageHeader
        title="Diretório de Frota"
        subtitle="Controle de Equipamentos, status operacionais e prontuários."
        actionLabel="Novo Veículo"
        onAction={() => setIsCadastroOpen(true)}
      />

      {/* FILTROS MOVIDOS PARA BAIXO DO HEADER */}
      <div className="flex flex-col sm:flex-row gap-3 w-full max-w-full overflow-hidden bg-surface p-2 sm:p-3 rounded-2xl border border-border/60 shadow-sm items-center sm:justify-between">
        <div className="flex items-center gap-3 px-4 h-11 bg-surface-hover/50 rounded-xl border border-border/60 shrink-0 w-full sm:w-auto">
          <Switch
            checked={apenasAtivos}
            onCheckedChange={setApenasAtivos}
          />
          <span className="text-xs font-bold text-text-muted select-none cursor-pointer" onClick={() => setApenasAtivos(!apenasAtivos)}>Apenas Ativos</span>
        </div>
        <div className="w-full sm:w-72">
          <Input
            placeholder="Procurar por placa ou modelo..."
            value={busca}
            onChange={e => setBusca(e.target.value)}
            icon={<Search className="w-4 h-4 text-text-muted" />}
            className="bg-surface-hover/50 border-none focus:ring-1 focus:ring-primary/30 font-medium h-11"
            containerClassName="!mb-0"
          />
        </div>
      </div>

      {/* 2. LISTAGEM & EMPTY STATE */}
      {isLoading ? (
        <div className="bg-surface rounded-3xl shadow-sm border border-border/60 p-6">
          <SkeletonTable />
        </div>
      ) : veiculosFinais.length === 0 ? (
        <EmptyState
          icon={Truck}
          title={busca || apenasAtivos ? "Nenhum veículo encontrado" : "Frota Vazia"}
          description={busca || apenasAtivos ? "Verifique os filtros aplicados." : "Registre o primeiro Equipamento para iniciar o controle."}
        />
      ) : (
        <div className="bg-surface rounded-3xl shadow-sm border border-border/60 overflow-hidden">
          <DataTable
            data={veiculosFinais}
            emptyMessage=""
            desktopGridCols="grid-cols-[2fr_2fr_1.5fr_1.5fr_1fr]"

            // CONFIGURAÇÃO DE COLUNAS DESKTOP
            columns={[
              {
                header: 'Veículo / Placa',
                headerClassName: 'pl-8 text-left',
                className: 'pl-8 py-5 hover-lift',
                cell: (v: Veiculo) => (
                  <button
                    onClick={() => navigate(`/admin/veiculos/${v.id}`)}
                    className="flex items-center gap-3 group focus-visible:ring-2 focus-visible:ring-primary rounded-lg"
                    title="Acessar ao Prontuário"
                    aria-label={`Acessar prontuário do veículo placa ${v.placa}`}
                  >
                    <div className="p-2.5 bg-surface-hover rounded-xl border border-border/60 text-text-muted group-hover:bg-primary/5 group-hover:text-primary transition-all shadow-sm">
                      <Truck className="w-4 h-4" />
                    </div>
                    <span className="text-data text-[13px] bg-surface-hover/80 px-2.5 py-1 rounded-md border border-border/80 shadow-[inset_0_1px_1px_rgba(255,255,255,0.8),0_1px_2px_rgba(0,0,0,0.05)] text-text-main group-hover:border-primary/40 transition-colors">
                      {v.placa}
                    </span>
                  </button>
                )
              },
              {
                header: 'Especificações',
                headerClassName: 'text-center',
                className: 'py-5 text-center',
                cell: (v: Veiculo) => (
                  <div className="w-full flex flex-col gap-1 items-center justify-center text-center">
                    <span className="text-sm font-bold text-text-main leading-tight block w-full truncate" title={v.modelo}>{v.modelo}</span>
                    <span className="text-xs text-text-secondary font-bold uppercase tracking-wider block w-full">{v.ano} • <span className="text-data">{v.id.substring(0, 6).toUpperCase()}</span></span>
                  </div>
                )
              },
              {
                header: 'Combustível',
                headerClassName: 'text-center',
                className: 'py-5 text-center',
                cell: (v: Veiculo) => (
                  <div className="w-full flex justify-center">
                    <span className="text-xs font-bold text-text-muted uppercase tracking-widest bg-surface-hover px-2 py-1 rounded-md border border-border/50 inline-block">
                      {v.tipoCombustivel.replace(/_/g, ' ')}
                    </span>
                  </div>
                )
              },
              {
                header: 'Status Operacional',
                headerClassName: 'text-center',
                className: 'py-5 text-center',
                cell: (v: Veiculo) => (
                  <div className="w-full flex justify-center">
                    <div className="glass inline-block rounded-md overflow-hidden">
                      {getStatusBadge(v.status)}
                    </div>
                  </div>
                )
              },
              {
                header: 'Ações',
                headerClassName: 'text-right pr-8',
                className: 'text-right pr-8 py-5',
                cell: (v: Veiculo) => (
                  <DropdownAcoes
                    onVerDetalhes={() => navigate(`/admin/veiculos/${v.id}`)}
                    onEditar={() => setVeiculoParaEditar(v)}
                    onExcluir={() => setVeiculoParaExcluir(v.id)}
                    excluirLabel="Inativar"
                  />
                )
              }
            ]}

            // CARD MOBILE
            renderMobile={(v) => (
              <div 
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    navigate(`/admin/veiculos/${v.id}`);
                  }
                }}
                className="text-left w-full block p-5 border-b border-border/50 hover:bg-surface-hover/30 transition-colors cursor-pointer hover-lift rounded-2xl m-2 glass" 
                onClick={() => navigate(`/admin/veiculos/${v.id}`)}
              >
                <div className="flex justify-between items-start w-full">
                  <div className="space-y-4 w-full">
                    <div className="flex items-center gap-3">
                      {/* Visual de placa cinza mobile */}
                      <span className="text-data text-[13px] bg-surface hover:bg-surface-hover px-2.5 py-1 rounded-md border border-border/80 shadow-[inset_0_1px_1px_rgba(255,255,255,0.8),0_1px_2px_rgba(0,0,0,0.05)] text-text-main transition-colors uppercase">
                        {v.placa}
                      </span>
                      <div className="glass inline-block rounded-md overflow-hidden">
                        {getStatusBadge(v.status)}
                      </div>
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-text-main leading-tight">{v.modelo}</h3>
                      <p className="text-xs font-bold uppercase tracking-wider text-text-secondary mt-1">{v.tipoVeiculo} • {v.ano}</p>
                    </div>
                  </div>

                  <div onClick={e => e.stopPropagation()} className="shrink-0 ml-2">
                    <DropdownAcoes
                      onVerDetalhes={() => navigate(`/admin/veiculos/${v.id}`)}
                      onEditar={() => setVeiculoParaEditar(v)}
                      onExcluir={() => setVeiculoParaExcluir(v.id)}
                      excluirLabel="Inativar"
                    />
                  </div>
                </div>
              </div>
            )}
          />
        </div>
      )}

      {/* --- MODAIS DE APOIO --- */}
      <Modal
        isOpen={isCadastroOpen}
        onClose={() => setIsCadastroOpen(false)}
        title="Registrar Novo Equipamento"
        className="max-w-2xl"
      >
        <div className="p-2">
          <Suspense fallback={<div className="p-4 space-y-4"><Skeleton variant="title" /><Skeleton variant="tableRow" className="h-24" /><Skeleton variant="tableRow" className="h-24" /></div>}>
            <FormCadastrarVeiculo
              onSuccess={() => { setIsCadastroOpen(false); refetch(); }}
              onCancelar={() => setIsCadastroOpen(false)}
            />
          </Suspense>
        </div>
      </Modal>

      <Modal
        isOpen={!!veiculoParaEditar}
        onClose={() => setVeiculoParaEditar(null)}
        title="Atualizar Equipamento"
        className="max-w-2xl"
      >
        {veiculoParaEditar && (
          <div className="p-2">
            <Suspense fallback={<div className="p-4 space-y-4"><Skeleton variant="title" /><Skeleton variant="tableRow" className="h-24" /><Skeleton variant="tableRow" className="h-24" /></div>}>
              <FormEditarVeiculo
                veiculoId={veiculoParaEditar.id}
                onSuccess={() => { setVeiculoParaEditar(null); refetch(); }}
                onCancelar={() => setVeiculoParaEditar(null)}
              />
            </Suspense>
          </div>
        )}
      </Modal>

      <ConfirmModal
        isOpen={!!veiculoParaExcluir}
        onCancel={() => setVeiculoParaExcluir(null)}
        onConfirm={handleExecuteDelete}
        title="Inativar ou Remover Equipamento"
        description={
          <div className="space-y-4">
            <p className="text-text-secondary text-sm">Tem certeza que deseja remover este veículo do diretório da frota? Se ele possuir histórico de rodagem, será apenas inativado para proteger o banco de dados e as métricas do BI.</p>
          </div>
        }
        confirmLabel="Sim, Confirmar Ação"
        variant="danger"
      />

      <SmartFAB 
        onClick={() => setIsCadastroOpen(true)} 
        label="Novo Veículo" 
      />

    </div>
    </PullToRefresh>
  );
}
