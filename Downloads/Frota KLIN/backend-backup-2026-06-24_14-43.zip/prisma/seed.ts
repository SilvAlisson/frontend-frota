// prisma/seed.ts
// 🔐 007 Fix: Guard de produção + Clean Code + batch transaction
import { PrismaClient, User, Jornada } from '@prisma/client';

const prisma = new PrismaClient();

// ----------------------------------------------------------------
// Guard — impede execução acidental em produção
// ----------------------------------------------------------------
function assertNotProduction(): void {
  if (process.env.NODE_ENV === 'production') {
    console.error('❌ SEED BLOQUEADO: não permitido em ambiente de produção.');
    process.exit(1);
  }
}

// ----------------------------------------------------------------
// Funções de responsabilidade única
// ----------------------------------------------------------------
async function findGhostUser(): Promise<User | null> {
  return prisma.user.findUnique({ where: { email: 'sistema@frota.ghost' } });
}

async function anonymizeGhostUser(bot: User): Promise<void> {
  await prisma.user.update({
    where: { id: bot.id },
    data: {
      nome: 'Auditoria Fixa (Legado)',
      role: 'ADMIN',
      fotoUrl: 'https://cdn-icons-png.flaticon.com/512/2040/2040504.png',
    },
  });
  console.log('✅ Conta bot anonimizada corporativamente.');
}

function buildSanitizedObservation(jornada: Jornada, botId?: string): string {
  if (botId && jornada.operadorId === botId) {
    const kmRodado = (jornada.kmFim || 0) - jornada.kmInicio;
    return `⚠️ [AUDITORIA] Lacuna legada de ${kmRodado}km preenchida no sistema antigo e validada.`;
  }
  return (jornada.observacoes || '')
    .replace(/🤖/g, '⚠️')
    .replace(/👻/g, '')
    .replace(/Fantasma/gi, 'Sistema')
    .replace(/AUTO-RECOVERY/gi, 'FECHAMENTO ADMINISTRATIVO')
    .replace(/ET de/gi, 'Registro de')
    .replace(/Fada do/gi, 'Registro do')
    .replace(/Zumbi/gi, 'Operador')
    .trim();
}

async function findGhostJourneys(): Promise<Jornada[]> {
  return prisma.jornada.findMany({
    where: {
      OR: [
        { observacoes: { contains: '🤖' } },
        { observacoes: { contains: '👻' } },
        { observacoes: { contains: 'Fantasma' } },
        { observacoes: { contains: 'AUTO-RECOVERY' } },
        { observacoes: { contains: 'ET de' } },
        { observacoes: { contains: 'Fada do' } },
        { observacoes: { contains: 'Zumbi' } },
      ],
    },
  });
}

async function sanitizeJourneys(jornadas: Jornada[], botId?: string): Promise<number> {
  if (jornadas.length === 0) return 0;

  // 🔥 Performance Fix: batch transaction — 1 round-trip ao invés de N queries
  await prisma.$transaction(
    jornadas.map((j) =>
      prisma.jornada.update({
        where: { id: j.id },
        data: { observacoes: buildSanitizedObservation(j, botId) },
      })
    )
  );

  return jornadas.length;
}

// ----------------------------------------------------------------
// Orquestrador principal
// ----------------------------------------------------------------
async function main() {
  assertNotProduction();

  console.log('🧹 Iniciando conversão de Fantasmas para Histórico de Auditoria...');

  const bot = await findGhostUser();
  if (bot) {
    await anonymizeGhostUser(bot);
  } else {
    console.log('⚠️ Conta sistema@frota.ghost não encontrada — nada a anonimizar.');
  }

  const jornadasGhosts = await findGhostJourneys();
  console.log(`🔍 ${jornadasGhosts.length} registos encontrados para higienizar...`);

  const total = await sanitizeJourneys(jornadasGhosts, bot?.id);
  console.log(`✨ Sucesso! ${total} registos sanitizados.`);
  console.log('🏁 Limpeza concluída!');
}

main()
  .catch((e: Error) => {
    // 🔐 007 Fix: não expõe stack trace completo — apenas a mensagem
    console.error('❌ Erro durante a limpeza:', e.message);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());