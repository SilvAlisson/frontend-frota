-- =============================================================
-- Migration: fix_drift_indexes_passkey_unique
-- Data: 17/06/2026
--
-- SEGURANÇA: Esta migration é 100% aditiva e idempotente.
-- - Usa IF NOT EXISTS em todos os CREATE INDEX
-- - Usa ADD COLUMN IF NOT EXISTS em todos os ALTER TABLE
-- - Usa blocos DO $$ para verificar constraints antes de criar
-- - NENHUM DROP, NENHUM UPDATE, NENHUM DELETE
-- - Pode ser rodada múltiplas vezes sem efeito colateral
-- =============================================================

-- =============================================================
-- 1. Sincronizar colunas do Treinamento
--    (adicionadas manualmente via update.sql — tornando oficial)
-- =============================================================
ALTER TABLE "Treinamento" ADD COLUMN IF NOT EXISTS "diasAntecedenciaAlerta" INTEGER NOT NULL DEFAULT 30;
ALTER TABLE "Treinamento" ADD COLUMN IF NOT EXISTS "comprovanteUrl" TEXT;

-- FK do Treinamento com CASCADE (idempotente via pg_constraint)
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'Treinamento_userId_fkey'
  ) THEN
    ALTER TABLE "Treinamento"
      ADD CONSTRAINT "Treinamento_userId_fkey"
      FOREIGN KEY ("userId") REFERENCES "User"("id")
      ON DELETE CASCADE ON UPDATE CASCADE;
  END IF;
END $$;

-- =============================================================
-- 2. Índices do Treinamento
--    (estavam comentados na migration 20260419090619)
-- =============================================================
CREATE INDEX IF NOT EXISTS "Treinamento_dataVencimento_idx"
  ON "Treinamento"("dataVencimento");

CREATE INDEX IF NOT EXISTS "Treinamento_userId_idx"
  ON "Treinamento"("userId");

-- =============================================================
-- 3. Índice e FK do SystemLog
--    (estavam comentados na migration 20260419090619)
-- =============================================================
CREATE INDEX IF NOT EXISTS "SystemLog_userId_idx"
  ON "SystemLog"("userId");

DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'SystemLog_userId_fkey'
  ) THEN
    ALTER TABLE "SystemLog"
      ADD CONSTRAINT "SystemLog_userId_fkey"
      FOREIGN KEY ("userId") REFERENCES "User"("id")
      ON DELETE SET NULL ON UPDATE CASCADE;
  END IF;
END $$;

-- =============================================================
-- 4. Passkey.credentialID — adiciona constraint UNIQUE
--    O WebAuthn garante por design que credentialID é único,
--    mas sem a constraint o banco não enforça isso.
--    CREATE UNIQUE INDEX IF NOT EXISTS = seguro se já não existir.
-- =============================================================
CREATE UNIQUE INDEX IF NOT EXISTS "Passkey_credentialID_key"
  ON "Passkey"("credentialID");
