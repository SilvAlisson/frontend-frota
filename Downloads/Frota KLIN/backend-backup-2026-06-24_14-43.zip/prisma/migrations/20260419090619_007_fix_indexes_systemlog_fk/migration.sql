-- Descrição: Adiciona índices faltantes em DocumentoLegal, HistoricoKm,
--             PlanoManutencao e Treinamento. Adiciona FK formal de SystemLog → User.

-- ────────────────────────────────────────────────────────────
-- DocumentoLegal: Painel de vencimentos e filtros inteligentes
-- ────────────────────────────────────────────────────────────

-- CreateIndex
CREATE INDEX "DocumentoLegal_dataValidade_idx" ON "DocumentoLegal"("dataValidade");

-- CreateIndex
CREATE INDEX "DocumentoLegal_veiculoId_idx" ON "DocumentoLegal"("veiculoId");

-- CreateIndex
CREATE INDEX "DocumentoLegal_categoria_idx" ON "DocumentoLegal"("categoria");

-- CreateIndex
--CREATE INDEX "DocumentoLegal_status_idx" ON "DocumentoLegal"("status");

-- ────────────────────────────────────────────────────────────
-- HistoricoKm: Gráfico de KM por veículo no tempo
-- ────────────────────────────────────────────────────────────

-- CreateIndex
CREATE INDEX "HistoricoKm_veiculoId_dataLeitura_idx" ON "HistoricoKm"("veiculoId", "dataLeitura");

-- ────────────────────────────────────────────────────────────
-- PlanoManutencao: Alertas de manutenção preventiva
-- ────────────────────────────────────────────────────────────

-- CreateIndex
CREATE INDEX "PlanoManutencao_veiculoId_idx" ON "PlanoManutencao"("veiculoId");

-- CreateIndex
CREATE INDEX "PlanoManutencao_kmProximaManutencao_idx" ON "PlanoManutencao"("kmProximaManutencao");

-- CreateIndex
CREATE INDEX "PlanoManutencao_dataProximaManutencao_idx" ON "PlanoManutencao"("dataProximaManutencao");

-- ────────────────────────────────────────────────────────────
-- SystemLog: Rastreabilidade por usuário (FK formal)
-- ────────────────────────────────────────────────────────────

-- CreateIndex
--CREATE INDEX "SystemLog_userId_idx" ON "SystemLog"("userId");

-- AddForeignKey (SetNull ao deletar usuário — log persiste sem referência)
--ALTER TABLE "SystemLog" ADD CONSTRAINT "SystemLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- ────────────────────────────────────────────────────────────
-- Treinamento: Alertas de vencimento de CNH e treinamentos
-- ────────────────────────────────────────────────────────────

-- CreateIndex
--CREATE INDEX "Treinamento_dataVencimento_idx" ON "Treinamento"("dataVencimento");

-- CreateIndex
--CREATE INDEX "Treinamento_userId_idx" ON "Treinamento"("userId");
