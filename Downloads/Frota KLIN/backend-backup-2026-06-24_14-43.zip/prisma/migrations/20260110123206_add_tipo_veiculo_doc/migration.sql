-- AlterTable
ALTER TABLE "DocumentoLegal" ADD COLUMN     "veiculoId" TEXT;

-- DropEnum
DROP TYPE "TipoVeiculo";

-- AddForeignKey
ALTER TABLE "DocumentoLegal" ADD CONSTRAINT "DocumentoLegal_veiculoId_fkey" FOREIGN KEY ("veiculoId") REFERENCES "Veiculo"("id") ON DELETE SET NULL ON UPDATE CASCADE;
