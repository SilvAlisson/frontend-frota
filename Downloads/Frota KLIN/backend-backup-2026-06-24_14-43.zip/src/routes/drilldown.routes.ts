import { Router } from 'express';
import { DrillDownController } from '../controllers/DrillDownController';
import { authenticateToken } from '../middleware/auth';

const router = Router();
const drillDownController = new DrillDownController();

router.use(authenticateToken);

// /api/drilldown/macro
router.get('/macro', drillDownController.getMacroGastos);

// /api/drilldown/veiculo
router.get('/veiculo', drillDownController.getVeiculoBreakdown);

// /api/drilldown/temporal
router.get('/temporal', drillDownController.getEvolucaoTemporal);

// /api/drilldown/fornecedores
router.get('/fornecedores', drillDownController.getFornecedoresBreakdown);
router.get('/fornecedores/tickets', drillDownController.getFornecedorTickets);

// Rotas de Quilometragem Total (KM_TOTAL)
router.get('/km/macro', drillDownController.getKmMacro);
router.get('/km/temporal', drillDownController.getKmTemporal);
router.get('/km/operadores', drillDownController.getKmOperadores);

// Rotas de Eficiência de Consumo (EFICIENCIA)
router.get('/eficiencia/macro', drillDownController.getEficienciaMacro);
router.get('/eficiencia/temporal', drillDownController.getEficienciaTemporal);

// Rotas de Custo Médio por KM (CUSTO_KM)
router.get('/custokm/macro', drillDownController.getCustoKmMacro);
router.get('/custokm/temporal', drillDownController.getCustoKmTemporal);
router.get('/custokm/categorias', drillDownController.getCustoKmCategorias);

export default router;
