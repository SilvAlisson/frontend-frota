import { Router } from 'express';
import { VeiculoController } from '../controllers/VeiculoController';
import { authenticateToken, authorize } from '../middleware/auth';
import { validate } from '../middleware/validate';
import { veiculoSchema } from '../schemas/veiculo.schemas';

const router = Router();
const veiculoController = new VeiculoController();

// Middleware de autenticação aplicado a todas as rotas
router.use(authenticateToken);

// --- Rotas de Escrita (Restritas) ---
router.post('/',
    authorize(['ADMIN', 'COORDENADOR']),
    validate(veiculoSchema),
    veiculoController.create
);

// --- Rota EXPRESSA para Operadores ---
router.get('/operacao',
    authorize(['ADMIN', 'COORDENADOR', 'ENCARREGADO', 'OPERADOR']),
    veiculoController.listarParaOperacao
);

// --- Rota de Inteligência de Ociosidade (CÉREBRO) ---
router.get('/alertas/ociosos',
    authorize(['ADMIN', 'COORDENADOR', 'ENCARREGADO']),
    veiculoController.listarOciosos
);

// --- Rotas de Leitura Geral ---
router.get('/',
    authorize(['ADMIN', 'COORDENADOR', 'ENCARREGADO', 'RH', 'OPERADOR']),
    veiculoController.list
);

router.get('/:id',
    authorize(['ADMIN', 'COORDENADOR', 'ENCARREGADO', 'RH']),
    veiculoController.getById
);

// Rota de Prontuário (Detalhes Avançados)
router.get('/:id/detalhes',
    authorize(['ADMIN', 'COORDENADOR', 'ENCARREGADO']),
    veiculoController.getDetalhes
);

// --- Rotas de Modificação ---
router.put('/:id',
    authorize(['ADMIN', 'COORDENADOR']),
    validate(veiculoSchema),
    veiculoController.update
);

// NANO-ENDPOINT Anti-Ociosidade
router.put('/:id/status',
    authorize(['ADMIN', 'COORDENADOR', 'ENCARREGADO']),
    veiculoController.updateStatus
);


router.delete('/:id',
    authorize(['ADMIN']),
    veiculoController.delete
);

export default router;