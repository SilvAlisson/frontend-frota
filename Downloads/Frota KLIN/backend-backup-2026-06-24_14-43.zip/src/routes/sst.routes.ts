import { Router } from 'express';
import { SSTController } from '../controllers/SSTController';
import { authenticateToken, authorize } from '../middleware/auth';

const sstRoutes = Router();
const controller = new SSTController();

// Todas as rotas exigem autenticação
sstRoutes.use(authenticateToken);

// Leitura: ADMIN, COORDENADOR e RH
sstRoutes.get('/',    authorize(['ADMIN', 'COORDENADOR', 'RH']), controller.index);
sstRoutes.get('/:id', authorize(['ADMIN', 'COORDENADOR', 'RH']), controller.show);

// Escrita: ADMIN, COORDENADOR e RH
sstRoutes.post('/',    authorize(['ADMIN', 'COORDENADOR', 'RH']), controller.create);
sstRoutes.put('/:id',  authorize(['ADMIN', 'COORDENADOR', 'RH']), controller.update);
sstRoutes.delete('/:id', authorize(['ADMIN', 'COORDENADOR', 'RH']), controller.delete);

export default sstRoutes;
