import { Router } from 'express';
import { ProdutoController } from '../controllers/ProdutoController';
import { authenticateToken, authorize } from '../middleware/auth';
import { validate } from '../middleware/validate';
import { produtoSchema } from '../schemas/produto.schemas';

const router = Router();
const produtoController = new ProdutoController();

router.use(authenticateToken);

// --- Rotas de Escrita (Restritas) ---
router.post('/',
    authorize(['ADMIN', 'COORDENADOR']),
    validate(produtoSchema),
    produtoController.create
);

// --- Rota EXPRESSA para Operadores ---
router.get('/operacao',
    authorize(['ADMIN', 'COORDENADOR', 'ENCARREGADO', 'OPERADOR']),
    produtoController.listarParaOperacao
);

// --- Rotas de Leitura Geral ---
router.get('/',
    authorize(['ADMIN', 'COORDENADOR', 'ENCARREGADO', 'OPERADOR']),
    produtoController.list
);

router.get('/:id',
    authorize(['ADMIN', 'COORDENADOR', 'ENCARREGADO']),
    produtoController.getById
);

// --- Rotas de Modificação ---
router.put('/:id',
    authorize(['ADMIN', 'COORDENADOR']),
    validate(produtoSchema),
    produtoController.update
);

router.delete('/:id',
    authorize(['ADMIN', 'COORDENADOR']),
    produtoController.delete
);

export default router;