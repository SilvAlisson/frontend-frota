import { Router } from 'express';
import { RelatorioController } from '../controllers/RelatorioController';
import { authenticateToken } from '../middleware/auth';
import { validate } from '../middleware/validate';
import { relatorioQuerySchema } from '../schemas/relatorio.schemas';

const router = Router();
const relatorioController = new RelatorioController();

router.use(authenticateToken);

// Adicionado middleware 'validate' para garantir tipos de Query Params (ano, mes)
router.get('/sumario', validate(relatorioQuerySchema), relatorioController.sumario);
router.get('/ranking', validate(relatorioQuerySchema), relatorioController.ranking);

// --- ROTA PARA O RANKING DE EFICIÊNCIA DE VEÍCULOS ---
router.get('/ranking-veiculos', validate(relatorioQuerySchema), relatorioController.rankingVeiculos);

router.get('/evolucao-km', relatorioController.getEvolucaoKm);
router.get('/lavagens', relatorioController.getRelatorioLavagens);
// Alertas não precisa de input complexo, apenas filtro interno
router.get('/alertas', relatorioController.alertas);

// --- ROTAS DO DASHBOARD BI ---
router.get('/evolucao-cpk', relatorioController.getEvolucaoCpk);
router.get('/performance-frota', validate(relatorioQuerySchema), relatorioController.getPerformanceFrota);
router.get('/analytics-raw', validate(relatorioQuerySchema), relatorioController.getAnalyticsRaw);

export default router;