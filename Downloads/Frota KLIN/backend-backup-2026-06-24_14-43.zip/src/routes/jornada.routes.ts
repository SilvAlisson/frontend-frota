import { Router } from 'express';
import { JornadaController } from '../controllers/JornadaController';
import { AuthenticatedRequest, authenticateToken } from '../middleware/auth';
import { validate } from '../middleware/validate';
import { prisma } from '../lib/prisma';
import { JornadaService } from '../services/JornadaService';
import {
    iniciarJornadaSchema,
    finalizarJornadaSchema,
    buscaJornadaSchema,
    updateJornadaSchema
} from '../schemas/jornada.schemas';

const router = Router();
const jornadaController = new JornadaController();

router.use(authenticateToken);

// Iniciar (Valida Body)
router.post('/iniciar', validate(iniciarJornadaSchema), jornadaController.iniciar);

// Finalizar (Valida ID no Params + Body)
router.put('/finalizar/:id', validate(finalizarJornadaSchema), jornadaController.finalizar);

// --- BUSCAS E LISTAGENS (DEVEM VIR ANTES DE /:id) ---

// 1. Histórico Geral (Admin)
router.get('/historico', validate(buscaJornadaSchema), jornadaController.listarHistorico);

// 2. Histórico Individual (Operador) - O botão "Meu Histórico" chama aqui
router.get('/meu-historico', jornadaController.listarMeuHistorico);

// --- ROTAS GLOBAIS / AUDITORIA / CRON (Apenas Admin/Encarregados) ---
router.post('/force-cron', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
        const adminId = req.user?.userId;
        if (req.user?.role !== 'ADMIN') return res.status(403).json({ error: 'Apenas admin pode forçar o cron.' });
        
        // Reseta as tentativas para poder rodar de novo
        await prisma.jornada.updateMany({
            where: { dataFim: null, tentativasAutoFechamento: { gte: 3 } },
            data: { tentativasAutoFechamento: 0 }
        });
        
        await JornadaService.fecharJornadasVencidas();
        
        const comErro = await prisma.jornada.findMany({
            where: { dataFim: null },
            select: { id: true, veiculo: { select: { placa: true } }, erroAutoFechamento: true, tentativasAutoFechamento: true }
        });
        
        res.json({ success: true, pending: comErro });
    } catch (e: unknown) {
        const err = e instanceof Error ? e : new Error(String(e));
        res.status(500).json({ error: err.message });
    }
});

router.get('/ativas', authenticateToken, jornadaController.listarAbertas);
router.get('/minhas-abertas-operador', jornadaController.listarMinhasAbertas);

// 4. Verificações de Sistema
router.post('/verificar-timeouts', jornadaController.verificarTimeouts);

// --- OPERAÇÕES POR ID (GENÉRICAS) ---

// Edição (Admin/Gestor) - O modal de edição chama aqui
router.put('/:id', validate(updateJornadaSchema), jornadaController.update);

// Exclusão (Admin)
router.delete('/:id', jornadaController.delete);

// Buscar uma única jornada (Para preencher o formulário de edição)
// IMPORTANTE: Esta rota deve ser a última das GETs para não capturar "historico" como se fosse um ID
router.get('/:id', jornadaController.getById);

export default router;