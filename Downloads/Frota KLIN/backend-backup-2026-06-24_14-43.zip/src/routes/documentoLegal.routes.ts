import { Router } from 'express';
import { DocumentoLegalController } from '../controllers/DocumentoLegalController';
import { authenticateToken } from '../middleware/auth';

const documentoLegalRoutes = Router();
const controller = new DocumentoLegalController();

// Todas as rotas abaixo exigem login
documentoLegalRoutes.use(authenticateToken);

// 1. Listar Documentos (Todo mundo acessa)
documentoLegalRoutes.get('/', controller.index);

// ✨ 2. Buscar Documento Específico (Para abrir a edição)
documentoLegalRoutes.get('/:id', controller.show);

// 3. Criar Documento (Restrito)
documentoLegalRoutes.post(
    '/',
    controller.create
);

// ✨ 4. Atualizar Documento
documentoLegalRoutes.put(
    '/:id',
    controller.update
);

// ✨ 4.5. Renovar Documento (Versões/Lineage)
documentoLegalRoutes.post(
    '/:id/renovar',
    controller.renovar
);

// 5. Deletar Documento (Restrito)
documentoLegalRoutes.delete(
    '/:id',
    controller.delete
);

export default documentoLegalRoutes;