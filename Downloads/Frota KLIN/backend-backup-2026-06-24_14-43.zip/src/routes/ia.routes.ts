import { Router } from 'express';
import { authenticateToken } from '../middleware/auth';
import { iaController } from '../controllers/IAController';
import rateLimit from 'express-rate-limit';

const router = Router();

// Rate limit rigoroso para relatórios e análises pesadas (Legado/Dashboards)
const relatorioLimiter = rateLimit({
    windowMs: 5 * 60 * 1000, // 5 minutos
    max: 20, // 20 requisições
    message: { error: 'Muitas consultas pesadas em sequência. Aguarde alguns minutos.' },
    standardHeaders: true,
    legacyHeaders: false,
});

// Rate limit mais flexível para o Chat em Streaming (pois a interação é contínua)
const chatLimiter = rateLimit({
    windowMs: 5 * 60 * 1000, // 5 minutos
    max: 40, // 40 mensagens por 5 minutos é um valor confortável para um chat
    message: { error: 'Limite de mensagens atingido para proteger a quota do sistema. Respire um pouco e tente daqui a 5 minutos.' },
    standardHeaders: true,
    legacyHeaders: false,
});

// Todas as rotas de IA exigem autenticação
router.use(authenticateToken);

// ============================================================================
// 🚀 NOVA ROTA DA KIA (STREAMING + FUNCTION CALLING)
// ============================================================================
router.post('/consultar-stream', chatLimiter, iaController.consultarStream);

// ============================================================================
// ⚠️ ROTAS DE RELATÓRIOS E COMPONENTES ESPECÍFICOS
// ============================================================================

// Chat geral legado (mantido para retrocompatibilidade do app mobile/antigo)
router.post('/consulta', relatorioLimiter, iaController.consultaGeral);

// Insights automáticos para o Dashboard de KPIs
router.post('/insights-kpis', relatorioLimiter, iaController.insightsKPIs);

// Diagnóstico preditivo de um veículo específico
router.post('/analise-veiculo', relatorioLimiter, iaController.analiseVeiculo);

// Relatório narrativo de RH
router.post('/relatorio-rh', relatorioLimiter, iaController.relatorioRH);

// Feedback de Qualidade
router.post('/feedback/:mensagemId', iaController.enviarFeedback);

export default router;