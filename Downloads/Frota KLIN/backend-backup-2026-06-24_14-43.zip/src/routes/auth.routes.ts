import { Router } from 'express';
import { AuthController } from '../controllers/AuthController';
import { authenticateToken } from '../middleware/auth';
import { validate } from '../middleware/validate';
import {
    loginWithTokenSchema,
    generateTokenSchema,
} from '../schemas/auth.schemas';
import { prisma } from '../lib/prisma';
import rateLimit from 'express-rate-limit';
import type { AuthenticatedRequest } from '../middleware/auth';

const router = Router();

// =========================================================
// ROTAS CUSTOMIZADAS (QR Code)
// =========================================================
router.post('/login-token', validate(loginWithTokenSchema), AuthController.loginWithToken);
router.post(
    '/user/:id/generate-token',
    authenticateToken,
    validate(generateTokenSchema),
    AuthController.generateToken
);

// (Rotas de passkeys movidas para user.routes.ts para evitar conflito com o regex do Better Auth)

export default router;