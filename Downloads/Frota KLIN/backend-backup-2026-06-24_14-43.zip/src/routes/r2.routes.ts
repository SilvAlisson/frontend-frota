import { Router } from 'express';
import { generatePresignedUploadUrl } from '../lib/s3';
import { authenticateToken } from '../middleware/auth';
import { AuthenticatedRequest } from '../middleware/auth';

const router = Router();

// Rota para gerar URL assinada com suporte a pastas
router.post('/presign', authenticateToken, async (req: AuthenticatedRequest, res) => {
  try {
    const { fileName, contentType, folder = 'geral' } = req.body;

    if (!fileName || !contentType) {
      res.status(400).json({ error: 'fileName e contentType são obrigatórios.' });
      return;
    }

    // Sanitização para garantir que o caminho da pasta seja válido
    const safeFolder = folder.replace(/[^a-zA-Z0-9_-]/g, '').toLowerCase();

    // O nome do arquivo agora inclui o caminho da pasta
    // Ex: "manutencoes/1713708000000-foto.jpg"
    const uniqueFileName = `${safeFolder}/${Date.now()}-${fileName.replace(/[^a-zA-Z0-9.\-_]/g, '')}`;

    const { presignedUrl, publicUrl } = await generatePresignedUploadUrl(uniqueFileName, contentType);

    res.json({ presignedUrl, publicUrl, fileName: uniqueFileName });
  } catch (error) {
    console.error('Erro ao gerar link de upload R2:', error);
    res.status(500).json({ error: 'Falha ao gerar o token de upload para nuvem.' });
  }
});

export default router;