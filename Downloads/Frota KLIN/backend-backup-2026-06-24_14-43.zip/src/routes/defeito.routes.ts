import { Router } from 'express';
import { DefeitoController } from '../controllers/DefeitoController';
import { authenticateToken, authorize } from '../middleware/auth';
import { validate } from '../middleware/validate';
import { registrarDefeitoSchema, resolverDefeitoSchema } from '../schemas/defeito.schemas';

const defeitoRoutes = Router();
const controller = new DefeitoController();

// Todas as rotas de defeito requerem usuário logado
defeitoRoutes.use(authenticateToken);

// Lista defeitos (Operador vê os seus; admin/encarregado vê todos)
defeitoRoutes.get('/', controller.index);

// Contagem rápida para selo/badge do Encarregado (só para encarregado/admin)
defeitoRoutes.get('/count', authorize(['ADMIN', 'ENCARREGADO']), controller.countAtivos);

// Registra um defeito (Operador e Encarregado podem)
defeitoRoutes.post(
  '/', 
  authorize(['ADMIN', 'ENCARREGADO', 'OPERADOR']),
  validate(registrarDefeitoSchema), 
  controller.create
);

// Encarregado analisa
defeitoRoutes.patch(
  '/:id/analisar',
  authorize(['ADMIN', 'ENCARREGADO']),
  controller.setEmAnalise
);

// Encarregado resolve
defeitoRoutes.patch(
  '/:id/resolver',
  authorize(['ADMIN', 'ENCARREGADO']),
  validate(resolverDefeitoSchema),
  controller.resolver
);

export { defeitoRoutes };
