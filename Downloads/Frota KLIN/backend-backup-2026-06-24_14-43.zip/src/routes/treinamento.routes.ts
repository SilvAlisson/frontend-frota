import { Router } from 'express';
import { prisma } from '../lib/prisma';
import { TreinamentoController } from '../controllers/TreinamentoController';
import { authenticateToken } from '../middleware/auth';
import { validate } from '../middleware/validate';
import { createTreinamentoSchema, importTreinamentosSchema } from '../schemas/treinamentos.schemas';

const router = Router();

//  ROTA PÚBLICA: Dossiê Digital (QR Code)
// Fica solta aqui em cima para não exigir Token/Login
router.get('/dossie/:id', async (req, res) => {
    try {
        const { id } = req.params;
        
        const integrante = await prisma.user.findUnique({
            where: { id },
            select: {
                nome: true,
                role: true,
                matricula: true,
                image: true, // O Prisma agora usa 'image' ao invés de 'fotoUrl'
                treinamentos: {
                    select: {
                        id: true,
                        nome: true,
                        dataRealizacao: true,
                        dataVencimento: true,
                        comprovanteUrl: true,
                    },
                    orderBy: {
                        dataVencimento: 'asc' // Mostra os que vencem primeiro no topo
                    }
                }
            }
        });

        if (!integrante) {
            return res.status(404).json({ error: 'Integrante não localizado.' });
        }

        // Devolvemos mapeando o 'image' para 'fotoUrl' para o Frontend ler nativamente
        return res.json({
            ...integrante,
            fotoUrl: integrante.image
        });

    } catch (error) {
        console.error('Erro no Dossiê Público:', error);
        return res.status(500).json({ error: 'Erro interno ao buscar dossiê.' });
    }
});

const controller = new TreinamentoController();

// Daqui para baixo, exige token de autenticação
router.use(authenticateToken);

// Cadastro Manual
router.post('/', validate(createTreinamentoSchema), controller.create);

// Importação em Massa
router.post('/importar', validate(importTreinamentosSchema), controller.importar);

// Listar por Usuário
router.get('/usuario/:userId', controller.listByUser);

// Deletar
router.delete('/:id', controller.delete);

export default router;