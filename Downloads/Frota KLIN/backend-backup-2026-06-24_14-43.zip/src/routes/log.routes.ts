import { Router } from 'express';
import { LogController } from '../controllers/LogController';
import { authenticateToken, authorize } from '../middleware/auth';

const router = Router();
const logController = new LogController();
router.get('/', authenticateToken, logController.index);

// A criação de log aceita usuários logados (como app interceptando token) e anônimos (caso o logoff pife).
// Para nossa arquitetura, fazemos authenticateToken opcional ou obrigamos.
// Vamos usar authenticateToken "solto", mas se falhar, o log não é criado com UserId.
// Para facilitar que todos batam na porta:
// 1. Inserir log (Qualquer operador, até sem token se for falha de login)
router.post('/', logController.create);

// 2. Marcar TODOS os logs como resolvidos (Somente chefes)
router.put('/resolver-todos', authenticateToken, logController.resolverTodos);

// 3. Marcar log específico como resolvido
router.put('/:id/resolver', authenticateToken, logController.resolver);

export default router;
