import { Router } from 'express';
import { FornecedorController } from '../controllers/FornecedorController';
import { authenticateToken, authorize } from '../middleware/auth';
import { validate } from '../middleware/validate';
import { fornecedorSchema } from '../schemas/fornecedor.schemas';

const router = Router();
const fornecedorController = new FornecedorController();

router.use(authenticateToken);

// --- Rotas de Escrita (Restritas) ---
router.post('/',
    authorize(['ADMIN', 'COORDENADOR']),
    validate(fornecedorSchema),
    fornecedorController.create
);

// --- Rota EXPRESSA para Operadores ---
// Usada nos modais de Abastecimento e Manutenção
router.get('/operacao',
    authorize(['ADMIN', 'COORDENADOR', 'ENCARREGADO', 'OPERADOR']),
    fornecedorController.listarParaOperacao
);

// --- Rotas de Leitura Geral ---
router.get('/',
    authorize(['ADMIN', 'COORDENADOR', 'ENCARREGADO', 'OPERADOR']),
    fornecedorController.list
);

router.get('/:id',
    authorize(['ADMIN', 'COORDENADOR', 'ENCARREGADO']),
    fornecedorController.getById
);

// --- Rotas de Modificação ---
router.put('/:id',
    authorize(['ADMIN', 'COORDENADOR']),
    validate(fornecedorSchema),
    fornecedorController.update
);

router.delete('/:id',
    authorize(['ADMIN']),
    fornecedorController.delete
);

export default router;