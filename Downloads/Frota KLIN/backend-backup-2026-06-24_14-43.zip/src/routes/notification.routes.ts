import { Router } from 'express';
import { NotificationController } from '../controllers/NotificationController';
import { authenticateToken } from '../middleware/auth';

const router = Router();
const controller = new NotificationController();

// Pega a public VAPID key
router.get('/vapid-public-key', controller.getVapidPublicKey);

// Inscrever-se (Requer Autenticação)
router.post('/subscribe', authenticateToken, controller.subscribe);

// Desinscrever
router.post('/unsubscribe', authenticateToken, controller.unsubscribe);

// Forçar varredura e notificação manual (Apenas Admin pode disparar idealmente)
import { checkExpiriesAndNotify } from '../jobs/ExpiryCronJob';
router.post('/test-cron', authenticateToken, async (req, res) => {
  await checkExpiriesAndNotify();
  res.json({ success: true, message: 'Varredura de vencimentos executada.' });
});

export default router;
