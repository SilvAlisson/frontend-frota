import { Router } from 'express';
import { UserController } from '../controllers/UserController';
import { authenticateToken, authorize } from '../middleware/auth';
import { validate } from '../middleware/validate';
import { registerUserSchema } from '../schemas/auth.schemas';
import { prisma } from '../lib/prisma';
import rateLimit from 'express-rate-limit';
import type { AuthenticatedRequest } from '../middleware/auth';

const passkeyLimiter = rateLimit({
    windowMs: 60 * 1000, // 1 minuto
    max: 10,
    message: { error: 'Muitas tentativas biométricas. Aguarde 1 minuto.' },
    standardHeaders: true,
    legacyHeaders: false,
});

const router = Router();
const userController = new UserController();

// 1. Garante que tem um token válido (Login)
router.use(authenticateToken);

// 2. ROTAS "ME" (Usuário logado)
// IMPORTANTE: Devem vir ANTES das rotas /:id para o Express não confundir 'me' com ':id'
router.get('/me/passkeys', passkeyLimiter, async (req: AuthenticatedRequest, res) => {
    try {
        const userId = req.user!.userId;

        const passkeys = await prisma.passkey.findMany({
            where: { userId },
            select: {
                id: true,
                name: true,
                deviceType: true,
                createdAt: true,
                credentialID: true,
            },
            orderBy: { createdAt: 'desc' },
        });

        res.json(passkeys);
    } catch (error) {
        res.status(500).json({ error: 'Erro ao listar dispositivos biométricos.' });
    }
});

router.delete('/me/passkeys/:passkeyId', passkeyLimiter, async (req: AuthenticatedRequest, res) => {
    try {
        const userId = req.user!.userId;
        const { passkeyId } = req.params;

        const passkey = await prisma.passkey.findFirst({
            where: { id: passkeyId, userId },
        });

        if (!passkey) {
            return res.status(404).json({ error: 'Dispositivo não encontrado ou não pertence a este usuário.' });
        }

        await prisma.passkey.delete({ where: { id: passkeyId } });

        await prisma.systemLog.create({
            data: {
                level: 'WARNING',
                source: 'BACKEND_AUTH',
                message: `Passkey revogada pelo usuário`,
                context: {
                    passkeyId,
                    deviceType: passkey.deviceType,
                    deviceName: passkey.name,
                },
                userId,
            },
        });

        res.json({ success: true, message: 'Dispositivo biométrico removido com sucesso.' });
    } catch (error) {
        res.status(500).json({ error: 'Erro ao revogar dispositivo biométrico.' });
    }
});

// 3. CREATE: Apenas ADMIN pode criar novos usuários

// ✅ CORREÇÃO: Adicionada a rota '/register' para casar com a chamada do Frontend
router.post('/register',
    authorize(['ADMIN']),
    validate(registerUserSchema),
    userController.create
);

// Mantemos a rota raiz '/' também por padrão REST
router.post('/',
    authorize(['ADMIN']),
    validate(registerUserSchema),
    userController.create
);

// Permite que o OPERADOR busque a lista de superiores.
// IMPORTANTE: Deve vir ANTES da rota /:id para não dar conflito.
router.get('/encarregados',
    authorize(['ADMIN', 'COORDENADOR', 'ENCARREGADO', 'RH', 'OPERADOR']),
    userController.listarEncarregados
);

// 3. LIST: Admin e Gestores podem ver a lista completa
router.get('/',
    authorize(['ADMIN', 'COORDENADOR', 'ENCARREGADO', 'RH', 'OPERADOR']),
    userController.list
);

// 4. GET BY ID (Dossiê Completo e Detalhes Simples)
router.get('/:id/dossie',
    authorize(['ADMIN', 'COORDENADOR', 'ENCARREGADO', 'RH']),
    userController.getDossie
);

router.get('/:id',
    authorize(['ADMIN', 'COORDENADOR', 'ENCARREGADO', 'RH']),
    userController.getById
);

// 5. UPDATE: Apenas ADMIN altera dados sensíveis (cargos, senhas)
router.put('/:id',
    authorize(['ADMIN']),
    userController.update
);

// NANO-ENDPOINT Anti-Ociosidade
router.put('/:id/status',
    authorize(['ADMIN', 'COORDENADOR', 'ENCARREGADO']),
    userController.updateStatus
);

// 6. DELETE: Apenas ADMIN remove
router.delete('/:id',
    authorize(['ADMIN']),
    userController.delete
);

export default router;