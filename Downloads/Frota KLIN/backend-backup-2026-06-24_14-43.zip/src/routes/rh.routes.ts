import { Router } from 'express';
import { RHController } from '../controllers/RHController';
import { authenticateToken } from '../middleware/auth';

const router = Router();
const rhController = new RHController();

router.use(authenticateToken);

// Retorna KPIs e dados para os gráficos do RH
router.get('/kpis', rhController.getKpis);

// Retorna a Matriz de Qualificação cruzando usuários, cargos e treinamentos
router.get('/matriz', rhController.getMatrizQualificacao);

export default router;
