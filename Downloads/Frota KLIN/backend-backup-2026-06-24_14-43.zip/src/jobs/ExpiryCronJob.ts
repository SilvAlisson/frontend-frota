import cron from 'node-cron';
import { PrismaClient } from '@prisma/client';
import { NotificationService } from '../services/NotificationService';

const prisma = new PrismaClient();
const notificationService = new NotificationService();

export function startExpiryCronJob() {
  // Roda todos os dias às 08:00
  // '0 8 * * *' = 8am daily
  cron.schedule('0 8 * * *', async () => {
    console.log('[CRON] Iniciando verificação de vencimentos (15 dias)...');
    try {
      await checkExpiriesAndNotify();
    } catch (err) {
      console.error('[CRON] Erro na verificação:', err);
    }
  });
}

// Também podemos exportar essa função para testes manuais via rota
export async function checkExpiriesAndNotify() {
  const hoje = new Date();
  const limite15Dias = new Date();
  limite15Dias.setDate(hoje.getDate() + 15);

  let mensagens: string[] = [];

  // 1. Checar Documentos Legais (Validade)
  const documentosVencendo = await prisma.documentoLegal.findMany({
    where: {
      dataValidade: {
        gte: hoje,
        lte: limite15Dias
      },
      status: 'VIGENTE' // Apenas se não estiver cancelado
    },
    include: { veiculo: true }
  });

  for (const doc of documentosVencendo) {
    const dias = Math.ceil((doc.dataValidade!.getTime() - hoje.getTime()) / (1000 * 3600 * 24));
    if (doc.veiculo) {
      mensagens.push(`⚠️ O Documento ${doc.titulo} do veículo ${doc.veiculo.placa} vence em ${dias} dias.`);
    } else {
      mensagens.push(`⚠️ O Documento Global "${doc.titulo}" vence em ${dias} dias.`);
    }
  }

  // 2. Checar Planos de Manutenção Preventiva (Data)
  const planosVencendo = await prisma.planoManutencao.findMany({
    where: {
      dataProximaManutencao: {
        gte: hoje,
        lte: limite15Dias
      }
    },
    include: { veiculo: true }
  });

  for (const plano of planosVencendo) {
    const dias = Math.ceil((plano.dataProximaManutencao!.getTime() - hoje.getTime()) / (1000 * 3600 * 24));
    mensagens.push(`🔧 A Manutenção "${plano.descricao}" do veículo ${plano.veiculo.placa} precisa ser feita em ${dias} dias.`);
  }

  // Enviar Notificações Agrupadas ou Individuais
  // Se houverem muitos, mandar uma notificação agregada, senão mandar individuais.
  if (mensagens.length > 0) {
    console.log(`[CRON] Encontrados ${mensagens.length} avisos. Disparando Pushs...`);
    
    // Podemos disparar até 5 pushes individuais, ou 1 consolidado se for muito spam
    if (mensagens.length <= 3) {
      for (const msg of mensagens) {
        await notificationService.notifyGestores('Alerta de Vencimento', msg, '/admin/manutencoes');
      }
    } else {
      await notificationService.notifyGestores(
        'Vários Vencimentos Próximos', 
        `Existem ${mensagens.length} pendências (documentos/manutenções) para os próximos 15 dias. Acesse o painel.`, 
        '/admin'
      );
    }
  } else {
    console.log('[CRON] Nenhum vencimento para os próximos 15 dias.');
  }
}
