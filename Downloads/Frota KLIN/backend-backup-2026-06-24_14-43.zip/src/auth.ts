import EmailService from './services/EmailService.js';
import { betterAuth } from "better-auth";
import { prismaAdapter } from "better-auth/adapters/prisma";
import { PrismaClient } from "@prisma/client";
import { passkey } from "@better-auth/passkey";
import { bearer } from "better-auth/plugins";
import bcrypt from "bcrypt";

const prisma = new PrismaClient();

const isProduction = process.env.NODE_ENV === "production" || !!process.env.RENDER_EXTERNAL_URL;

// Garante sempre https em produção
const FRONTEND_URL = isProduction
    ? (process.env.FRONTEND_URL || "https://klinfrota.vercel.app").replace(/^http:\/\//, "https://")
    : "http://localhost:5173";

// O Better Auth precisa saber a URL PÚBLICA que o browser usa para montar cookies.
// Como o Vercel proxeia /api/* → Render, do ponto de vista do browser tudo é klinfrota.vercel.app.
// Se o baseURL fosse onrender.com, o cookie seria emitido para .onrender.com (third-party no Safari → ITP bloqueia).
// Com baseURL = klinfrota.vercel.app, o cookie é first-party → Safari aceita ✅
const BACKEND_URL = isProduction
    ? (process.env.BETTER_AUTH_URL || FRONTEND_URL)
    : "http://localhost:3001";

// ========== LOG DE DIAGNÓSTICO (inicialização) ==========
console.log('[AUTH_CONFIG] ==========================================');
console.log(`[AUTH_CONFIG] isProduction    : ${isProduction}`);
console.log(`[AUTH_CONFIG] NODE_ENV        : ${process.env.NODE_ENV ?? 'undefined'}`);
console.log(`[AUTH_CONFIG] RENDER_EXTERNAL_URL: ${process.env.RENDER_EXTERNAL_URL ?? 'undefined'}`);
console.log(`[AUTH_CONFIG] BACKEND_URL (baseURL/cookie domain): ${BACKEND_URL}`);
console.log(`[AUTH_CONFIG] FRONTEND_URL    : ${FRONTEND_URL}`);
console.log(`[AUTH_CONFIG] Passkey rpID    : ${isProduction ? 'klinfrota.vercel.app' : 'localhost'}`);
console.log(`[AUTH_CONFIG] Passkey origin  : ${isProduction ? FRONTEND_URL : 'http://localhost:5173'}`);
console.log(`[AUTH_CONFIG] Cookie sameSite : lax`);
console.log(`[AUTH_CONFIG] Cookie secure   : ${isProduction}`);
console.log('[AUTH_CONFIG] ==========================================');

export const auth = betterAuth({
    database: prismaAdapter(prisma, {
        provider: "postgresql",
    }),
    baseURL: BACKEND_URL,
    advanced: {
        defaultCookieAttributes: {
            sameSite: "lax",
            secure: isProduction,
        }
    },
    user: {
        modelName: "User",
        fields: {
            // O Prisma usa 'nome', o Better Auth chama de 'name'
            name: "nome"
        },
        additionalFields: {
            // Garante que role, matricula e status chegam no objeto de sessão
            role: {
                type: "string",
                defaultValue: "OPERADOR",
                returned: true,
            },
            matricula: {
                type: "string",
                required: false,
                returned: true,
            },
            status: {
                type: "string",
                defaultValue: "ATIVO",
                returned: true,
            },
            fotoUrl: {
                type: "string",
                required: false,
                returned: true,
            },
        }
    },
    emailAndPassword: {
        enabled: true,
        // 🔑 Compatibilidade com hashes bcrypt legados ($2b$10$...)
        // O Better Auth usa scrypt por padrão, mas nosso banco tem bcrypt.
        password: {
            hash: async (password: string) => {
                return bcrypt.hash(password, 10);
            },
            verify: async ({ password, hash }: { password: string; hash: string }) => {
                // Suporta hashes bcrypt ($2b$ ou $2a$) E scrypt (salt:hex)
                if (hash.startsWith("$2b$") || hash.startsWith("$2a$")) {
                    return bcrypt.compare(password, hash);
                }
                const [salt, key] = hash.split(":");
                if (!salt || !key) return false;
                const crypto = await import("node:crypto");
                return new Promise<boolean>((resolve, reject) => {
                    crypto.scrypt(
                        password.normalize("NFKC"),
                        salt,
                        64,
                        { N: 16384, r: 16, p: 1, maxmem: 128 * 16384 * 16 * 2 },
                        (err, derivedKey) => {
                            if (err) reject(err);
                            else resolve(derivedKey.toString("hex") === key);
                        }
                    );
                });
            }
        },
        sendResetPassword: async ({ user, token }) => {
            
            await EmailService.sendPasswordResetEmail(user.email, token, user.name);
        }
    },
    plugins: [
        bearer(),
        passkey({
            rpID: isProduction ? "klinfrota.vercel.app" : "localhost",
            rpName: "Frota KLIN",
            origin: FRONTEND_URL,
        }),
    ],
    secret: process.env.JWT_SECRET || "default_super_secret_for_better_auth_123",
    trustedOrigins: [
        "http://localhost:5173",
        "http://localhost:5174",
        "http://localhost:5175",
        "http://localhost:3000",
        "http://127.0.0.1:5173",
        "http://127.0.0.1:5174",
        FRONTEND_URL,
        "https://klinfrota.vercel.app",
        "https://api-frota-klin.onrender.com",
    ]
});
