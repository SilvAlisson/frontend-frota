import "./instrument";
import * as Sentry from "@sentry/node";
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import compression from 'compression';
import 'dotenv/config';
import cron from 'node-cron';
import { env } from './config/env';
import documentoLegalRoutes from './routes/documentoLegal.routes';

// Services e Middlewares
import { JornadaService } from './services/JornadaService';
import { errorHandler } from './middleware/errorHandler';

// ================== IMPORTS DE ROTAS ==================
import authRoutes from './routes/auth.routes';
import notificationRoutes from './routes/notification.routes';
import veiculoRoutes from './routes/Veiculo.routes';
import abastecimentoRoutes from './routes/abastecimento.routes';
import jornadaRoutes from './routes/jornada.routes';
import manutencaoRoutes from './routes/manutencao.routes';
import userRoutes from './routes/user.routes';
import produtoRoutes from './routes/produto.routes';
import fornecedorRoutes from './routes/fornecedor.routes';
import planoManutencaoRoutes from './routes/planoManutencao.routes';
import relatorioRoutes from './routes/relatorio.routes';
import cargoRoutes from './routes/cargo.routes';
import treinamentoRoutes from './routes/treinamento.routes';
import sstRoutes from './routes/sst.routes';
import rhRoutes from './routes/rh.routes';
import { defeitoRoutes } from './routes/defeito.routes';
import r2Routes from './routes/r2.routes';
import logRoutes from './routes/log.routes';
import drilldownRoutes from './routes/drilldown.routes';
import iaRoutes from './routes/ia.routes';
import path from 'path';

// ================== VERIFICAÇÃO DE AMBIENTE ==================
if (!process.env.TOKEN_SECRET) {
  console.error("🔴 ERRO FATAL: TOKEN_SECRET não definido no .env");
  process.exit(1);
}

const app = express();

app.set('trust proxy', 1);

const port = env.PORT || 3001;

// ================== MIDDLEWARES GLOBAIS ==================
// Configuração de CORS (Deve vir ANTES de tudo, incluindo o Better Auth)
const allowedOrigins = env.CORS_ORIGINS.includes(',')
  ? env.CORS_ORIGINS.split(',')
  : [env.CORS_ORIGINS];

app.use(cors({
  origin: function (origin, callback) {
    if (!origin) return callback(null, true);
    if (allowedOrigins.includes('*') || allowedOrigins.indexOf(origin) !== -1) {
      callback(null, true);
    } else {
      callback(new Error('Bloqueado pela política de CORS'));
    }
  },
  credentials: true
}));

import { auth } from './auth';
import { toNodeHandler } from 'better-auth/node';

// 🛑 IMPORTANTE: O Better Auth DEVE vir ANTES do express.json() 
// porque ele lê a requisição como stream!
// Usamos Regex para evitar que o Express 5 (path-to-regexp v8) crash e 
// para impedir que o app.use() fatiasse a URL, confundindo o Better Auth.
const betterAuthHandler = toNodeHandler(auth);

app.all(/^\/api\/auth(\/.*)?$/, (req: import('express').Request, res: import('express').Response) => {
  const start = Date.now();
  const url = req.url;
  const isPasskey = url.includes('passkey') || url.includes('verify');

  // --- LOG DE DIAGNÓSTICO: Cabeçalhos da Requisição ---
  if (isPasskey) {
    console.log(`[AUTH_DEBUG] → ${req.method} ${url}`);
    console.log(`[AUTH_DEBUG]   Origin: ${req.headers.origin ?? 'N/A'}`);
    console.log(`[AUTH_DEBUG]   Referer: ${req.headers.referer ?? 'N/A'}`);
    console.log(`[AUTH_DEBUG]   Cookie: ${req.headers.cookie ? 'PRESENTE' : 'AUSENTE'}`);
    console.log(`[AUTH_DEBUG]   Authorization: ${req.headers.authorization ? 'PRESENTE' : 'AUSENTE'}`);
    console.log(`[AUTH_DEBUG]   Content-Type: ${req.headers['content-type'] ?? 'N/A'}`);
  }

  // --- LOG DE DIAGNÓSTICO: Intercepta WRITE + END para capturar o body completo ---
  let responseBody = '';

  const originalWrite = res.write.bind(res);
  (res as unknown as { write: (chunk: unknown, ...args: unknown[]) => boolean }).write = function (chunk: unknown, ...args: unknown[]) {
    if (chunk && isPasskey) {
      try { responseBody += Buffer.isBuffer(chunk) ? chunk.toString('utf8') : String(chunk); } catch (_) {}
    }
    // eslint-disable-next-line @typescript-eslint/ban-types
    return (originalWrite as Function)(chunk, ...args);
  };

  const originalEnd = res.end.bind(res);
  (res as unknown as { end: (chunk: unknown, ...args: unknown[]) => unknown }).end = function (chunk: unknown, ...args: unknown[]) {
    const duration = Date.now() - start;
    if (chunk && isPasskey) {
      try { responseBody += Buffer.isBuffer(chunk) ? chunk.toString('utf8') : String(chunk); } catch (_) {}
    }
    if (res.statusCode >= 400 || isPasskey) {
      console.log(`[AUTH_DEBUG] ← ${res.statusCode} ${url} (${duration}ms)`);
      if (responseBody) {
        console.log(`[AUTH_DEBUG]   Response body: ${responseBody}`);
      } else {
        console.log(`[AUTH_DEBUG]   Response body: (vazio)`);
      }
    }
    // eslint-disable-next-line @typescript-eslint/ban-types
    return (originalEnd as Function)(chunk, ...args);
  };

  betterAuthHandler(req, res);
});


app.use(express.json());
app.use(compression());

// ==================🛡️ SEGURANÇA 007 ==================
// Helmet: Protege via envio massivo de HTTP Headers (XSS, Clickjack)
app.use(helmet({
  crossOriginResourcePolicy: false, // Permite que nossas imagens geradas localmente apareçam no front-end
}));

// Escudo Global: 300 requisições a cada 15 min por IP (Basic DoS Protection)
const globalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, 
  max: 300,
  message: { error: 'O sistema bloqueou seu acesso temporariamente devido a requisições em excesso. Respire e tente denovo mais tarde.' },
  standardHeaders: true,
  legacyHeaders: false,
});
app.use(globalLimiter);

// Escudo Focado: Rotas de Login sofrem estrangulamento rápido (Anti Força-Bruta) 
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, 
  max: 10, // Apenas 10 tentativas a cada 15 minutos!
  message: { error: 'Invasão por Força Bruta detectada. Seu IP foi bloqueado na rota de Login por 15 minutos.' }
});

// ================== ROTAS DA API ==================
// Autenticação Customizada (Tokens QR)
app.use('/api/auth-custom', authLimiter, authRoutes);

// Usuários
app.use('/api/users', userRoutes);
app.use('/api/notifications', notificationRoutes);

// Gestão de Frota
app.use('/api/veiculos', veiculoRoutes);
app.use('/api/abastecimentos', abastecimentoRoutes);
app.use('/api/jornadas', jornadaRoutes);

// Alterado de 'ordens-servico' para 'manutencoes' para casar com o Frontend
app.use('/api/manutencoes', manutencaoRoutes);

app.use('/api/planos-manutencao', planoManutencaoRoutes);

// Cadastros Auxiliares
app.use('/api/produtos', produtoRoutes);
app.use('/api/fornecedores', fornecedorRoutes);

// RH e Gestão
app.use('/api/cargos', cargoRoutes);
app.use('/api/treinamentos', treinamentoRoutes);
app.use('/api/rh', rhRoutes);

// Documentos Legais
app.use('/api/documentos-legais', documentoLegalRoutes);

// SST — Saúde e Segurança do Trabalho
app.use('/api/sst', sstRoutes);

// Defeitos de Veículo (Reportados via APP Operador)
app.use('/api/defeitos', defeitoRoutes);

// Sistema de Gerenciamento Cloudflare R2 de Mídias
app.use('/api/r2', r2Routes);

// O upload de arquivos agora é feito em arquitetura Client-to-Cloud via R2.

import { authenticateToken } from './middleware/auth';

// 🔐 /uploads protegido — requer sessão válida antes de servir arquivos
app.use('/uploads', authenticateToken, express.static(path.resolve(process.cwd(), 'uploads')));

// Relatórios
app.use('/api/relatorios', relatorioRoutes);
app.use('/api/drilldown', drilldownRoutes);

// Auditoria (Big Brother Logs)
app.use('/api/logs', logRoutes);

// Inteligência Artificial (Kia)
app.use('/api/ia', iaRoutes);

// Health Check (Monitoramento)
app.get('/api/health', (req, res) => {
  res.json({ status: 'UP', timestamp: new Date() });
});

// ================== TRATAMENTO DE ERROS ==================
Sentry.setupExpressErrorHandler(app);
app.use(errorHandler);

// ================== CRON JOBS ==================
cron.schedule('*/15 * * * *', async () => {
  const agora = new Date().toLocaleString('pt-BR');
  console.log(`⏰ [CRON] Disparando verificação de jornadas às ${agora}...`);

  try {
    await JornadaService.fecharJornadasVencidas();
  } catch (error) {
    console.error('❌ [CRON] Falha crítica ao tentar executar o job:', error);
  }
});

// CRON JOB FRENTE 3: Varredura de Ociosidade
// Roda toda meia-noite
cron.schedule('0 0 * * *', async () => {
  console.log('⏰ [CRON] Realizando varredura de Ociosidade (Frente 3)...');
  try {
    // Como a lógica já existe na inteligência do RelatorioController, o frontend consome em tempo real.
    // Mas esta rotina enviaria emails ou SMS.
    console.log('✅ Varredura de Ociosidade Completa.');
  } catch (e) {
    console.error('❌ [CRON] Erro na varredura de ociosidade:', e);
  }
});

// CRON JOB FRENTE AUDITORIA: Limpeza de Logs Antigos (>30 dias)
// Roda toda madrugada às 03:00
cron.schedule('0 3 * * *', async () => {
  console.log('⏰ [CRON] Iniciando limpeza de SystemLogs antigos (>30 dias)...');
  try {
    const { prisma } = require('./lib/prisma');
    const trintaDiasAtras = new Date();
    trintaDiasAtras.setDate(trintaDiasAtras.getDate() - 30);
    
    const result = await prisma.systemLog.deleteMany({
      where: {
        createdAt: {
          lt: trintaDiasAtras
        }
      }
    });
    console.log(`✅ [CRON] Limpeza de Logs Completa: ${result.count} eventos antigos deletados.`);
  } catch (e) {
    console.error('❌ [CRON] Erro ao limpar SystemLogs:', e);
  }
});

import { NotificationService } from './services/NotificationService';
const notificationService = new NotificationService();

// CRON JOB FRENTE DOCUMENTOS: Verificar documentos próximos do vencimento
// Roda todo dia às 08:00
cron.schedule('0 8 * * *', async () => {
  console.log('⏰ [CRON] Verificando documentos vencendo nos próximos 30 dias...');
  try {
    const { prisma } = require('./lib/prisma');
    const trintaDiasFrente = new Date();
    trintaDiasFrente.setDate(trintaDiasFrente.getDate() + 30);
    const hoje = new Date();

    const documentos = await prisma.documentoLegal.findMany({
      where: {
        status: 'VIGENTE',
        dataValidade: {
          not: null,
          lte: trintaDiasFrente,
          gte: hoje
        }
      }
    });

    const vencidos = await prisma.documentoLegal.findMany({
      where: {
        status: 'VIGENTE',
        dataValidade: {
          not: null,
          lt: hoje
        }
      }
    });

    let docsVencendo = documentos.length;
    let docsVencidos = vencidos.length;

    if (docsVencendo > 0 || docsVencidos > 0) {
      let bodyText = '';
      if (docsVencidos > 0) bodyText += `⚠ ${docsVencidos} documentos já estão vencidos! `;
      if (docsVencendo > 0) bodyText += `🔔 ${docsVencendo} documentos vencem em menos de 30 dias.`;

      await notificationService.notifyGestores(
        'Alerta de Documentos',
        bodyText.trim(),
        '/gestao-documentos'
      );
      console.log(`✅ [CRON] Alerta PUSH enviado para Gestores (${docsVencidos} vencidos, ${docsVencendo} vencendo).`);
    } else {
      console.log('✅ [CRON] Nenhum documento com alerta de vencimento.');
    }
  } catch (e) {
    console.error('❌ [CRON] Erro na verificação de documentos:', e);
  }
});

// ================== START SERVER ==================
app.listen(port, () => {
  console.log(`✅ Servidor rodando na porta ${port}`);
  console.log(`🌍 Ambiente: ${process.env.NODE_ENV || 'development'}`);
});