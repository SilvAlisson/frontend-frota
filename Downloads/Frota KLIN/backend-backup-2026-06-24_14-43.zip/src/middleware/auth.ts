import { Request, Response, NextFunction } from 'express';
import { env } from '../config/env';
import { auth } from '../auth';
import { fromNodeHeaders } from 'better-auth/node';
import jwt from 'jsonwebtoken';
import { prisma } from '../lib/prisma';

export interface AuthenticatedRequest extends Request {
  user?: { userId: string; role: string; nome?: string; email?: string };
}

/**
 * Middleware de autenticação com suporte dual:
 * 1. Sessão do Better Auth (cookie) — login por email/senha ou biometria
 * 2. Bearer Token JWT — fallback para QR Code e apps mobile
 */
export const authenticateToken = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    // --- MODO 1: Sessão Better Auth (Cookie) ---
    const session = await auth.api.getSession({
      headers: fromNodeHeaders(req.headers)
    });

    if (session?.user) {
      req.user = {
        userId: session.user.id,
        role: (session.user as any).role as string || 'OPERADOR',
        nome: session.user.name,
        email: session.user.email
      };
      return next();
    }

    // --- MODO 2: Bearer Token JWT (QR Code / App Mobile) ---
    const authHeader = req.headers['authorization'];
    const token = authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : null;

    if (token) {
      try {
        const decoded = jwt.verify(token, env.TOKEN_SECRET) as any;
        req.user = {
          userId: decoded.userId,
          role: decoded.role || 'OPERADOR',
          nome: decoded.nome,
          email: decoded.email
        };
        return next();
      } catch (jwtError) {
        // Se falhou como JWT, pode ser um Session Token (criado no login com QR code)
        const sessionDb = await prisma.session.findFirst({
          where: { token },
          include: { user: true }
        });

        if (sessionDb && sessionDb.expiresAt > new Date()) {
          req.user = {
            userId: sessionDb.user.id,
            role: sessionDb.user.role || 'OPERADOR',
            nome: sessionDb.user.nome,
            email: sessionDb.user.email || undefined
          };
          return next();
        }
      }
    }

    return res.status(401).json({ error: 'Token não fornecido ou Sessão expirada.' });

  } catch (error) {
    return res.status(403).json({ error: 'Sessão ou token inválido.' });
  }
};

export const authorize = (allowedRoles: string[]) => {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    if (!req.user) return res.sendStatus(401);
    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({ error: 'Acesso negado: Permissões insuficientes.' });
    }
    next();
  };
};