import { Response, NextFunction } from 'express';
import { prisma } from '../lib/prisma';
import { JornadaService } from '../services/JornadaService';
import { AuthenticatedRequest } from '../middleware/auth';
import { Prisma } from '@prisma/client';
import { z } from 'zod';
import {
    iniciarJornadaSchema,
    finalizarJornadaSchema,
    buscaJornadaSchema,
    updateJornadaSchema
} from '../schemas/jornada.schemas';

// --- TIPAGENS ---
type IniciarJornadaData = z.infer<typeof iniciarJornadaSchema>['body'];
type FinalizarJornadaBody = z.infer<typeof finalizarJornadaSchema>['body'];
type BuscaJornadaQuery = z.infer<typeof buscaJornadaSchema>['query'];
type UpdateJornadaBody = z.infer<typeof updateJornadaSchema>['body'];

// --- CONSTANTES & CONFIGURAÇÕES CORPORATIVAS ---
const VELOCIDADE_MAXIMA_POSSIVEL_KMH = 150; // Física (Velocidade Limite)
const MAX_GAP_PERMITIDO_KM = 3000; // Trava de segurança máxima (Anti-digito extra grave)
const MAX_RODAGEM_TURNO_KM = 2000; // Limite biológico/turno

export class JornadaController {

    private async sincronizarKmVeiculo(veiculoId: string, tx: Prisma.TransactionClient) {
        const ultimaJornadaReal = await tx.jornada.findFirst({
            where: { veiculoId: veiculoId, kmFim: { not: null } },
            orderBy: { dataFim: 'desc' }
        });

        if (ultimaJornadaReal && ultimaJornadaReal.kmFim) {
            await tx.veiculo.update({
                where: { id: veiculoId },
                data: { ultimoKm: Number(ultimaJornadaReal.kmFim) }
            });
        }
    }

    /**
     * 🛡️ INICIAR JORNADA (Sem OCR, Com Auditoria Limpa)
     */
    iniciar = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            const { veiculoId, encarregadoId, kmInicio: kmDigitado, observacoes, fotoInicioUrl } = req.body as IniciarJornadaData;
            const operadorId = req.user?.userId;

            if (!operadorId || !encarregadoId) {
                return res.status(401).json({ error: 'Autenticação necessária.' });
            }

            // TRANSAÇÃO ATÔMICA
            const resultado = await prisma.$transaction(async (tx) => {
                // A. Blindagem de Concorrência com Row-Level Locking
                const veiculosOcupados = await tx.$queryRaw<{id: string}[]>`SELECT id FROM "Jornada" WHERE "veiculoId" = ${veiculoId} AND "dataFim" IS NULL FOR UPDATE`;
                if (veiculosOcupados.length > 0) throw new Error(`CONFLITO: O veículo já está em rota com outro motorista.`);

                const operadoresOcupados = await tx.$queryRaw<{id: string}[]>`SELECT id FROM "Jornada" WHERE "operadorId" = ${operadorId} AND "dataFim" IS NULL FOR UPDATE`;
                if (operadoresOcupados.length > 0) throw new Error(`VOCÊ JÁ TEM UMA ROTA ABERTA: Finalize a anterior primeiro.`);

                const veiculo = await tx.veiculo.findUnique({ where: { id: veiculoId } });
                if (!veiculo) throw new Error('Veículo não encontrado.');

                if (req.user?.role === 'ENCARREGADO') {
                    const tiposPermitidos = ['UTILITARIO', 'LEVE', 'OUTRO'];
                    if (veiculo.tipoVeiculo && !tiposPermitidos.includes(veiculo.tipoVeiculo)) {
                        throw new Error(`Atenção: Encarregados não têm permissão para conduzir veículos pesados.`);
                    }
                }

                const ultimoKMConsolidado = veiculo.ultimoKm || 0;
                let kmProcessado = kmDigitado;

                // B. Bloqueio de Digito Extra (Anti-Fraude explícito)
                if ((kmProcessado - ultimoKMConsolidado) > MAX_GAP_PERMITIDO_KM) {
                    throw new Error(`BLOQUEIO DE SEGURANÇA: Salto irreal de KM detectado. O veículo pulou de ${ultimoKMConsolidado} para ${kmProcessado}. Verifique o odômetro!`);
                }

                if (kmProcessado < ultimoKMConsolidado) {
                    throw new Error(`ERRO: KM informado (${kmProcessado}) é menor que o anterior (${ultimoKMConsolidado}).`);
                }

                const diferencaKm = kmProcessado - ultimoKMConsolidado;
                let observacaoGap = '';

                // C. Resolução de Gaps Operacionais e KM Pendente do Cron
                const ultimaJornadaVencida = await tx.jornada.findFirst({
                    where: { veiculoId, kmFim: null, dataFim: { not: null } },
                    orderBy: { dataFim: 'desc' }
                });

                if (ultimaJornadaVencida) {
                    // O Cron fechou a jornada por tempo (14h), mas o KM ficou pendente.
                    // O KM inicial do NOVO operador será o KM final do operador ANTERIOR.
                    await tx.jornada.update({
                        where: { id: ultimaJornadaVencida.id },
                        data: {
                            kmFim: kmProcessado,
                            observacoes: ultimaJornadaVencida.observacoes + ` | ⚠️ KM Final (${kmProcessado}) registrado posteriormente pelo próximo motorista.`
                        }
                    });

                    await tx.historicoKm.create({
                        data: {
                            km: kmProcessado,
                            origem: "JORNADA",
                            origemId: ultimaJornadaVencida.id,
                            veiculoId: veiculoId
                        }
                    });
                } else if (diferencaKm > 50) {
                    observacaoGap = `\n⚠️ [SISTEMA] Gap Operacional: Veículo assumido com salto de ${diferencaKm}km não justificado desde a última viagem.`;
                }

                // D. Muro Mágico (Despertar Inteligente Anti-Ociosidade)
                if (veiculo.status === 'EM_MANUTENCAO') {
                    await tx.veiculo.update({ where: { id: veiculoId }, data: { status: 'ATIVO' } });
                }

                const opStatus = await tx.user.findUnique({ where: { id: operadorId }, select: { status: true } });
                if (opStatus && ['FERIAS', 'ATESTADO', 'AFASTADO'].includes(opStatus.status)) {
                    await tx.user.update({ where: { id: operadorId }, data: { status: 'ATIVO' } });
                }

                // E. Criação da Jornada Real
                return await tx.jornada.create({
                    data: {
                        veiculoId,
                        operadorId,
                        encarregadoId,
                        dataInicio: req.body.actionCreatedAt ? new Date(req.body.actionCreatedAt) : new Date(),
                        kmInicio: kmProcessado,
                        observacoes: observacoes ? (observacoes + observacaoGap) : observacaoGap,
                        fotoInicioUrl: fotoInicioUrl ?? null,
                    },
                    include: { veiculo: true, encarregado: true }
                });
            }, { maxWait: 5000, timeout: 20000 });

            return res.status(201).json(resultado);

        } catch (error: unknown) {
            const err = error instanceof Error ? error : new Error(String(error));
            const errosConflito = ['CONFLITO', 'VOCÊ JÁ TEM', 'ERRO', 'BLOQUEIO', 'Atenção'];
            if (errosConflito.some(msg => err.message.includes(msg))) {

                // Registrar o Insight/Log se for Bloqueio ou Impossível
                if (err.message.includes('BLOQUEIO') || err.message.includes('IMPOSSÍVEL')) {
                    await prisma.systemLog.create({
                        data: {
                            level: 'FRAUD_ATTEMPT',
                            source: 'BACKEND_JORNADAS',
                            message: err.message,
                            userId: req.user?.userId || null,
                            veiculoId: req.body.veiculoId || null,
                            context: JSON.parse(JSON.stringify(req.body))
                        }
                    }).catch(e => console.error("Falha ao salvar SystemLog:", e));
                }

                return res.status(400).json({ error: err.message });
            }
            next(err);
        }
    }

    /**
     * 🛡️ FINALIZAR JORNADA (Sem OCR)
     */
    finalizar = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            const { kmFim: kmDigitado, observacoes, fotoFimUrl } = req.body as FinalizarJornadaBody;
            const { id } = req.params;

            if (!id) return res.status(400).json({ error: 'ID necessário.' });

            const resultado = await prisma.$transaction(async (tx) => {
                const jornada = await tx.jornada.findUnique({ where: { id: String(id) } });

                if (!jornada) throw new Error('ERRO: Jornada não encontrada.');
                if (!fotoFimUrl) throw new Error('ERRO: Você precisa enviar a foto do Odômetro final.');
                if (jornada.dataFim) {
                    throw new Error('ERRO: Esta jornada já foi finalizada administrativamente pelo sistema. O KM Final será preenchido automaticamente quando o próximo motorista iniciar um turno com este veículo.');
                }
                
                // Trava Dupla 007 (Anti-Sabotagem): Operador só fecha própria Rota
                if (req.user?.role === 'OPERADOR' && jornada.operadorId !== req.user?.userId) {
                    throw new Error('ERRO: Você não pode alterar a viagem de outro Operador.');
                }

                const agora = new Date();
                const dataParaCalculo = jornada.dataFim || agora;
                const diffMs = dataParaCalculo.getTime() - new Date(jornada.dataInicio).getTime();
                const horasReais = Math.max(diffMs / (1000 * 60 * 60), 0.08); // Minimo 5 min

                let kmFimProcessado = kmDigitado;
                const distBruta = kmDigitado - jornada.kmInicio;

                // Smart Typo Check substituído por Hard Block (Anti-Fraude explícito)
                if (distBruta > MAX_RODAGEM_TURNO_KM) {
                     throw new Error(`ERRO: BLOQUEIO DE SEGURANÇA: Salto irreal de KM detectado para um único turno (${distBruta}km). Verifique o KM digitado!`);
                }

                const distancia = kmFimProcessado - jornada.kmInicio;

                if (distancia < 0) throw new Error(`ERRO: KM Final menor que Inicial.`);
                if (distancia > MAX_RODAGEM_TURNO_KM) throw new Error(`ERRO: BLOQUEIO: Distância de ${distancia}km impossível para um turno.`);

                const velocidadeMedia = distancia / horasReais;
                if (velocidadeMedia > VELOCIDADE_MAXIMA_POSSIVEL_KMH) {
                    throw new Error(`ERRO: IMPOSSÍVEL: Velocidade média de ${velocidadeMedia.toFixed(0)}km/h detectada.`);
                }
                
                const novaDataFim = jornada.dataFim || (req.body.actionCreatedAt ? new Date(req.body.actionCreatedAt) : agora);
                const obsNova = observacoes ? (jornada.observacoes ? `${jornada.observacoes} | ${observacoes}` : observacoes) : (jornada.observacoes || '');

                const update = await tx.jornada.update({
                    where: { id: String(id) },
                    data: {
                        dataFim: novaDataFim,
                        kmFim: kmFimProcessado,
                        observacoes: obsNova,
                        fotoFimUrl: fotoFimUrl ?? null,
                    },
                });

                await this.sincronizarKmVeiculo(jornada.veiculoId, tx);

                await tx.historicoKm.create({
                    data: {
                        km: kmFimProcessado,
                        origem: "JORNADA",
                        origemId: String(id),
                        veiculoId: jornada.veiculoId
                    }
                });

                return update;
            }, { maxWait: 10000, timeout: 20000 });

            res.json(resultado);

        } catch (error: unknown) {
            const err = error instanceof Error ? error : new Error(String(error));
            // Se for um erro contendo nossas palavras-chave de bloqueio, logamos como fraude
            if (err.message && (err.message.includes('IMPOSSÍVEL') || err.message.includes('BLOQUEIO'))) {
                await prisma.systemLog.create({
                    data: {
                        level: 'FRAUD_ATTEMPT',
                        source: 'BACKEND_JORNADAS',
                        message: err.message,
                        userId: req.user?.userId || null,
                        context: JSON.parse(JSON.stringify(req.body))
                    }
                }).catch(e => console.error("Falha ao salvar SystemLog:", e));
            }
            return res.status(400).json({ error: err.message.replace('ERRO: ', '') });
        }
    }

    // --- LEITURA E EDIÇÃO (MANTIDOS INTACTOS) ---
    getById = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            const jornada = await prisma.jornada.findUnique({
                where: { id: String(req.params.id) },
                include: { 
                    veiculo: true, 
                    operador: { select: { id: true, nome: true, role: true, image: true, status: true, matricula: true, cargo: true } }, 
                    encarregado: { select: { id: true, nome: true, role: true } } 
                }
            });

            if (!jornada) {
                return res.status(404).json({ error: 'Jornada não encontrada.' });
            }

            // 🛡️ TRAVA IDOR 007: Operador só vê a própria jornada
            if (req.user?.role === 'OPERADOR' && jornada.operadorId !== req.user?.userId) {
                return res.status(403).json({ error: 'Acesso negado. Você não tem permissão para visualizar esta jornada.' });
            }

            res.json(jornada);
        } catch (e) { next(e); }
    }

    listarAbertas = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            // Trava Dupla 007: Só a gerência pode rastrear as frotas em andamento
            if (!['ADMIN', 'ENCARREGADO'].includes(req.user?.role || '')) {
                return res.status(403).json({ error: 'Acesso negado. Apenas o Hub de Comando pode monitorar a base total.' });
            }

            const list = await prisma.jornada.findMany({
                where: { dataFim: null },
                include: { 
                    veiculo: true, 
                    operador: { select: { id: true, nome: true, role: true, image: true, status: true, matricula: true, cargo: true } } 
                },
                orderBy: { dataInicio: 'desc' }
            });
            res.json(list);
        } catch (e) { next(e); }
    }

    listarMinhasAbertas = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            const list = await prisma.jornada.findMany({
                where: { operadorId: req.user?.userId, dataFim: null },
                include: { 
                    veiculo: true, 
                    encarregado: { select: { id: true, nome: true, role: true } }, 
                    operador: { select: { id: true, nome: true, role: true, image: true, status: true, matricula: true, cargo: true } } 
                },
                orderBy: { dataInicio: 'desc' }
            });
            res.json(list);
        } catch (e) { next(e); }
    }

    listarHistorico = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            const userRole = req.user?.role || '';
            const userId = req.user?.userId;

            if (!['ADMIN', 'ENCARREGADO', 'OPERADOR'].includes(userRole)) {
                return res.status(403).json({ error: 'Acesso negado.' });
            }

            const { dataInicio, dataFim, veiculoId, operadorId } = req.query as unknown as BuscaJornadaQuery;
            const where: Prisma.JornadaWhereInput = { kmFim: { not: null } };

            if (userRole === 'OPERADOR') where.operadorId = userId;
            else if (operadorId) where.operadorId = operadorId;

            if (dataInicio) where.dataInicio = { gte: new Date(dataInicio as string) };
            if (dataFim) {
                const fim = new Date(dataFim as string);
                fim.setDate(fim.getDate() + 1);
                where.dataInicio = { 
                    ...(typeof where.dataInicio === 'object' && where.dataInicio && 'gte' in where.dataInicio ? where.dataInicio : {}),
                    lt: fim 
                };
            }
            if (veiculoId) where.veiculoId = veiculoId;

            const historico = await prisma.jornada.findMany({
                where,
                include: {
                    veiculo: { select: { placa: true, modelo: true } },
                    operador: { select: { nome: true } },
                    encarregado: { select: { nome: true } }
                },
                orderBy: { dataInicio: 'desc' },
                take: 100
            });

            const formatado = historico.map(j => ({
                ...j,
                kmPercorrido: (j.kmFim || 0) - j.kmInicio,
                fotoInicio: j.fotoInicioUrl,
                fotoFim: j.fotoFimUrl
            }));

            res.json(formatado);
        } catch (error) { next(error); }
    }

    listarMeuHistorico = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            const userId = req.user?.userId;
            const historico = await prisma.jornada.findMany({
                where: { operadorId: userId, kmFim: { not: null } },
                include: {
                    veiculo: { select: { placa: true, modelo: true } },
                    encarregado: { select: { nome: true } }
                },
                orderBy: { dataInicio: 'desc' },
                take: 50
            });
            
            const formatado = historico.map(j => ({
                ...j,
                kmPercorrido: (j.kmFim || 0) - j.kmInicio
            }));

            res.json(formatado);
        } catch (e) { next(e); }
    }

    update = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            if (!['ADMIN', 'ENCARREGADO'].includes(req.user?.role || '')) {
                return res.status(403).json({ error: 'Apenas gestores podem corrigir jornadas.' });
            }
            const { id } = req.params;
            const dados = req.body as UpdateJornadaBody;

            const { atualizarOdometroVeiculo, ...camposParaBanco } = dados;

            // 🔐 007 Fix: Objeto de update tipado e sanitizado via Zod
            const dataToUpdate: Prisma.JornadaUpdateInput = {
                ...camposParaBanco,
                dataInicio: camposParaBanco.dataInicio ? new Date(camposParaBanco.dataInicio) : undefined,
                dataFim: camposParaBanco.dataFim ? new Date(camposParaBanco.dataFim) : undefined,
            };

            const jornadaAtualizada = await prisma.$transaction(async (tx) => {
                if (dataToUpdate.kmInicio !== undefined) {
                    const jornadaOriginal = await tx.jornada.findUnique({ where: { id: String(id) } });
                    if (jornadaOriginal) {
                         const anterior = await tx.jornada.findFirst({
                            where: { veiculoId: jornadaOriginal.veiculoId, dataFim: { lt: jornadaOriginal.dataInicio }, kmFim: { not: null }},
                            orderBy: { dataFim: 'desc' }
                         });
                         
                         const kmInicioNum = Number(dataToUpdate.kmInicio);
                         if (anterior && anterior.kmFim && (kmInicioNum - anterior.kmFim > MAX_GAP_PERMITIDO_KM)) {
                             throw new Error(`A edição criaria um salto inseguro de KM. Verifique os dados.`);
                         }
                    }
                }

                // Lógica de Fechamento Administrativo (Se KM Fim for informado mas não Data Fim)
                if (dataToUpdate.kmFim !== undefined && !dataToUpdate.dataFim) {
                    const encarregadoUser = req.user?.userId ? await tx.user.findUnique({ where: { id: req.user.userId } }) : null;
                    const nomeEncarregado = encarregadoUser?.nome || 'Gestor';
                    
                    dataToUpdate.dataFim = new Date();
                    const tagFechamento = `⚠️ [SISTEMA] Fechamento administrativo forçado pelo Encarregado ${nomeEncarregado}.`;
                    
                    dataToUpdate.observacoes = dataToUpdate.observacoes 
                        ? (`${dataToUpdate.observacoes} | ${tagFechamento}`)
                        : tagFechamento;
                }

                const updated = await tx.jornada.update({
                    where: { id: String(id) },
                    data: dataToUpdate,
                    include: { veiculo: true }
                });

                // Sincroniza o KM do veículo se o KM Fim foi alterado ou se for solicitado explicitamente
                if (dataToUpdate.kmFim !== undefined || atualizarOdometroVeiculo) {
                    await this.sincronizarKmVeiculo(updated.veiculoId, tx);
                }
                return updated;
            });

            res.json(jornadaAtualizada);
        } catch (error: unknown) {
            const err = error instanceof Error ? error : new Error(String(error));
            return res.status(400).json({ error: err.message });
        }
    }

    delete = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            if (!['ADMIN', 'ENCARREGADO'].includes(req.user?.role || '')) return res.status(403).json({ error: 'Acesso negado.' });
            await prisma.jornada.delete({ where: { id: String(req.params.id) } });
            res.json({ message: 'Removido com sucesso.' });
        } catch (error) { next(error); }
    }

    verificarTimeouts = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            await JornadaService.fecharJornadasVencidas();
            res.json({ message: 'Verificação executada.', timestamp: new Date() });
        } catch (error) { next(error); }
    }
}