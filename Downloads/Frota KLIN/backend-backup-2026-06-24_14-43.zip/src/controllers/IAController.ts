import { Response, NextFunction } from 'express';
import { prisma } from '../lib/prisma';
import { AuthenticatedRequest } from '../middleware/auth';
import { iaService } from '../services/IAService';
import { addDays } from '../utils/dateUtils';

const ROLES_PERMITIDOS = ['ADMIN', 'RH', 'COORDENADOR', 'ENCARREGADO'];

function checarAcesso(req: AuthenticatedRequest, res: Response): boolean {
    if (!req.user || !ROLES_PERMITIDOS.includes(req.user.role)) {
        res.status(403).json({ error: 'Acesso negado. Nível de permissão insuficiente para usar a IA.' });
        return false;
    }
    return true;
}

export class IAController {

    // ============================================================================
    // 🚀 NOVO ENDPOINT: STREAMING E FUNCTION CALLING (USADO PELA NOVA KIA)
    // ============================================================================
    public consultarStream = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
        try {
            if (!checarAcesso(req, res)) return;

            const { pergunta, contextoSistema, historico } = req.body;
            if (!pergunta || typeof pergunta !== 'string' || pergunta.trim().length < 2) {
                res.status(400).json({ error: 'Pergunta inválida.' });
                return;
            }

            // Headers rígidos para Server-Sent Events (SSE) e Bypass de Buffering (Nginx/Render)
            res.setHeader('Content-Type', 'text/event-stream');
            res.setHeader('Cache-Control', 'no-cache, no-transform');
            res.setHeader('Connection', 'keep-alive');
            res.setHeader('X-Accel-Buffering', 'no');
            res.flushHeaders();

            // Desconecta o processamento se o usuário fechar a aba do navegador
            req.on('close', () => res.end());

            await iaService.gerarRespostaStream(
                pergunta.trim(),
                contextoSistema || `Usuário atual: ${req.user?.nome} (Cargo: ${req.user?.role})`,
                historico,
                (chunk: string) => {
                    res.write(`data: ${JSON.stringify({ text: chunk })}\n\n`);
                }
            );

            res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
            res.end();
        } catch (error) {
            console.error('[IAController] Erro fatal no stream:', error);
            res.write(`data: ${JSON.stringify({ error: 'Falha interna ao processar a requisição de IA.' })}\n\n`);
            res.end();
        }
    };

    // ============================================================================
    // ⚠️ ENDPOINT LEGADO: CONSULTA GERAL SÍNCRONA
    // Mantido para retrocompatibilidade, mas a carga de dados foi limitada
    // ============================================================================
    public consultaGeral = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
        try {
            if (!checarAcesso(req, res)) return;

            const { pergunta, historico } = req.body;
            if (!pergunta || typeof pergunta !== 'string' || pergunta.trim().length < 3) {
                res.status(400).json({ error: 'Pergunta inválida ou muito curta.' });
                return;
            }

            const hoje = new Date();
            // Reduzido para 30 dias para evitar OOM (Out of Memory) e estouro de Tokens
            const limiteHistorico = addDays(hoje, -30);

            // Coleta otimizada: Apenas o essencial para contexto rápido
            const [veiculos, operadores, alertasSST] = await Promise.all([
                prisma.veiculo.findMany({
                    select: { placa: true, modelo: true, status: true, ultimoKm: true }
                }),
                prisma.user.findMany({
                    where: { role: 'OPERADOR' },
                    select: { nome: true, status: true }
                }),
                prisma.acaoSST.findMany({
                    where: { status: { in: ['PENDENTE', 'ATRASADO'] } }
                })
            ]);

            const dbDump = {
                avisoSistema: "ATENÇÃO KIA: Este é um sumário de alto nível da frota. Se precisar de detalhes aprofundados, instrua o usuário a perguntar no formato de Chat/Stream.",
                veiculos,
                operadores,
                alertasSST
            };

            const resposta = await iaService.gerarResposta(pergunta.trim(), JSON.stringify(dbDump), historico);
            res.json({ resposta });
        } catch (error) {
            next(error);
        }
    };

    // ============================================================================
    // 📊 INSIGHTS DE KPIs (Análise de Dashboard)
    // ============================================================================
    public insightsKPIs = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
        try {
            if (!checarAcesso(req, res)) return;

            const { kpis, mes, ano } = req.body;
            if (!kpis) {
                res.status(400).json({ error: 'Dados de KPI são obrigatórios.' });
                return;
            }

            const mesN = Number(mes) || new Date().getMonth() + 1;
            const anoN = Number(ano) || new Date().getFullYear();
            const mesAnterior = mesN === 1 ? 12 : mesN - 1;
            const anoAnterior = mesN === 1 ? anoN - 1 : anoN;

            const inicioMesAnt = new Date(anoAnterior, mesAnterior - 1, 1);
            const fimMesAnt = new Date(anoAnterior, mesAnterior, 1);

            const [combustivelAnt, manutencaoAnt, jornadasAnt] = await Promise.all([
                prisma.itemAbastecimento.aggregate({
                    _sum: { valorTotal: true },
                    where: { produto: { tipo: 'COMBUSTIVEL' }, abastecimento: { dataHora: { gte: inicioMesAnt, lt: fimMesAnt } } }
                }),
                prisma.ordemServico.aggregate({
                    _sum: { custoTotal: true },
                    where: { data: { gte: inicioMesAnt, lt: fimMesAnt }, status: 'CONCLUIDA' }
                }),
                prisma.jornada.findMany({
                    where: { dataInicio: { gte: inicioMesAnt, lt: fimMesAnt }, kmFim: { not: null } },
                    select: { kmInicio: true, kmFim: true }
                }),
            ]);

            const custoAntTotal = Number(combustivelAnt._sum.valorTotal || 0) + Number(manutencaoAnt._sum.custoTotal || 0);
            const kmAnt = jornadasAnt.reduce((acc, j) => acc + ((j.kmFim ?? 0) - j.kmInicio), 0);

            const contexto = iaService.montarContextoFrota({
                periodoAtual: `${mesN}/${anoN}`,
                periodoAnterior: `${mesAnterior}/${anoAnterior}`,
                kpisAtuais: kpis,
                kpisAnterior: {
                    custoTotal: custoAntTotal.toFixed(2),
                    kmRodado: kmAnt,
                    custoManutencao: Number(manutencaoAnt._sum.custoTotal || 0).toFixed(2),
                    custoCombustivel: Number(combustivelAnt._sum.valorTotal || 0).toFixed(2),
                }
            });

            const pergunta = `Com base nos KPIs do período atual versus o período anterior, gere um texto curto de análise (máximo 4 bullet points) destacando: variações significativas de custo (acima de 10%), tendências preocupantes e 1 recomendação de ação. Seja direto e use valores reais dos dados.`;

            const resposta = await iaService.gerarResposta(pergunta, contexto);
            res.json({ insights: resposta });
        } catch (error) {
            next(error);
        }
    };

    // ============================================================================
    // 🚜 DIAGNÓSTICO PREDITIVO DE VEÍCULO
    // ============================================================================
    public analiseVeiculo = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
        try {
            if (!checarAcesso(req, res)) return;

            const { veiculoId } = req.body;
            if (!veiculoId) {
                res.status(400).json({ error: 'ID do veículo é obrigatório.' });
                return;
            }

            const hoje = new Date();
            const inicio60Dias = addDays(hoje, -60);

            const [veiculo, defeitos, manutencoes, abastecimentos, jornadas, planos] = await Promise.all([
                prisma.veiculo.findUnique({
                    where: { id: veiculoId },
                    select: { placa: true, modelo: true, status: true, ultimoKm: true, vencimentoCiv: true, vencimentoCipp: true }
                }),
                prisma.defeitoVeiculo.findMany({
                    where: { veiculoId, createdAt: { gte: inicio60Dias } },
                    select: { categoria: true, status: true, descricao: true, createdAt: true }
                }),
                prisma.ordemServico.findMany({
                    where: { veiculoId, data: { gte: inicio60Dias } },
                    select: { tipo: true, custoTotal: true, observacoes: true, data: true }
                }),
                prisma.itemAbastecimento.findMany({
                    where: { produto: { tipo: 'COMBUSTIVEL' }, abastecimento: { veiculoId, dataHora: { gte: inicio60Dias } } },
                    select: { quantidade: true, abastecimento: { select: { dataHora: true } } }
                }),
                prisma.jornada.findMany({
                    where: { veiculoId, dataInicio: { gte: inicio60Dias }, kmFim: { not: null } },
                    select: { kmInicio: true, kmFim: true, dataInicio: true }
                }),
                prisma.planoManutencao.findMany({
                    where: { veiculoId },
                    select: { descricao: true, tipoIntervalo: true, kmProximaManutencao: true, dataProximaManutencao: true }
                }),
            ]);

            if (!veiculo) {
                res.status(404).json({ error: 'Veículo não encontrado.' });
                return;
            }

            const kmRodado60d = jornadas.reduce((acc, j) => acc + ((j.kmFim ?? 0) - j.kmInicio), 0);
            const litros60d = abastecimentos.reduce((acc, a) => acc + Number(a.quantidade), 0);

            const contexto = iaService.montarContextoFrota({
                veiculo: {
                    placa: veiculo.placa,
                    modelo: veiculo.modelo,
                    status: veiculo.status,
                    kmAtual: veiculo.ultimoKm,
                    vencimentoCIV: veiculo.vencimentoCiv?.toLocaleDateString('pt-BR'),
                    vencimentoCIPP: veiculo.vencimentoCipp?.toLocaleDateString('pt-BR'),
                },
                ultimos60Dias: {
                    kmRodado: Math.round(kmRodado60d),
                    litrosConsumidos: litros60d.toFixed(1),
                    consumoMedioKML: litros60d > 0 ? (kmRodado60d / litros60d).toFixed(2) : 'N/A',
                    defeitos: defeitos.map(d => ({ categoria: d.categoria, status: d.status, descricao: d.descricao, data: new Date(d.createdAt).toLocaleDateString('pt-BR') })),
                    manutencoes: manutencoes.map(m => ({ tipo: m.tipo, custo: Number(m.custoTotal).toFixed(2), obs: m.observacoes, data: m.data.toLocaleDateString('pt-BR') })),
                },
                planosPreventivos: planos.map(p => ({
                    descricao: p.descricao,
                    tipo: p.tipoIntervalo,
                    proximoKM: p.kmProximaManutencao,
                    proximaData: p.dataProximaManutencao?.toLocaleDateString('pt-BR'),
                })),
            });

            const pergunta = `Com base no histórico dos últimos 60 dias deste veículo, gere um diagnóstico técnico completo que inclua: 1) Análise dos defeitos recorrentes por categoria, 2) Avaliação do consumo e eficiência, 3) Status das manutenções, 4) Recomendações de ação prioritárias. Use dados reais, seja direto e profissional.`;

            const resposta = await iaService.gerarResposta(pergunta, contexto);
            res.json({ diagnostico: resposta, veiculo: { placa: veiculo.placa, modelo: veiculo.modelo } });
        } catch (error) {
            next(error);
        }
    };

    // ============================================================================
    // 👥 RELATÓRIO NARRATIVO DE RH
    // ============================================================================
    public relatorioRH = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
        try {
            if (!checarAcesso(req, res)) return;

            const hoje = new Date();
            const dataLimite60 = addDays(hoje, 60);

            const [
                colaboradores,
                treinamentos,
                sstAcoes,
                operadoresStatus,
                documentosRH,
                totalJornadasMes,
            ] = await Promise.all([
                prisma.user.findMany({
                    where: { role: { in: ['OPERADOR', 'ENCARREGADO'] }, nome: { not: { startsWith: '[INATIVO]' } } },
                    select: {
                        nome: true, role: true, status: true,
                        profile: { select: { dataAdmissao: true } },
                        cargo: { select: { nome: true } },
                        treinamentos: { where: { dataVencimento: { lte: dataLimite60 } }, select: { nome: true, dataVencimento: true } }
                    }
                }),
                prisma.treinamento.findMany({
                    where: { dataVencimento: { not: null, lte: dataLimite60 } },
                    select: { nome: true, dataVencimento: true, user: { select: { nome: true, role: true } } },
                    orderBy: { dataVencimento: 'asc' }
                }),
                prisma.acaoSST.findMany({
                    select: { acao: true, programa: true, status: true, vencimento: true, responsaveis: true }
                }),
                prisma.user.findMany({
                    where: { role: 'OPERADOR', status: { not: 'ATIVO' } },
                    select: { nome: true, status: true }
                }),
                prisma.documentoLegal.findMany({
                    where: { dataValidade: { not: null, lte: dataLimite60 }, status: 'VIGENTE', categoria: { in: ['AST', 'LICENCA_AMBIENTAL', 'ATRP', 'CTF IBAMA'] } },
                    select: { titulo: true, categoria: true, dataValidade: true }
                }),
                prisma.jornada.count({
                    where: { dataInicio: { gte: new Date(hoje.getFullYear(), hoje.getMonth(), 1) } }
                }),
            ]);

            const colaboradoresComAlerta = colaboradores.filter(c => c.treinamentos.length > 0);
            const operadoresPorStatus = {
                ativos: colaboradores.filter(c => c.role === 'OPERADOR' && c.status === 'ATIVO').length,
                ferias: operadoresStatus.filter(o => o.status === 'FERIAS').length,
                atestado: operadoresStatus.filter(o => o.status === 'ATESTADO').length,
                afastado: operadoresStatus.filter(o => o.status === 'AFASTADO').length,
            };

            const contexto = iaService.montarContextoFrota({
                dataRelatorio: hoje.toLocaleDateString('pt-BR'),
                quadroDeColaboradores: {
                    operadores: operadoresPorStatus,
                    totalEncarregados: colaboradores.filter(c => c.role === 'ENCARREGADO').length,
                },
                treinamentosVencendo: treinamentos.map(t => ({
                    colaborador: t.user.nome,
                    cargo: t.user.role,
                    treinamento: t.nome,
                    vencimento: t.dataVencimento?.toLocaleDateString('pt-BR'),
                    situacao: t.dataVencimento && t.dataVencimento < hoje ? 'VENCIDO' : 'A VENCER'
                })),
                colaboradoresComTreinamentosVencendo: colaboradoresComAlerta.map(c => c.nome),
                programasSST: {
                    pendentes: sstAcoes.filter(s => s.status === 'PENDENTE').length,
                    atrasados: sstAcoes.filter(s => s.status === 'ATRASADO').length,
                    realizados: sstAcoes.filter(s => s.status === 'REALIZADO').length,
                    acoesAtrasadas: sstAcoes.filter(s => s.status === 'ATRASADO').map(s => ({
                        acao: s.acao, programa: s.programa, responsaveis: s.responsaveis, vencimento: s.vencimento.toLocaleDateString('pt-BR')
                    })),
                },
                documentosRHVencendo: documentosRH.map(d => ({
                    titulo: d.titulo, categoria: d.categoria, vencimento: d.dataValidade?.toLocaleDateString('pt-BR')
                })),
                atividadeOperacional: {
                    jornadasNoMes: totalJornadasMes,
                },
            });

            const pergunta = `Gere um Relatório Executivo de RH completo e bem estruturado, com seções claras para: 1) Resumo do Quadro de Colaboradores, 2) Situação de Treinamentos e ASOs (identificando colaboradores com urgência), 3) Status dos Programas de SST (PCA, PPR, AET, PGR), 4) Documentos Legais e Licenças Críticas, 5) Recomendações Prioritárias de RH. Use títulos em negrito, seja formal e objetivo, como um relatório real entregue à gestão.`;

            const resposta = await iaService.gerarResposta(pergunta, contexto);
            res.json({ relatorio: resposta });
        } catch (error) {
            next(error);
        }
    };
    // ============================================================================
    // 👎👍 FEEDBACK DA IA (Avaliação de Qualidade)
    // ============================================================================
    public enviarFeedback = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
        try {
            if (!req.user) {
                res.status(401).json({ error: 'Não autorizado.' });
                return;
            }

            const { mensagemId } = req.params;
            const { pergunta, respostaIA, avaliacao, contextoRota } = req.body;

            if (!mensagemId || !avaliacao) {
                res.status(400).json({ error: 'ID da mensagem e avaliação são obrigatórios.' });
                return;
            }

            // Atualiza ou cria o feedback (upsert) para evitar duplicidade na mesma mensagem
            const feedback = await prisma.iAFeedback.upsert({
                where: { mensagemId },
                update: { avaliacao },
                create: {
                    mensagemId,
                    pergunta: pergunta || '',
                    respostaIA: respostaIA || '',
                    avaliacao,
                    contextoRota,
                    userId: req.user.userId
                }
            });

            res.json({ message: 'Feedback salvo com sucesso.', feedback });
        } catch (error) {
            next(error);
        }
    };
}

// Exportação da instância (já pronta para ser consumida em ia.routes.ts)
export const iaController = new IAController();