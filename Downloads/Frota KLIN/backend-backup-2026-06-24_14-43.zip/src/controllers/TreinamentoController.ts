import { Response, Request, NextFunction } from 'express';
import { prisma } from '../lib/prisma';
import { AuthenticatedRequest } from '../middleware/auth';
import { z } from 'zod';
import { createTreinamentoSchema, importTreinamentosSchema } from '../schemas/treinamentos.schemas';

// Extração de Tipos (Zod garante que são tipos compatíveis com o que definimos)
type CreateTreinamentoData = z.infer<typeof createTreinamentoSchema>['body'];
type ImportTreinamentosData = z.infer<typeof importTreinamentosSchema>['body'];

export class TreinamentoController {

    // Cadastrar um treinamento (Manual)
    create = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            if (!['ADMIN', 'RH', 'ENCARREGADO'].includes(req.user?.role || '')) {
                res.status(403).json({ error: 'Acesso negado.' });
                return;
            }

            const {
                userId,
                nome,
                dataRealizacao,
                descricao,
                dataVencimento,
                comprovanteUrl,
                diasAntecedenciaAlerta
            } = req.body as CreateTreinamentoData;

            const treinamentosExistentes = await prisma.treinamento.findMany({
                where: { userId },
                select: { nome: true }
            });
            
            const normalizeNome = (n: string) => n.replace(/\s+/g, '').toUpperCase();
            const nomeAlvo = normalizeNome(nome);
            
            const isDuplicado = treinamentosExistentes.some(t => normalizeNome(t.nome) === nomeAlvo);
            
            if (isDuplicado) {
                res.status(409).json({ error: 'O integrante já possui um registro ativo para este treinamento.' });
                return;
            }

            const treinamento = await prisma.treinamento.create({
                data: {
                    user: { connect: { id: userId } },
                    nome,
                    dataRealizacao,
                    descricao: (descricao as string) ?? null,
                    dataVencimento: dataVencimento ?? null,
                    comprovanteUrl: (comprovanteUrl as string) ?? null,
                    diasAntecedenciaAlerta: diasAntecedenciaAlerta ?? 30
                }
            });

            res.status(201).json(treinamento);
        } catch (error) {
            next(error);
        }
    }

    // Importação em massa via Excel
    // Importação em massa via Excel
    importar = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            if (!['ADMIN', 'RH', 'ENCARREGADO'].includes(req.user?.role || '')) {
                res.status(403).json({ error: 'Acesso negado.' });
                return;
            }

            const { userId, treinamentos } = req.body as ImportTreinamentosData;

            // 🔥 A MURALHA NO EXCEL: Buscar os existentes para comparação
            const treinamentosExistentes = await prisma.treinamento.findMany({
                where: { userId },
                select: { nome: true }
            });

            const normalizeNome = (n: string) => n.replace(/\s+/g, '').toUpperCase();
            
            // Criar um Set (lista otimizada) com os nomes já existentes
            const nomesExistentes = new Set(treinamentosExistentes.map(t => normalizeNome(t.nome)));

            // Filtrar a planilha: manter APENAS os treinamentos que o integrante ainda não tem
            const novosTreinamentos = treinamentos.filter(t => !nomesExistentes.has(normalizeNome(t.nome)));

            // Se a planilha inteira for de coisas repetidas, avisa o RH
            if (novosTreinamentos.length === 0) {
                res.status(409).json({ error: 'Todos os treinamentos desta planilha já estão cadastrados para este integrante.' });
                return;
            }

            // createMany insere apenas os que passaram no filtro
            const resultado = await prisma.treinamento.createMany({
                data: novosTreinamentos.map(t => ({
                    userId,
                    nome: t.nome,
                    dataRealizacao: t.dataRealizacao,
                    descricao: (t.descricao as string) ?? null,
                    dataVencimento: t.dataVencimento ?? null,
                    comprovanteUrl: null
                }))
            });

            res.status(201).json({
                message: `Importação concluída: ${resultado.count} novos registros inseridos. ${treinamentos.length - novosTreinamentos.length} ignorados por duplicidade.`,
                count: resultado.count
            });
        } catch (error) {
            next(error);
        }
    }

    // Listar treinamentos de um usuário
    listByUser = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            const { userId } = req.params;

            if (!userId) {
                res.status(400).json({ error: "ID de usuário inválido" });
                return;
            }

            const treinamentos = await prisma.treinamento.findMany({
                where: { userId },
                orderBy: { dataRealizacao: 'desc' }
            });

            res.json(treinamentos);
        } catch (error) {
            next(error);
        }
    }

    delete = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            if (!['ADMIN', 'RH'].includes(req.user?.role || '')) {
                res.status(403).json({ error: 'Acesso negado.' });
                return;
            }

            const { id } = req.params;
            if (!id) {
                res.status(400).json({ error: "ID inválido" });
                return;
            }

            await prisma.treinamento.delete({ where: { id } });
            res.json({ message: 'Registro removido.' });
        } catch (error) {
            next(error);
        }
    }
}