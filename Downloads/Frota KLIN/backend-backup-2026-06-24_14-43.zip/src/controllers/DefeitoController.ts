import { Request, Response, NextFunction } from 'express';
import { prisma } from '../lib/prisma';
import { AuthenticatedRequest } from '../middleware/auth';
import { Prisma } from '@prisma/client';
import { registrarDefeitoSchema, resolverDefeitoSchema } from '../schemas/defeito.schemas';
import { z } from 'zod';

type RegistrarDefeitoData = z.infer<typeof registrarDefeitoSchema>['body'];
type ResolverDefeitoData = z.infer<typeof resolverDefeitoSchema>['body'];

export class DefeitoController {
  
  /**
   * Lista defeitos. Operador vê só os dele; Admin/Encarregado vê todos.
   */
  index = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      const { status, veiculoId } = req.query;
      const user = req.user;

      if (!user) {
        res.status(401).json({ error: 'Não autenticado' });
        return;
      }

      const where: Prisma.DefeitoVeiculoWhereInput = {};

      if (status) where.status = status as any;
      if (veiculoId) where.veiculoId = veiculoId as string;

      // Restringe exibição para operadores (só veem os próprios)
      if (user.role === 'OPERADOR') {
        where.operadorId = user.userId;
      }

      const defeitos = await prisma.defeitoVeiculo.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        include: {
          veiculo: { select: { id: true, placa: true, modelo: true } },
          operador: { select: { id: true, nome: true } },
          resolvidoPor: { select: { id: true, nome: true } },
        },
      });

      res.json(defeitos);
    } catch (error) {
      next(error);
    }
  };

  /**
   * Obtém detalhes de um defeito específico.
   * 🛡️ IDOR Protection: Operador só vê os próprios defeitos.
   */
  getById = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const user = req.user;

      if (!user) {
        res.status(401).json({ error: 'Não autenticado' });
        return;
      }

      const defeito = await prisma.defeitoVeiculo.findUnique({
        where: { id },
        include: {
          veiculo: { select: { id: true, placa: true, modelo: true } },
          operador: { select: { id: true, nome: true } },
          resolvidoPor: { select: { id: true, nome: true } },
        },
      });

      if (!defeito) {
        res.status(404).json({ error: 'Registro de defeito não encontrado.' });
        return;
      }

      // Restrição de acesso para operadores
      if (user.role === 'OPERADOR' && defeito.operadorId !== user.userId) {
        res.status(403).json({ error: 'Acesso negado. Você não tem permissão para visualizar este registro.' });
        return;
      }

      res.json(defeito);
    } catch (error) {
      next(error);
    }
  };

  /**
   * Conta defeitos não resolvidos (Aberto ou Em Análise) para o painel de alerta (somente Admin/Encarregado)
   */
  countAtivos = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
         if (!['ADMIN', 'ENCARREGADO'].includes(req.user?.role || '')) {
             res.status(403).json({ error: 'Acesso negado' });
             return;
         }

         const contagem = await prisma.defeitoVeiculo.count({
             where: {
                 status: { in: ['ABERTO', 'EM_ANALISE'] }
             }
         });

         res.json({ count: contagem });
    } catch (error) {
        next(error);
    }
  }

  /**
   * Cria novo registro de defeito (comum a Operadores/Encarregados).
   */
  create = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      const dados = req.body as RegistrarDefeitoData;
      const user = req.user;

      if (!user) {
        res.status(401).json({ error: 'Não autenticado' });
        return;
      }

      // Verifica se Veículo existe
      const veiculoExistente = await prisma.veiculo.findUnique({ where: { id: dados.veiculoId } });
      if (!veiculoExistente) {
        res.status(404).json({ error: 'Veículo não encontrado' });
        return;
      }

      const novoDefeito = await prisma.defeitoVeiculo.create({
        data: {
          veiculoId: dados.veiculoId,
          descricao: dados.descricao,
          categoria: dados.categoria,
          fotoUrl: dados.fotoUrl,
          operadorId: user.userId, // Pega o usuário da request autenticada (JWT lock)
          status: 'ABERTO',
        },
        include: {
          veiculo: { select: { placa: true, modelo: true } },
          operador: { select: { nome: true } },
        },
      });

      res.status(201).json(novoDefeito);
    } catch (error) {
      next(error);
    }
  };

  /**
   * Encarregado marca o defeito como EM ANÁLISE (já está verificando)
   */
  setEmAnalise = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      if (!['ADMIN', 'ENCARREGADO'].includes(req.user?.role || '')) {
        res.status(403).json({ error: 'Acesso negado' });
        return;
      }

      const { id } = req.params;

      const atualizado = await prisma.defeitoVeiculo.update({
        where: { id },
        data: { status: 'EM_ANALISE' },
      });

      res.json(atualizado);
    } catch (error) {
      next(error);
    }
  };

  /**
   * Encarregado resolve o reparo e encerra o problema.
   */
  resolver = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      if (!['ADMIN', 'ENCARREGADO'].includes(req.user?.role || '')) {
        res.status(403).json({ error: 'Acesso negado' });
        return;
      }

      const { id } = req.params;
      const user = req.user!;
      const dados = req.body as ResolverDefeitoData;

      const atualizado = await prisma.defeitoVeiculo.update({
        where: { id },
        data: {
          status: 'RESOLVIDO',
          resolucao: dados.resolucao || null,
          resolvidoPorId: user.userId,
          resolvidoEm: new Date(),
        },
        include: { resolvidoPor: { select: { nome: true } } },
      });

      res.json(atualizado);
    } catch (error) {
      next(error);
    }
  };
}
