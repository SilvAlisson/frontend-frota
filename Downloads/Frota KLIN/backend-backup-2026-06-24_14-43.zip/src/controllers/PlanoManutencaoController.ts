import { Request, Response, NextFunction } from 'express';
import { prisma } from '../lib/prisma';
import { Prisma } from '@prisma/client';
import { KmService } from '../services/KmService';
import { AuthenticatedRequest } from '../middleware/auth';
import { z } from 'zod';
import { planoManutencaoSchema } from '../schemas/planoManutencao.schemas';

// Extraímos a tipagem do schema
type CreatePlanoData = z.infer<typeof planoManutencaoSchema>['body'];

export class PlanoManutencaoController {

    create = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            // ATUALIZAÇÃO: Permite ENCARREGADO e COORDENADOR criarem planos
            if (!['ADMIN', 'ENCARREGADO', 'COORDENADOR'].includes(req.user?.role || '')) {
                res.status(403).json({ error: 'Acesso negado. Apenas gestão pode criar planos.' });
                return;
            }

            // req.body já validado e tipado pelo middleware
            const { veiculoId, descricao, tipoIntervalo, valorIntervalo } = req.body as CreatePlanoData;

            // Busca KM atual para cálculo
            const kmAtual = await KmService.getUltimoKMRegistrado(veiculoId);

            let kmProximaManutencao: number | null = null;
            let dataProximaManutencao: Date | null = null;

            // Lógica de Negócio: Calcular vencimento
            if (tipoIntervalo === 'KM') {
                if (valorIntervalo > 0) {
                    // Lógica de Múltiplos (Ex: 20, 40, 60...)
                    // Se kmAtual = 111.405 e intervalo = 20.000:
                    // 111.405 / 20.000 = 5.57 -> Floor = 5
                    // (5 + 1) * 20.000 = 120.000 KM (Próxima revisão correta)
                    const multiplicador = Math.floor(kmAtual / valorIntervalo) + 1;
                    kmProximaManutencao = multiplicador * valorIntervalo;
                } else {
                    kmProximaManutencao = kmAtual; // Segurança contra divisão por zero
                }
            } else if (tipoIntervalo === 'TEMPO') {
                const data = new Date();
                // valorIntervalo já é number aqui
                data.setMonth(data.getMonth() + valorIntervalo);
                dataProximaManutencao = data;
            }

            const plano = await prisma.planoManutencao.create({
                data: {
                    veiculoId,
                    descricao,
                    tipoIntervalo,
                    valorIntervalo,
                    kmProximaManutencao,
                    dataProximaManutencao,
                },
                include: {
                    veiculo: {
                        select: { placa: true, modelo: true }
                    }
                }
            });

            res.status(201).json(plano);
        } catch (error) {
            next(error);
        }
    }

    list = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            const { veiculoId } = req.query;
            const userRole = req.user?.role || '';

            let whereClause: Prisma.PlanoManutencaoWhereInput = {};

            // 1. Se tem veiculoId na URL, filtra por ele (Contexto do Operador)
            if (veiculoId) {
                whereClause.veiculoId = String(veiculoId);
            }
            // 2. Se NÃO tem veiculoId...
            else {
                // ...e é OPERADOR, bloqueia (ele não pode ver a frota toda)
                if (userRole === 'OPERADOR') {
                    res.status(400).json({ error: 'Operadores precisam especificar um veículo.' });
                    return;
                }
                // Admin/Encarregado/Coordenador veem tudo se não especificarem veículo
            }

            const planos = await prisma.planoManutencao.findMany({
                where: whereClause,
                include: {
                    veiculo: {
                        select: { placa: true, modelo: true, ultimoKm: true }
                    },
                    historicoExecucoes: {
                        orderBy: { dataExecucao: 'desc' },
                        take: 3,
                        include: { registradoPor: { select: { nome: true } } }
                    }
                },
                orderBy: [
                    // Ordena por data mais próxima ou km mais próximo para dar urgência
                    { dataProximaManutencao: 'asc' },
                    { kmProximaManutencao: 'asc' }
                ]
            });
            res.json(planos);
        } catch (error) {
            next(error);
        }
    }

    delete = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            // ATUALIZAÇÃO: Permite ENCARREGADO e COORDENADOR deletarem planos
            if (!['ADMIN', 'ENCARREGADO', 'COORDENADOR'].includes(req.user?.role || '')) {
                res.status(403).json({ error: 'Acesso negado.' });
                return;
            }

            const { id } = req.params;
            if (!id) {
                res.status(400).json({ error: 'ID do plano não fornecido.' });
                return;
            }

            await prisma.planoManutencao.delete({
                where: { id }
            });
            res.status(204).send();
        } catch (error) {
            next(error);
        }
    }

    // ✨ NOVO: O Clique Interativo "Manutenção Realizada"
    registrarExecucao = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            if (!['ADMIN', 'ENCARREGADO', 'COORDENADOR'].includes(req.user?.role || '')) {
                res.status(403).json({ error: 'Acesso negado.' });
                return;
            }

            const { id } = req.params;
            const { kmDaBaixa, observacao } = req.body; 
            const registradoPorId = req.user?.userId;

            if (!registradoPorId) {
                return res.status(401).json({ error: 'Usuário não identificado.' });
            }

            const plano = await prisma.planoManutencao.findUnique({ where: { id } });
            if (!plano) {
                return res.status(404).json({ error: 'Plano não encontrado.' });
            }

            const atualizado = await prisma.$transaction(async (tx) => {
                // 1. Gera Histórico de Auditoria para o futuro
                await tx.historicoPlanoManutencao.create({
                    data: {
                        planoManutencaoId: id,
                        registradoPorId,
                        kmNaExecucao: kmDaBaixa ? Number(kmDaBaixa) : undefined,
                        observacao: observacao || undefined
                    }
                });

                // 2. Transfere Alvo pro prõximo ciclo (Seja KM ou DATA)
                let dataUpdate: Prisma.PlanoManutencaoUpdateInput = {};
                
                if (plano.tipoIntervalo === 'KM') {
                    // Se deram baixa fora da hora, o KM base é o que preencheram. Senão usa a atual meta.
                    const baseCalculo = kmDaBaixa ? Number(kmDaBaixa) : plano.kmProximaManutencao;
                    dataUpdate.kmProximaManutencao = (baseCalculo || 0) + plano.valorIntervalo;
                } else {
                    // Se é TEMPO (Em meses)
                    const baseCalculo = new Date();
                    baseCalculo.setMonth(baseCalculo.getMonth() + plano.valorIntervalo);
                    dataUpdate.dataProximaManutencao = baseCalculo;
                }

                return await tx.planoManutencao.update({
                    where: { id },
                    data: dataUpdate,
                    include: { 
                        veiculo: { select: { placa: true, modelo: true, ultimoKm: true } },
                        historicoExecucoes: { orderBy: { dataExecucao: 'desc' }, take: 3 }
                    }
                });
            });

            res.json(atualizado);
        } catch (error) {
            next(error);
        }
    }
}