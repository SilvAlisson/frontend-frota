import { Request, Response, NextFunction } from 'express';
import { prisma } from '../lib/prisma';
import { KmService } from '../services/KmService';
import { AuthenticatedRequest } from '../middleware/auth';
import { Prisma } from '@prisma/client';
import { z } from 'zod';
import { abastecimentoSchema } from '../schemas/operacao.schemas';

type AbastecimentoData = z.infer<typeof abastecimentoSchema>['body'];

export class AbastecimentoController {

    /**
     * Registra um novo abastecimento.
     */
    create = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            if (!['ADMIN', 'ENCARREGADO'].includes(req.user?.role || '')) {
                res.status(403).json({ error: 'Acesso negado. Apenas Gestores podem lançar abastecimentos.' });
                return;
            }

            const dados = req.body as AbastecimentoData;

            const veiculo = await prisma.veiculo.findUnique({ where: { id: dados.veiculoId } });
            if (!veiculo) {
                res.status(404).json({ error: "Veículo não encontrado." });
                return;
            }

            // 🔥 PERFORMANCE OPTIMIZER: 007 Clean Code - Fix N+1 Queries
            // Busca todos os produtos de uma única vez em vez de um por um em loop.
            const produtoIds = [...new Set(dados.itens.map(i => i.produtoId))];
            const produtosDetalhados = await prisma.produto.findMany({
                where: { id: { in: produtoIds } }
            });

            const produtosMap = new Map(produtosDetalhados.map(p => [p.id, p]));

            const combustivelErrado = dados.itens.find(item => {
                const produto = produtosMap.get(item.produtoId);
                if (produto?.tipo !== 'COMBUSTIVEL') return false;
                
                const nomeProduto = produto.nome.toUpperCase();
                const tipoVeiculo = veiculo.tipoCombustivel;

                if (tipoVeiculo === 'DIESEL_S10' && (nomeProduto.includes('GASOLINA') || nomeProduto.includes('ETANOL'))) return true;
                if ((['GASOLINA_COMUM', 'ETANOL', 'GNV'].includes(tipoVeiculo)) && nomeProduto.includes('DIESEL')) return true;
                return false;
            });

            if (combustivelErrado) {
                const pNome = produtosMap.get(combustivelErrado.produtoId)?.nome;
                res.status(400).json({ error: `Bloqueio: Veículo ${veiculo.tipoCombustivel} incompatível com ${pNome}.` });
                return;
            }

            // =================================================================================
            // 🚨 CORREÇÃO DE LÓGICA: Validação de Retroativo (Regra de Ouro)
            // =================================================================================
            const ultimoKM = await KmService.getUltimoKMRegistrado(dados.veiculoId);
            // Se o KM digitado for menor ou igual ao atual, é retroativo.
            const isRetroativo = dados.kmOdometro <= ultimoKM;

            if (isRetroativo) {
                console.warn(`[Abastecimento] Registro Retroativo: KM informado (${dados.kmOdometro}) <= Atual (${ultimoKM}). Mantendo odômetro atual.`);
            }

            // CÁLCULOS
            let custoTotalGeral = 0;
            const itensParaCriar = dados.itens.map((item) => {
                const total = item.quantidade * item.valorPorUnidade;
                custoTotalGeral += total;
                return {
                    produtoId: item.produtoId,
                    quantidade: item.quantidade,
                    valorPorUnidade: item.valorPorUnidade,
                    valorTotal: Number(total.toFixed(2)),
                };
            });
            custoTotalGeral = Number(custoTotalGeral.toFixed(2));

            // REGRA DE OURO (NOVA): Abastecimentos >= R$ 2000 ficam retidos para avaliação
            const statusInicial = custoTotalGeral >= 2000 ? 'PENDENTE_AVALIACAO' : 'APROVADO';

            const novoAbastecimento = await prisma.$transaction(async (tx) => {
                // 1. Cria o Abastecimento
                const abastecimento = await tx.abastecimento.create({
                    data: {
                        veiculo: { connect: { id: dados.veiculoId } },
                        operador: { connect: { id: dados.operadorId } },
                        fornecedor: { connect: { id: dados.fornecedorId } },
                        kmOdometro: dados.kmOdometro,
                        dataHora: dados.dataHora,
                        custoTotal: custoTotalGeral,
                        placaCartaoUsado: dados.placaCartaoUsado ?? null,
                        observacoes: dados.observacoes ?? null,
                        justificativa: dados.justificativa ?? null,
                        fotoNotaFiscalUrl: dados.fotoNotaFiscalUrl ?? null,
                        status: statusInicial,
                        itens: { create: itensParaCriar },
                    },
                    include: { itens: { include: { produto: true } } },
                });

                // 2. Lógica de Atualização do Veículo (Regra de Ouro)
                // Se estiver PENDENTE, nós NÃO atualizamos o veículo oficial AINDA.
                if (statusInicial === 'APROVADO') {
                    if (!isRetroativo) {
                        // SE FOR AVANÇO: Atualiza o veículo e histórico via Service
                        await KmService.registrarKm(dados.veiculoId, dados.kmOdometro, 'ABASTECIMENTO', abastecimento.id, tx);
                    } else {
                        // SE FOR RETROATIVO: Cria apenas o histórico para auditoria, SEM atualizar o veículo
                        await tx.historicoKm.create({
                            data: {
                                veiculoId: dados.veiculoId,
                                km: dados.kmOdometro,
                                origem: 'ABASTECIMENTO',
                                origemId: abastecimento.id,
                                dataLeitura: new Date()
                            }
                        });
                    }
                }

                return abastecimento;
            });

            res.status(201).json(novoAbastecimento);
        } catch (error: any) {
            // Tratamento de erro mais amigável
            if (error.message && (error.message.includes('Bloqueio') || error.message.includes('Erro'))) {
                 res.status(400).json({ error: error.message });
            } else {
                 next(error);
            }
        }
    }

    /**
     * Busca por ID.
     */
    getById = async (req: Request, res: Response, next: NextFunction) => {
        try {
            const { id } = req.params;

            if (!id) {
                res.status(400).json({ error: 'ID inválido.' });
                return;
            }

            const abastecimento = await prisma.abastecimento.findUnique({
                where: { id },
                include: {
                    veiculo: { select: { id: true, placa: true, modelo: true } },
                    operador: { select: { id: true, nome: true } },
                    fornecedor: { select: { id: true, nome: true } },
                    itens: { include: { produto: { select: { id: true, nome: true, tipo: true } } } }
                }
            });

            if (!abastecimento) {
                res.status(404).json({ error: 'Abastecimento não encontrado.' });
                return;
            }

            res.json(abastecimento);
        } catch (error) {
            next(error);
        }
    }

    /**
     * Atualização.
     */
    update = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            if (!['ADMIN', 'ENCARREGADO'].includes(req.user?.role || '')) {
                res.status(403).json({ error: 'Acesso negado.' });
                return;
            }

            const { id } = req.params;

            if (!id) {
                res.status(400).json({ error: 'ID é obrigatório.' });
                return;
            }

            const dados = req.body as AbastecimentoData;

            const existente = await prisma.abastecimento.findUnique({ where: { id } });
            if (!existente) {
                res.status(404).json({ error: 'Registro não encontrado.' });
                return;
            }

            // Verifica KM atual para decidir a atualização
            const ultimoKM = await KmService.getUltimoKMRegistrado(dados.veiculoId);
            // Verifica se o NOVO valor é retroativo em relação ao carro
            const isRetroativo = dados.kmOdometro <= ultimoKM;

            // BLINDAGEM DE COMBUSTÍVEL
            const veiculo = await prisma.veiculo.findUnique({ where: { id: dados.veiculoId } });
            if (veiculo) {
                const itensComDetalhes = await Promise.all(dados.itens.map(async (item) => {
                    const produto = await prisma.produto.findUnique({ where: { id: item.produtoId } });
                    return { ...item, produto };
                }));

                const combustivelErrado = itensComDetalhes.find(item => {
                    if (item.produto?.tipo !== 'COMBUSTIVEL') return false;
                    const nomeProduto = item.produto.nome.toUpperCase();
                    const tipoVeiculo = veiculo.tipoCombustivel;

                    if (tipoVeiculo === 'DIESEL_S10' && (nomeProduto.includes('GASOLINA') || nomeProduto.includes('ETANOL'))) return true;
                    if ((['GASOLINA_COMUM', 'ETANOL', 'GNV'].includes(tipoVeiculo)) && nomeProduto.includes('DIESEL')) return true;
                    return false;
                });

                if (combustivelErrado) {
                    res.status(400).json({ error: `Bloqueio: Veículo ${veiculo.tipoCombustivel} incompatível com ${combustivelErrado.produto?.nome}.` });
                    return;
                }
            }

            let custoTotalGeral = 0;
            const itensParaCriar = dados.itens.map((item) => {
                const total = item.quantidade * item.valorPorUnidade;
                custoTotalGeral += total;
                return {
                    produtoId: item.produtoId,
                    quantidade: item.quantidade,
                    valorPorUnidade: item.valorPorUnidade,
                    valorTotal: Number(total.toFixed(2)),
                };
            });
            custoTotalGeral = Number(custoTotalGeral.toFixed(2));

            const atualizado = await prisma.$transaction(async (tx) => {
                await tx.itemAbastecimento.deleteMany({
                    where: { abastecimentoId: id }
                });

                const abs = await tx.abastecimento.update({
                    where: { id },
                    data: {
                        veiculoId: dados.veiculoId,
                        operadorId: dados.operadorId,
                        fornecedorId: dados.fornecedorId,
                        kmOdometro: dados.kmOdometro,
                        dataHora: dados.dataHora,
                        custoTotal: custoTotalGeral,
                        placaCartaoUsado: dados.placaCartaoUsado ?? null,
                        justificativa: dados.justificativa ?? null,
                        observacoes: dados.observacoes ?? null,
                        status: req.body.status || existente.status, // Permite ADMIN aprovar
                        itens: { create: itensParaCriar }
                    },
                    include: { itens: { include: { produto: true } } }
                });

                // REGRA DE OURO NA EDIÇÃO:
                // Se o KM mudou ou o status passou para APROVADO, avaliamos o KM
                const foiAprovadoAgora = existente.status === 'PENDENTE_AVALIACAO' && req.body.status === 'APROVADO';
                
                if ((dados.kmOdometro !== existente.kmOdometro || foiAprovadoAgora) && abs.status === 'APROVADO') {
                    if (!isRetroativo) {
                        // É um avanço -> Atualiza tudo
                        await KmService.registrarKm(dados.veiculoId, dados.kmOdometro, 'ABASTECIMENTO', abs.id, tx);
                    } else {
                        // É retroativo -> Cria apenas registro de auditoria, preservando o KM atual do veículo
                        await tx.historicoKm.create({
                            data: {
                                veiculoId: dados.veiculoId,
                                km: dados.kmOdometro,
                                origem: 'ABASTECIMENTO',
                                origemId: abs.id,
                                dataLeitura: new Date()
                            }
                        });
                    }
                }

                return abs;
            });

            res.json(atualizado);

        } catch (error) {
            next(error);
        }
    }

    listRecent = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            if (!['ADMIN', 'ENCARREGADO'].includes(req.user?.role || '')) {
                res.status(403).json({ error: 'Acesso negado.' });
                return;
            }

            const { dataInicio, dataFim, veiculoId, limit, tipoProduto, status } = req.query;
            const where: Prisma.AbastecimentoWhereInput = {};

            // Oculta pendentes das listas normais (se não for admin explícito pedindo pendentes)
            if (status) {
                where.status = status as any;
            } else {
                where.status = 'APROVADO'; // Default apenas aprovados
            }

            if (dataInicio || dataFim) {
                const dateFilter: Prisma.DateTimeFilter = {};
                if (dataInicio && typeof dataInicio === 'string') dateFilter.gte = new Date(dataInicio);
                if (dataFim && typeof dataFim === 'string') {
                    const fim = new Date(dataFim);
                    fim.setDate(fim.getDate() + 1);
                    dateFilter.lt = fim;
                }
                if (Object.keys(dateFilter).length > 0) where.dataHora = dateFilter;
            }
            if (veiculoId && typeof veiculoId === 'string') where.veiculoId = veiculoId;
            if (tipoProduto && typeof tipoProduto === 'string') {
                where.itens = { some: { produto: { tipo: tipoProduto as any } } };
            }

            const findOptions: Prisma.AbastecimentoFindManyArgs = {
                where,
                orderBy: { dataHora: 'desc' },
                include: {
                    veiculo: { select: { id: true, placa: true, modelo: true } },
                    operador: { select: { nome: true } },
                    fornecedor: { select: { nome: true } },
                    itens: { include: { produto: { select: { nome: true, tipo: true } } } }
                }
            };
            if (limit !== 'all') findOptions.take = 50;

            let recentes = await prisma.abastecimento.findMany(findOptions);
            
            // Recálculo do custoTotal caso exista filtro de tipoProduto (Ex: Apenas Aditivos)
            if (tipoProduto && typeof tipoProduto === 'string') {
                recentes = recentes.map((ab: any) => {
                    const itensFiltrados = ab.itens ? ab.itens.filter((i: any) => i.produto.tipo === tipoProduto) : [];
                    const custoRecalculado = itensFiltrados.reduce((acc: number, curr: any) => acc + Number(curr.valorTotal), 0);
                    return {
                        ...ab,
                        custoTotal: custoRecalculado
                    };
                });
            }

            res.json(recentes);
        } catch (error) { next(error); }
    }

    delete = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            if (req.user?.role !== 'ADMIN') {
                res.status(403).json({ error: 'Apenas Admins.' });
                return;
            }

            const { id } = req.params;

            if (!id) {
                res.status(400).json({ error: 'ID inválido.' });
                return;
            }

            await prisma.$transaction(async (tx) => {
                const exists = await tx.abastecimento.findUnique({ where: { id } });
                if (!exists) throw new Error('Registro não encontrado');

                await tx.itemAbastecimento.deleteMany({ where: { abastecimentoId: id } });
                await tx.abastecimento.delete({ where: { id } });
            });
            res.json({ message: 'Removido.' });
        } catch (error) { next(error); }
    }
}