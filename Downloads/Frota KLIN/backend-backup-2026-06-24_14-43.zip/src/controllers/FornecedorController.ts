import { Request, Response, NextFunction } from 'express';
import { prisma } from '../lib/prisma';
import { Prisma } from '@prisma/client';
import { AuthenticatedRequest } from '../middleware/auth';
import { z } from 'zod';
import { fornecedorSchema } from '../schemas/fornecedor.schemas';

type FornecedorData = z.infer<typeof fornecedorSchema>['body'] & {
    produtosIds?: string[];
};

export class FornecedorController {

    create = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            if (req.user?.role !== 'ADMIN') {
                res.status(403).json({ error: 'Acesso negado' });
                return;
            }

            const { nome, cnpj, tipo, produtosIds } = req.body as FornecedorData;

            // SOLUÇÃO: Construímos o objeto de dados condicionalmente
            const dataToCreate: Prisma.FornecedorCreateInput = {
                nome,
                cnpj: cnpj ?? null,
                tipo,
                // O spread (...) abaixo só adiciona a chave se a condição for verdadeira.
                // Se for falsa, a chave 'produtosOferecidos' nem sequer é criada.
                ...(produtosIds && produtosIds.length > 0 ? {
                    produtosOferecidos: {
                        connect: produtosIds.map(id => ({ id }))
                    }
                } : {})
            };

            const fornecedor = await prisma.fornecedor.create({
                data: dataToCreate,
                include: {
                    produtosOferecidos: true
                }
            });

            res.status(201).json(fornecedor);
        } catch (error) {
            next(error);
        }
    }

    list = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            const list = await prisma.fornecedor.findMany({
                orderBy: { nome: 'asc' },
                include: {
                    produtosOferecidos: true
                }
            });
            res.json(list);
        } catch (error) {
            next(error);
        }
    }

    getById = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            const { id } = req.params;
            if (!id) {
                res.status(400).json({ error: 'ID inválido' });
                return;
            }

            const f = await prisma.fornecedor.findUnique({
                where: { id },
                include: {
                    produtosOferecidos: true
                }
            });

            if (!f) {
                res.status(404).json({ error: 'Não encontrado' });
                return;
            }
            res.json(f);
        } catch (error) {
            next(error);
        }
    }

    update = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            if (req.user?.role !== 'ADMIN') {
                res.status(403).json({ error: 'Acesso negado' });
                return;
            }

            const { id } = req.params;
            if (!id) {
                res.status(400).json({ error: 'ID inválido' });
                return;
            }

            const { nome, cnpj, tipo, produtosIds } = req.body as FornecedorData;

            // SOLUÇÃO: Mesma lógica aqui. Se produtosIds for undefined, não mexemos na relação.
            // Se for um array vazio [], o 'set: []' vai remover todas as conexões (correto).
            const dataToUpdate: Prisma.FornecedorUpdateInput = {
                nome,
                cnpj: cnpj ?? null,
                tipo,
                ...(produtosIds ? {
                    produtosOferecidos: {
                        set: produtosIds.map(id => ({ id }))
                    }
                } : {})
            };

            const updated = await prisma.fornecedor.update({
                where: { id },
                data: dataToUpdate,
                include: {
                    produtosOferecidos: true
                }
            });
            res.json(updated);
        } catch (error) {
            next(error);
        }
    }

    delete = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            if (req.user?.role !== 'ADMIN') {
                res.status(403).json({ error: 'Acesso negado' });
                return;
            }

            const { id } = req.params;
            if (!id) {
                res.status(400).json({ error: 'ID inválido' });
                return;
            }

            await prisma.fornecedor.delete({ where: { id } });
            res.json({ message: 'Removido com sucesso' });
        } catch (error) {
            next(error);
        }
    }

    listarParaOperacao = async (req: Request, res: Response, next: NextFunction) => {
        try {
            const fornecedores = await prisma.fornecedor.findMany({
                select: {
                    id: true,
                    nome: true,
                    tipo: true,
                    cnpj: true,
                    produtosOferecidos: {
                        select: {
                            id: true,
                            nome: true,
                            tipo: true
                        }
                    }
                },
                orderBy: { nome: 'asc' }
            });
            res.json(fornecedores);
        } catch (error) { next(error); }
    }
}