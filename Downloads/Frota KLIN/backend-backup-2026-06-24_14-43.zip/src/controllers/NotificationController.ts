import { Request, Response } from 'express';
import { NotificationService } from '../services/NotificationService';

const notificationService = new NotificationService();

export class NotificationController {
  
  public getVapidPublicKey = (req: Request, res: Response) => {
    res.json({ publicKey: process.env.VAPID_PUBLIC_KEY });
  };

  public subscribe = async (req: Request, res: Response) => {
    try {
      const subscription = req.body;
      const userId = (req as Request & { user?: { id: string } }).user?.id;

      if (!userId) {
        return res.status(401).json({ error: 'Não autorizado.' });
      }
      if (!subscription || !subscription.endpoint) {
        return res.status(400).json({ error: 'Subscription inválida.' });
      }

      await notificationService.subscribe(userId, subscription);
      res.status(201).json({ success: true, message: 'Inscrito com sucesso.' });
    } catch (error) {
      console.error('Erro no Push Subscribe:', error);
      res.status(500).json({ error: 'Erro interno ao assinar notificações.' });
    }
  };

  public unsubscribe = async (req: Request, res: Response) => {
    try {
      const { endpoint } = req.body;
      if (endpoint) {
        await notificationService.unsubscribe(endpoint);
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Erro ao desinscrever notificações.' });
    }
  };
}
