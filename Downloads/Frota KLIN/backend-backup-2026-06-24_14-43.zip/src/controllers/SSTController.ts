import { Request, Response } from 'express';
import { prisma } from '../lib/prisma';
import { Prisma } from '@prisma/client';
import { z } from 'zod';
import { AuthenticatedRequest } from '../middleware/auth';

// ─── Schemas de Validação ─────────────────────────────────────────────────────

const criarAcaoSSTSchema = z.object({
  acao: z.string().min(3, 'Descreva a ação com pelo menos 3 caracteres.'),
  unidade: z.string().min(1, 'Unidade é obrigatória.').default('CASE'),
  programa: z.enum(['PCA', 'PPR', 'AET', 'PGR'], { error: 'Programa inválido.' }),
  responsaveis: z.string().min(3, 'Informe o(s) responsável(is).'),
  vencimento: z.string().datetime({ offset: true }).or(z.string().regex(/^\d{4}-\d{2}-\d{2}$/)),
  realizado: z.string().optional().nullable(),
  observacao: z.string().optional().nullable(),
});

const atualizarAcaoSSTSchema = criarAcaoSSTSchema.partial().extend({
  status: z.enum(['PENDENTE', 'REALIZADO', 'ATRASADO']).optional(),
});

// ─── Controller ───────────────────────────────────────────────────────────────

export class SSTController {

  /** GET /api/sst — Lista todas as ações SST */
  async index(req: AuthenticatedRequest, res: Response) {
    try {
      const { programa, status } = req.query;

      const where: Prisma.AcaoSSTWhereInput = {};
      if (programa) where.programa = String(programa) as Prisma.EnumProgramaSSTFilter | "PCA" | "PPR" | "AET" | "PGR";
      if (status)   where.status  = String(status) as Prisma.EnumStatusAcaoSSTFilter | "PENDENTE" | "REALIZADO" | "ATRASADO";

      const acoes = await prisma.acaoSST.findMany({
        where,
        orderBy: { vencimento: 'asc' },
      });

      return res.json(acoes);
    } catch (error) {
      console.error('[SST] Erro ao listar ações:', error);
      return res.status(500).json({ error: 'Erro interno ao buscar ações de SST.' });
    }
  }

  /** GET /api/sst/:id — Busca uma ação específica */
  async show(req: AuthenticatedRequest, res: Response) {
    try {
      const acao = await prisma.acaoSST.findUnique({
        where: { id: req.params.id },
      });

      if (!acao) return res.status(404).json({ error: 'Ação não encontrada.' });
      return res.json(acao);
    } catch (error) {
      console.error('[SST] Erro ao buscar ação:', error);
      return res.status(500).json({ error: 'Erro ao buscar ação de SST.' });
    }
  }

  /** POST /api/sst — Cria nova ação */
  async create(req: AuthenticatedRequest, res: Response) {
    try {
      if (!['ADMIN', 'COORDENADOR', 'RH'].includes(req.user?.role || '')) {
        return res.status(403).json({ error: 'Acesso negado: Permissão insuficiente para gerenciar SST.' });
      }

      const data = criarAcaoSSTSchema.parse(req.body);

      const novaAcao = await prisma.acaoSST.create({
        data: {
          acao:         data.acao,
          unidade:      data.unidade,
          programa:     data.programa,
          responsaveis: data.responsaveis,
          vencimento:   new Date(data.vencimento),
          realizado:    data.realizado ?? null,
          observacao:   data.observacao ?? null,
          status:       'PENDENTE',
        },
      });

      return res.status(201).json(novaAcao);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Dados inválidos', errors: error.issues });
      }
      console.error('[SST] Erro ao criar ação:', error);
      return res.status(500).json({ error: 'Erro ao criar ação de SST.' });
    }
  }

  /** PUT /api/sst/:id — Atualiza ação existente */
  async update(req: AuthenticatedRequest, res: Response) {
    try {
      if (!['ADMIN', 'COORDENADOR', 'RH'].includes(req.user?.role || '')) {
        return res.status(403).json({ error: 'Acesso negado: Permissão insuficiente para gerenciar SST.' });
      }

      const data = atualizarAcaoSSTSchema.parse(req.body);

      const atualizado = await prisma.acaoSST.update({
        where: { id: req.params.id },
        data: {
          ...data,
          vencimento: data.vencimento ? new Date(data.vencimento) : undefined,
        },
      });

      return res.json(atualizado);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Dados inválidos', errors: error.issues });
      }
      console.error('[SST] Erro ao atualizar ação:', error);
      return res.status(500).json({ error: 'Erro ao atualizar ação de SST.' });
    }
  }

  /** DELETE /api/sst/:id — Remove ação */
  async delete(req: AuthenticatedRequest, res: Response) {
    try {
      if (!['ADMIN', 'COORDENADOR', 'RH'].includes(req.user?.role || '')) {
        return res.status(403).json({ error: 'Acesso negado: Permissão insuficiente para excluir SST.' });
      }

      await prisma.acaoSST.delete({ where: { id: req.params.id } });
      return res.status(204).send();
    } catch (error) {
      console.error('[SST] Erro ao deletar ação:', error);
      return res.status(500).json({ error: 'Erro ao remover ação de SST.' });
    }
  }
}
