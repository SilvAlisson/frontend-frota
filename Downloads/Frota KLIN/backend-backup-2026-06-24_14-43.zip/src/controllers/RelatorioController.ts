import { Response, NextFunction } from 'express';
import { prisma } from '../lib/prisma';
import { KmService } from '../services/KmService';
import { PrevisaoService } from '../services/PrevisaoService';
import { AuthenticatedRequest } from '../middleware/auth';
import { addDays } from '../utils/dateUtils';
import { z } from 'zod';
import { relatorioQuerySchema } from '../schemas/relatorio.schemas';

// Extraímos a tipagem do schema (Query Params)
type RelatorioQuery = z.infer<typeof relatorioQuerySchema>['query'];

interface Alerta {
    tipo: 'DOCUMENTO' | 'MANUTENCAO' | 'VEICULO_OCIOSO' | 'OPERADOR_OCIOSO' | 'SST' | 'TENTATIVA_FRAUDE' | 'ERRO_SISTEMA';
    nivel: 'VENCIDO' | 'ATENCAO' | 'PROJETADO';
    mensagem: string;
    veiculoId?: string;
    usuarioId?: string;
    logId?: string;
}

export class RelatorioController {

    /**
     * EVOLUÇÃO DE KM (Para Gráficos)
     * Busca a progressão do odômetro do veículo nos últimos X dias.
     */
    getEvolucaoKm = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            const { veiculoId, dias } = req.query;
            const diasNum = Number(dias) || 7;

            if (!veiculoId) {
                return res.status(400).json({ error: 'ID do veículo é obrigatório.' });
            }

            const dataLimite = new Date();
            dataLimite.setDate(dataLimite.getDate() - diasNum);

            // 1. Busca o histórico no período solicitado
            const historico = await prisma.historicoKm.findMany({
                where: {
                    veiculoId: veiculoId as string,
                    dataLeitura: { gte: dataLimite }
                },
                orderBy: { dataLeitura: 'asc' }
            });

            // 2. INTELIGÊNCIA: Se não houver dados nos últimos dias, buscamos a última leitura disponível
            // para que o gráfico não fique totalmente vazio e o sistema tenha uma referência.
            if (historico.length === 0) {
                const ultimaLeitura = await prisma.historicoKm.findFirst({
                    where: { veiculoId: veiculoId as string },
                    orderBy: { dataLeitura: 'desc' }
                });

                if (ultimaLeitura) {
                    return res.json([{
                        data: new Date(ultimaLeitura.dataLeitura).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }),
                        km: ultimaLeitura.km
                    }]);
                }
                return res.json([]);
            }

            // 3. Agrupamento: pega o maior KM registrado em cada dia
            const dadosAgrupados = historico.reduce((acc: Record<string, number>, curr) => {
                const dataLabel = new Date(curr.dataLeitura).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });

                if (!acc[dataLabel] || curr.km > acc[dataLabel]) {
                    acc[dataLabel] = curr.km;
                }
                return acc;
            }, {});

            const dadosFormatados = Object.keys(dadosAgrupados).map(data => ({
                data,
                km: dadosAgrupados[data]
            }));

            res.json(dadosFormatados);
        } catch (error) {
            console.error("Erro em getEvolucaoKm:", error);
            next(error);
        }
    }

    /**
     * SUMÁRIO EXECUTIVO (KPIs)
     * Consolida custos de combustível, aditivos, manutenção e eficiência.
     */
    sumario = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            if (req.user?.role !== 'ADMIN' && req.user?.role !== 'ENCARREGADO') {
                res.status(403).json({ error: 'Acesso negado' });
                return;
            }

            const { ano, mes, veiculoId } = req.query as unknown as RelatorioQuery;
            const anoNum = Number(ano) || new Date().getFullYear();
            const mesNum = Number(mes) || new Date().getMonth() + 1;

            const dataInicio = new Date(anoNum, mesNum - 1, 1);
            const dataFim = new Date(anoNum, mesNum, 1);

            const filtroData = { gte: dataInicio, lt: dataFim };
            const filtroVeiculo = veiculoId ? { veiculoId } : {};

            const [combustivel, aditivo, manutencao, litros, jornadas] = await Promise.all([
                prisma.itemAbastecimento.aggregate({
                    _sum: { valorTotal: true },
                    where: {
                        produto: { tipo: 'COMBUSTIVEL' },
                        abastecimento: { dataHora: filtroData, ...filtroVeiculo }
                    }
                }),
                prisma.itemAbastecimento.aggregate({
                    _sum: { valorTotal: true },
                    where: {
                        produto: { tipo: 'ADITIVO' },
                        abastecimento: { dataHora: filtroData, ...filtroVeiculo }
                    }
                }),
                prisma.ordemServico.aggregate({
                    _sum: { custoTotal: true },
                    where: { data: filtroData, ...filtroVeiculo }
                }),
                prisma.itemAbastecimento.aggregate({
                    _sum: { quantidade: true },
                    where: {
                        produto: { tipo: 'COMBUSTIVEL' },
                        abastecimento: { dataHora: filtroData, ...filtroVeiculo }
                    }
                }),
                prisma.jornada.findMany({
                    where: { dataInicio: filtroData, kmFim: { not: null }, ...filtroVeiculo },
                    select: { kmInicio: true, kmFim: true }
                })
            ]);

            const kmTotal = jornadas.reduce((acc, j) => acc + ((j.kmFim ?? 0) - j.kmInicio), 0);

            // Conversão garantida para Number para evitar problemas de serialização Decimal
            const totalCombustivel = Number(combustivel._sum.valorTotal || 0);
            const totalAditivo = Number(aditivo._sum.valorTotal || 0);
            const totalManutencao = Number(manutencao._sum.custoTotal || 0);
            const litrosTotal = Number(litros._sum.quantidade || 0);
            const totalGeral = totalCombustivel + totalAditivo + totalManutencao;

            res.json({
                kpis: {
                    custoTotalGeral: totalGeral,
                    custoTotalCombustivel: totalCombustivel,
                    custoTotalAditivo: totalAditivo,
                    custoTotalManutencao: totalManutencao,
                    kmTotalRodado: kmTotal,
                    litrosTotaisConsumidos: litrosTotal,
                    consumoMedioKML: litrosTotal > 0 ? kmTotal / litrosTotal : 0,
                    custoMedioPorKM: kmTotal > 0 ? totalGeral / kmTotal : 0,
                }
            });
        } catch (e) { next(e); }
    }

    /**
     * RANKING DE VEÍCULOS (NOVO)
     * Calcula eficiência (KM/L) agrupada por veículo, independente do condutor.
     */
    rankingVeiculos = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            if (req.user?.role !== 'ADMIN' && req.user?.role !== 'ENCARREGADO') {
                res.status(403).json({ error: 'Acesso negado' });
                return;
            }

            const { ano, mes } = req.query as unknown as RelatorioQuery;
            const anoNum = Number(ano) || new Date().getFullYear();
            const mesNum = Number(mes) || new Date().getMonth() + 1;

            const dataInicio = new Date(anoNum, mesNum - 1, 1);
            const dataFim = new Date(anoNum, mesNum, 1);

            // Buscas paralelas para performance
            const [jornadas, abastecimentos, veiculos] = await Promise.all([
                // 1. Busca KM rodado por veículo no período
                prisma.jornada.findMany({
                    where: {
                        dataInicio: { gte: dataInicio, lt: dataFim },
                        kmFim: { not: null }
                    },
                    select: { veiculoId: true, kmInicio: true, kmFim: true }
                }),
                // 2. Busca litros abastecidos por veículo no período
                prisma.itemAbastecimento.findMany({
                    where: {
                        produto: { tipo: 'COMBUSTIVEL' },
                        abastecimento: { dataHora: { gte: dataInicio, lt: dataFim } }
                    },
                    select: {
                        quantidade: true,
                        abastecimento: { select: { veiculoId: true } }
                    }
                }),
                // 3. Busca detalhes dos veículos
                prisma.veiculo.findMany({
                    where: { status: { not: 'INATIVO' } },
                    select: { id: true, placa: true, modelo: true }
                })
            ]);

            // Processamento em Memória (Map Reduce)
            const kmsPorVeiculo = new Map<string, number>();
            jornadas.forEach(j => {
                const km = (j.kmFim ?? 0) - j.kmInicio;
                if (km > 0) {
                    kmsPorVeiculo.set(j.veiculoId, (kmsPorVeiculo.get(j.veiculoId) || 0) + km);
                }
            });

            const litrosPorVeiculo = new Map<string, number>();
            abastecimentos.forEach(item => {
                const vId = item.abastecimento.veiculoId;
                litrosPorVeiculo.set(vId, (litrosPorVeiculo.get(vId) || 0) + Number(item.quantidade));
            });

            // Montagem do Resultado
            const rankingData = veiculos.map(v => {
                const km = kmsPorVeiculo.get(v.id) || 0;
                const litros = litrosPorVeiculo.get(v.id) || 0;

                // Evita divisão por zero
                const kml = litros > 0 ? km / litros : 0;

                return {
                    id: v.id,
                    placa: v.placa,
                    modelo: v.modelo,
                    totalKM: km,
                    totalLitros: litros,
                    kml: kml
                };
            })
            // Filtra veículos sem atividade para não poluir o ranking
            .filter(r => r.totalKM > 0 || r.totalLitros > 0)
            // Ordena do mais eficiente para o menos eficiente
            .sort((a, b) => b.kml - a.kml);

            res.json(rankingData);
        } catch (error) { next(error); }
    }

    /**
     * RANKING DE OPERADORES
     * Calcula eficiência (KM/L) individual por motorista.
     */
    ranking = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            if (req.user?.role !== 'ADMIN' && req.user?.role !== 'ENCARREGADO') {
                res.status(403).json({ error: 'Acesso negado' });
                return;
            }

            const { ano, mes } = req.query as unknown as RelatorioQuery;
            const anoNum = Number(ano) || new Date().getFullYear();
            const mesNum = Number(mes) || new Date().getMonth() + 1;

            const dataInicio = new Date(anoNum, mesNum - 1, 1);
            const dataFim = new Date(anoNum, mesNum, 1);

            const [jornadas, abastecimentos, operadores] = await Promise.all([
                prisma.jornada.findMany({
                    where: { dataInicio: { gte: dataInicio, lt: dataFim }, kmFim: { not: null } },
                    select: { operadorId: true, kmInicio: true, kmFim: true }
                }),
                prisma.itemAbastecimento.findMany({
                    where: {
                        produto: { tipo: 'COMBUSTIVEL' },
                        abastecimento: { dataHora: { gte: dataInicio, lt: dataFim } }
                    },
                    select: {
                        quantidade: true,
                        abastecimento: { select: { operadorId: true } }
                    }
                }),
                prisma.user.findMany({
                    where: { role: 'OPERADOR' },
                    select: { id: true, nome: true }
                })
            ]);

            const kmsPorOperador = new Map<string, number>();
            jornadas.forEach(j => {
                const km = (j.kmFim ?? 0) - j.kmInicio;
                if (km > 0) kmsPorOperador.set(j.operadorId, (kmsPorOperador.get(j.operadorId) || 0) + km);
            });

            const litrosPorOperador = new Map<string, number>();
            abastecimentos.forEach(item => {
                const opId = item.abastecimento.operadorId;
                litrosPorOperador.set(opId, (litrosPorOperador.get(opId) || 0) + Number(item.quantidade));
            });

            const rankingData = operadores.map(op => {
                const km = kmsPorOperador.get(op.id) || 0;
                const litros = litrosPorOperador.get(op.id) || 0;
                return {
                    id: op.id,
                    nome: op.nome,
                    totalKM: km,
                    totalLitros: litros,
                    kml: litros > 0 ? km / litros : 0
                };
            }).filter(r => r.totalKM > 0 || r.totalLitros > 0).sort((a, b) => b.kml - a.kml);

            res.json(rankingData);
        } catch (error) { next(error); }
    }

    /**
     * ALERTAS GERAIS (Documentação e Previsão Inteligente de Manutenção)
     */
    alertas = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            if (!['ADMIN', 'ENCARREGADO', 'RH'].includes(req.user?.role || '')) {
                res.status(403).json({ error: 'Acesso negado' });
                return;
            }

            const alertas: Alerta[] = [];
            const hoje = new Date();
            const dataLimite = addDays(hoje, 30);
            const limiteAlertaKM = 1500;

            // PERFORMANCE: Cache do KM atual dos veículos para evitar N+1 buscas
            const veiculosBase = await prisma.veiculo.findMany({ 
                where: { status: { not: 'INATIVO' } },
                select: { id: true, ultimoKm: true } 
            });
            const kmMap = new Map(veiculosBase.map(v => [v.id, v.ultimoKm || 0]));

            // 1. ALERTAS DE DOCUMENTOS (CIV e CIPP)
            const veiculosDocs = await prisma.veiculo.findMany({
                where: { 
                    status: { not: 'INATIVO' },
                    OR: [{ vencimentoCiv: { lte: dataLimite } }, { vencimentoCipp: { lte: dataLimite } }] 
                },
                select: { id: true, placa: true, vencimentoCiv: true, vencimentoCipp: true }
            });

            veiculosDocs.forEach(v => {
                if (v.vencimentoCiv && v.vencimentoCiv <= dataLimite) {
                    const vencido = v.vencimentoCiv < hoje;
                    alertas.push({ tipo: 'DOCUMENTO', nivel: vencido ? 'VENCIDO' : 'ATENCAO', mensagem: `CIV ${v.placa} ${vencido ? 'venceu' : 'vence'}: ${v.vencimentoCiv.toLocaleDateString('pt-BR')}`, veiculoId: v.id });
                }
                if (v.vencimentoCipp && v.vencimentoCipp <= dataLimite) {
                    const vencido = v.vencimentoCipp < hoje;
                    alertas.push({ tipo: 'DOCUMENTO', nivel: vencido ? 'VENCIDO' : 'ATENCAO', mensagem: `CIPP ${v.placa} ${vencido ? 'venceu' : 'vence'}: ${v.vencimentoCipp.toLocaleDateString('pt-BR')}`, veiculoId: v.id });
                }
            });

            // 2. ALERTAS DE MANUTENÇÃO (PLANOS)
            const planos = await prisma.planoManutencao.findMany({
                where: { veiculo: { status: { not: 'INATIVO' } } },
                include: { veiculo: { select: { id: true, placa: true } } }
            });

            // OTIMIZAÇÃO DE PERFORMANCE (Evitando N+1 Queries)
            const veiculoIdsPlanos = [...new Set(planos.map(p => p.veiculo.id))];
            const mediasDiariasMap = await PrevisaoService.calcularMediasDiariasBulk(veiculoIdsPlanos);

            for (const p of planos) {
                // Lógica de Vencimento por TEMPO
                if (p.tipoIntervalo === 'TEMPO' && p.dataProximaManutencao && p.dataProximaManutencao <= dataLimite) {
                    const vencido = p.dataProximaManutencao < hoje;
                    alertas.push({ tipo: 'MANUTENCAO', nivel: vencido ? 'VENCIDO' : 'ATENCAO', mensagem: `Manutenção TEMPO (${p.descricao}) ${p.veiculo.placa} ${vencido ? 'venceu' : 'vence'}: ${p.dataProximaManutencao.toLocaleDateString('pt-BR')}`, veiculoId: p.veiculo.id });
                }

                // Lógica de Vencimento por KM e PREVISÃO
                if (p.tipoIntervalo === 'KM' && p.kmProximaManutencao) {
                    const kmAtual = kmMap.get(p.veiculo.id) || 0;
                    const kmRestante = p.kmProximaManutencao - kmAtual;

                    if (kmRestante <= 0) {
                        alertas.push({ tipo: 'MANUTENCAO', nivel: 'VENCIDO', mensagem: `Manutenção KM (${p.descricao}) ${p.veiculo.placa} VENCIDA (KM atual: ${kmAtual.toLocaleString('pt-BR')})`, veiculoId: p.veiculo.id });
                    } else {
                        try {
                            // Algoritmo de Previsão de Rodagem usando o cache de médias
                            const mediaPrecalc = mediasDiariasMap.get(p.veiculo.id) || 1;
                            const diasEstimados = await PrevisaoService.estimarDiasParaManutencao(p.veiculo.id, p.kmProximaManutencao, kmAtual, mediaPrecalc);

                            if (diasEstimados !== null && diasEstimados <= 15) {
                                alertas.push({
                                    tipo: 'MANUTENCAO',
                                    nivel: 'ATENCAO',
                                    mensagem: `PREVISÃO: ${p.veiculo.placa} deve atingir o KM da ${p.descricao} em aprox. ${diasEstimados} dias.`,
                                    veiculoId: p.veiculo.id
                                });
                            } else if (kmRestante <= limiteAlertaKM) {
                                alertas.push({
                                    tipo: 'MANUTENCAO',
                                    nivel: 'ATENCAO',
                                    mensagem: `Manutenção KM (${p.descricao}) ${p.veiculo.placa} vence em ${kmRestante.toLocaleString('pt-BR')} KM`,
                                    veiculoId: p.veiculo.id
                                });
                            }
                        } catch (err) {
                            console.error(`[Previsao Error] ${p.veiculo.placa}:`, err);
                        }
                    }
                }
            }

            // 3. INTELIGÊNCIA EXTRA: ALERTAS DE OCIOSIDADE (> 3 DIAS)
            const limiteOciosidade = new Date(hoje);
            limiteOciosidade.setDate(limiteOciosidade.getDate() - 3);

            // A. Veículos Fantasmas (Status ATIVO sem abrir KM há > 3 dias)
            const veiculosOciosos = await prisma.veiculo.findMany({
                where: { status: 'ATIVO' },
                include: {
                    jornadas: { orderBy: { dataInicio: 'desc' }, take: 1, select: { dataInicio: true } }
                }
            });

            veiculosOciosos.forEach(v => {
                const ultimaAbertura = v.jornadas.length > 0 ? v.jornadas[0].dataInicio : v.createdAt;
                if (ultimaAbertura < limiteOciosidade) {
                    const dias = Math.floor((hoje.getTime() - ultimaAbertura.getTime()) / (1000 * 60 * 60 * 24));
                    alertas.push({
                        tipo: 'VEICULO_OCIOSO',
                        nivel: 'ATENCAO',
                        mensagem: `${v.placa} (${v.modelo}) está ocioso há ${dias} dias. Está em manutenção?`,
                        veiculoId: v.id
                    });
                }
            });

            // B. Operadores Fantasmas (Status ATIVO sem abrir KM há > 3 dias)
            const operadoresOciosos = await prisma.user.findMany({
                where: { role: 'OPERADOR', status: 'ATIVO' },
                include: {
                    jornadasComoOperador: { orderBy: { dataInicio: 'desc' }, take: 1, select: { dataInicio: true } }
                }
            });

            operadoresOciosos.forEach(op => {
                const ultimaAbertura = op.jornadasComoOperador.length > 0 ? op.jornadasComoOperador[0].dataInicio : op.createdAt;
                if (ultimaAbertura < limiteOciosidade) {
                    const dias = Math.floor((hoje.getTime() - ultimaAbertura.getTime()) / (1000 * 60 * 60 * 24));
                    alertas.push({
                        tipo: 'OPERADOR_OCIOSO',
                        nivel: 'ATENCAO',
                        mensagem: `${op.nome} não roda há ${dias} dias. Está de Férias ou Atestado?`,
                        usuarioId: op.id
                    });
                }
            });

            // 5. INTEGRAÇÃO SST E RH: Treinamentos e ASOs vencendo
            const treinamentosCríticos = await prisma.treinamento.findMany({
                where: {
                    dataVencimento: { not: null, lte: dataLimite }
                },
                include: {
                    user: { select: { id: true, nome: true, role: true } }
                }
            });

            treinamentosCríticos.forEach(t => {
                if (!t.dataVencimento) return;
                const vencido = t.dataVencimento < hoje;
                alertas.push({
                    tipo: 'SST',
                    nivel: vencido ? 'VENCIDO' : 'ATENCAO',
                    mensagem: `SST: ${t.nome} de ${t.user.nome} ${vencido ? 'venceu' : 'vence'} em ${t.dataVencimento.toLocaleDateString('pt-BR')}`,
                    usuarioId: t.user.id
                });
            });

            // 6. BIG BROTHER DOS ERROS DE SISTEMA E FRAUDES
            const logsPendentes = await prisma.systemLog.findMany({
                where: { resolved: false },
                orderBy: { createdAt: 'desc' }
            });

            logsPendentes.forEach(log => {
                alertas.push({
                    tipo: log.level === 'FRAUD_ATTEMPT' ? 'TENTATIVA_FRAUDE' : 'ERRO_SISTEMA',
                    nivel: log.level === 'FRAUD_ATTEMPT' ? 'VENCIDO' : 'ATENCAO', // Exibe vermelho para fraude
                    mensagem: log.source === 'FRONTEND' 
                        ? `O aplicativo apresentou erro para o Operador. Log técnico: ${log.message}` 
                        : `O sistema bloqueou uma tentativa indevida: ${log.message}`,
                    logId: log.id,
                    veiculoId: log.veiculoId || undefined,
                    usuarioId: log.userId || undefined
                });
            });

            // Ordenação por severidade: VENCIDO > ATENCAO > PROJETADO
            const nivelOrdem: Record<string, number> = { VENCIDO: 0, ATENCAO: 1, PROJETADO: 2 };
            alertas.sort((a, b) => (nivelOrdem[a.nivel] ?? 3) - (nivelOrdem[b.nivel] ?? 3));
            res.json(alertas);
        } catch (e) { next(e); }
    }

    /**
     * RELATÓRIO DE LAVAGENS
     * Histórico e resumo financeiro anual de lavagens.
     */
    getRelatorioLavagens = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            if (!['ADMIN', 'ENCARREGADO'].includes(req.user?.role || '')) {
                res.status(403).json({ error: 'Acesso negado' });
                return;
            }

            const { ano } = req.query;
            const anoFiltro = Number(ano) || new Date().getFullYear();
            const startDate = new Date(anoFiltro, 0, 1);
            const endDate = new Date(anoFiltro, 11, 31, 23, 59, 59);

            const lavagens = await prisma.ordemServico.findMany({
                where: { data: { gte: startDate, lte: endDate }, tipo: 'LAVAGEM' },
                include: {
                    veiculo: true,
                    fornecedor: true,
                    itens: { include: { produto: true } }
                },
                orderBy: { data: 'asc' }
            });

            // Geração de resumo mensal de custos
            const resumoMensal = Array(12).fill(0);
            lavagens.forEach(l => {
                const mes = new Date(l.data).getMonth();
                resumoMensal[mes] += Number(l.custoTotal);
            });

            const resumoFormatado = resumoMensal.map((valor, index) => ({
                mes: new Date(anoFiltro, index, 1).toLocaleDateString('pt-BR', { month: '2-digit', year: 'numeric' }),
                valorTotal: valor
            }));

            const lavagensFormatadas = lavagens.map(l => ({
                ...l,
                descricao: l.itens.length > 0 ? l.itens.map(i => i.produto.nome).join(' + ') : (l.observacoes || 'Lavagem Geral'),
                notaFiscal: l.observacoes
            }));

            res.json({ lavagens: lavagensFormatadas, resumoMensal: resumoFormatado, ano: anoFiltro });
        } catch (error) { next(error); }
    }

    /**
     * DASHBOARD BI: SÉRIE HISTÓRICA DE CPK
     * Retorna os últimos 6 meses de Custo por KM (Combustível vs Manutenção)
     */
    getEvolucaoCpk = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            if (!['ADMIN', 'ENCARREGADO'].includes(req.user?.role || '')) {
                return res.status(403).json({ error: 'Acesso negado' });
            }

            const { veiculoId } = req.query;
            const filtroVeiculo = veiculoId ? { veiculoId: veiculoId as string } : {};

            const meses = [];
            const quantidadeMeses = 6;
            
            // Gerar array dos últimos 6 meses retroativos
            for (let i = quantidadeMeses - 1; i >= 0; i--) {
                const d = new Date();
                d.setMonth(d.getMonth() - i);
                meses.push({
                    ano: d.getFullYear(),
                    mes: d.getMonth() + 1,
                    nome: d.toLocaleDateString('pt-BR', { month: 'short' }).toUpperCase(),
                    inicio: new Date(d.getFullYear(), d.getMonth(), 1),
                    fim: new Date(d.getFullYear(), d.getMonth() + 1, 1)
                });
            }

            // 🔥 PERFORMANCE OPTIMIZER: 18 Queries → 3 Queries
            // Busca todos os dados do semestre de uma vez
            const dataInicioGlobal = meses[0].inicio;
            const dataFimGlobal = meses[meses.length - 1].fim;
            const filtroDataGlobal = { gte: dataInicioGlobal, lt: dataFimGlobal };

            const [itensCobustivel, ordensManutencao, jornadasTerminadas] = await Promise.all([
                // 1. Todos os abastecimentos do semestre
                prisma.itemAbastecimento.findMany({
                    where: {
                        produto: { tipo: 'COMBUSTIVEL' },
                        abastecimento: { dataHora: filtroDataGlobal, ...filtroVeiculo }
                    },
                    select: { valorTotal: true, abastecimento: { select: { dataHora: true } } }
                }),
                // 2. Todas as OS do semestre
                prisma.ordemServico.findMany({
                    where: { data: filtroDataGlobal, ...filtroVeiculo },
                    select: { custoTotal: true, data: true }
                }),
                // 3. Todas as jornadas terminadas do semestre
                prisma.jornada.findMany({
                    where: { dataInicio: filtroDataGlobal, kmFim: { not: null }, ...filtroVeiculo },
                    select: { kmInicio: true, kmFim: true, dataInicio: true }
                })
            ]);

            // Faz o agrupamento (Map Reduce) em memória para os 6 meses (muito mais rápido que 18 requests TCP)
            const dadosEvolucao = meses.map(m => {
                const totalKm = jornadasTerminadas
                    .filter(j => j.dataInicio >= m.inicio && j.dataInicio < m.fim)
                    .reduce((acc, j) => acc + ((j.kmFim ?? 0) - j.kmInicio), 0);

                const custoComb = itensCobustivel
                    .filter(i => i.abastecimento.dataHora >= m.inicio && i.abastecimento.dataHora < m.fim)
                    .reduce((acc, i) => acc + Number(i.valorTotal || 0), 0);

                const custoManut = ordensManutencao
                    .filter(o => o.data >= m.inicio && o.data < m.fim)
                    .reduce((acc, o) => acc + Number(o.custoTotal || 0), 0);

                return {
                    name: m.nome,
                    fuel: totalKm > 0 ? Number((custoComb / totalKm).toFixed(2)) : 0,
                    maintenance: totalKm > 0 ? Number((custoManut / totalKm).toFixed(2)) : 0,
                    custoCombustivelAbsoluto: custoComb,
                    custoManutencaoAbsoluto: custoManut,
                    kmRodado: totalKm
                };
            });

            // Adiciona Cache-Control para evitar requests desnecessários em dados históricos
            res.set('Cache-Control', 'private, max-age=120'); // 2 minutos de cache
            res.json(dadosEvolucao);
        } catch (error) { next(error); }
    }

    /**
     * DASHBOARD BI: PERFORMANCE DA FROTA (Gráfico de Barras)
     * Retorna custo total vs performance do veículo no mês
     */
    getPerformanceFrota = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            if (!['ADMIN', 'ENCARREGADO'].includes(req.user?.role || '')) {
                return res.status(403).json({ error: 'Acesso negado' });
            }

            const { ano, mes } = req.query as unknown as RelatorioQuery;
            const anoNum = Number(ano) || new Date().getFullYear();
            const mesNum = Number(mes) || new Date().getMonth() + 1;

            const dataInicio = new Date(anoNum, mesNum - 1, 1);
            const dataFim = new Date(anoNum, mesNum, 1);

            const veiculosBase = await prisma.veiculo.findMany({
                where: { status: { not: 'INATIVO' } },
                select: { id: true, placa: true, modelo: true }
            });

            // Buscamos jornadas, abastecimentos e manutencoes agrupadas
            const [jornadas, abastecimentos, manutencoes] = await Promise.all([
                prisma.jornada.findMany({
                    where: { dataInicio: { gte: dataInicio, lt: dataFim }, kmFim: { not: null } },
                    select: { veiculoId: true, kmInicio: true, kmFim: true }
                }),
                prisma.itemAbastecimento.findMany({
                    where: { abastecimento: { dataHora: { gte: dataInicio, lt: dataFim } } },
                    select: { valorTotal: true, abastecimento: { select: { veiculoId: true } } }
                }),
                prisma.ordemServico.findMany({
                    where: { data: { gte: dataInicio, lt: dataFim } },
                    select: { custoTotal: true, veiculoId: true }
                })
            ]);

            const custosPorVeiculo = new Map<string, number>();
            abastecimentos.forEach(item => {
                const vid = item.abastecimento.veiculoId;
                custosPorVeiculo.set(vid, (custosPorVeiculo.get(vid) || 0) + Number(item.valorTotal));
            });
            manutencoes.forEach(os => {
                const vid = os.veiculoId ?? '';
                if (vid) custosPorVeiculo.set(vid, (custosPorVeiculo.get(vid) || 0) + Number(os.custoTotal));
            });

            const kmpPorVeiculo = new Map<string, number>();
            jornadas.forEach(j => {
                const km = (j.kmFim ?? 0) - j.kmInicio;
                if(km > 0) kmpPorVeiculo.set(j.veiculoId, (kmpPorVeiculo.get(j.veiculoId) || 0) + km);
            });

            const cores = ['#4f46e5', '#ec5b13', '#0d9488', '#e11d48', '#8b5cf6'];

            const dadosMatriz = veiculosBase.map((v, index) => {
                const custo = custosPorVeiculo.get(v.id) || 0;
                const km = kmpPorVeiculo.get(v.id) || 0;

                return {
                    id: v.id,
                    name: `${v.modelo} (${v.placa})`,
                    cost: custo,
                    kmRodado: km,
                    color: cores[index % cores.length]
                };
            }).filter(d => d.cost > 0 || d.kmRodado > 0)
              .sort((a,b) => b.cost - a.cost)
              .slice(0, 10); // Retorna os 10 veículos com maior custo para não poluir o gráfico

            res.json(dadosMatriz);
        } catch (error) { next(error); }
    }

    /**
     * DASHBOARD BI PRO MAX: DADOS BRUTOS PARA O FRONTEND
     * Retorna arrays de jornadas, abastecimentos e manutenções 
     * dos últimos 4 meses para processamento in-memory no React (useMemo).
     */
    getAnalyticsRaw = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            if (!['ADMIN', 'ENCARREGADO'].includes(req.user?.role || '')) {
                return res.status(403).json({ error: 'Acesso negado' });
            }

            const { ano, mes, veiculoId } = req.query as unknown as RelatorioQuery;
            const anoNum = Number(ano) || new Date().getFullYear();
            const mesNum = Number(mes) || new Date().getMonth() + 1;

            // Busca do mês atual + 3 meses anteriores para Forecasting e MoM Delta
            const dataFim = new Date(anoNum, mesNum, 1);
            const dataInicio = new Date(anoNum, mesNum - 4, 1);

            const filtroData = { gte: dataInicio, lt: dataFim };
            const filtroVeiculo = veiculoId ? { veiculoId: String(veiculoId) } : {};

            // Otimização: Paralelizar as 4 grandes queries com limites de segurança 007
            const [veiculos, jornadas, abastecimentos, manutencoes] = await Promise.all([
                prisma.veiculo.findMany({
                    where: { status: { not: 'INATIVO' }, ...filtroVeiculo },
                    select: { id: true, placa: true, modelo: true, status: true },
                    take: 100 // Frota dificilmente passa de 100 ativos
                }),
                prisma.jornada.findMany({
                    where: { dataInicio: filtroData, kmFim: { not: null }, ...filtroVeiculo },
                    select: { id: true, veiculoId: true, dataInicio: true, kmInicio: true, kmFim: true },
                    take: 500 // Trava de segurança contra queries abusivas
                }),
                // Trazer items com as notas para calcular gastos detalhados
                prisma.itemAbastecimento.findMany({
                    where: {
                        abastecimento: { dataHora: filtroData, ...filtroVeiculo }
                    },
                    select: {
                        quantidade: true,
                        valorTotal: true,
                        produto: { select: { tipo: true, nome: true } },
                        abastecimento: { select: { veiculoId: true, dataHora: true } }
                    },
                    take: 500
                }),
                prisma.ordemServico.findMany({
                    where: { data: filtroData, ...filtroVeiculo },
                    select: { 
                        id: true, veiculoId: true, data: true, tipo: true, custoTotal: true,
                        itens: { select: { valorTotal: true, produto: { select: { nome: true, tipo: true } } } }
                    },
                    take: 500
                })
            ]);

            res.json({
                periodo: { inicio: dataInicio, fim: dataFim },
                veiculos,
                jornadas,
                abastecimentos,
                manutencoes
            });
        } catch (error) { next(error); }
    }
}