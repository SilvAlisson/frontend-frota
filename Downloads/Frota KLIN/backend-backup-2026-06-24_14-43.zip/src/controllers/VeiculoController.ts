import { Request, Response, NextFunction } from 'express';
import { prisma } from '../lib/prisma';
import { AuthenticatedRequest } from '../middleware/auth';
import { z } from 'zod';
import { veiculoSchema } from '../schemas/veiculo.schemas';

// Helper para formatar data para o input HTML (YYYY-MM-DD)
const formatDateToInput = (date: Date | null | undefined): string | null => {
    if (!date) return null;
    const d = new Date(date);
    const dataCorrigida = new Date(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate());
    return dataCorrigida.toISOString().split('T')[0] || null;
};

// Extração do tipo do Zod + kmAtual que não está no schema do banco, mas vem no body
type VeiculoData = z.infer<typeof veiculoSchema>['body'] & { kmAtual?: number };

export class VeiculoController {

    /**
     * LISTAR TODOS (ADMIN / GESTOR)
     */
    list = async (req: Request, res: Response, next: NextFunction) => {
        try {
            const veiculos = await prisma.veiculo.findMany({
                orderBy: { placa: 'asc' }
            });
            res.status(200).json(veiculos);
        } catch (error) { next(error); }
    }

    /**
     * BUSCAR POR ID (DETALHES SIMPLES)
     */
    getById = async (req: Request, res: Response, next: NextFunction) => {
        try {
            const { id } = req.params;
            if (!id) return res.status(400).json({ error: 'ID inválido' });

            const veiculo = await prisma.veiculo.findUnique({ where: { id: id as string } });
            if (!veiculo) return res.status(404).json({ error: 'Veículo não encontrado.' });

            // Busca o KM real (pode estar na tabela veiculo ou historico, aqui garantimos sincronia)
            const ultimoKm = veiculo.ultimoKm || 0;

            const veiculoFormatado = {
                ...veiculo,
                kmAtual: ultimoKm, // Retorna kmAtual para o frontend preencher o input
                vencimentoCiv: formatDateToInput(veiculo.vencimentoCiv),
                vencimentoCipp: formatDateToInput(veiculo.vencimentoCipp),
            };

            res.status(200).json(veiculoFormatado);
        } catch (error) { next(error); }
    }

    /**
     * BUSCA DETALHES CONSOLIDADOS (Prontuário do Veículo)
     */
    getDetalhes = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            const { id } = req.params;
            if (!id) return res.status(400).json({ error: 'ID do veículo é obrigatório.' });

            const veiculo = await prisma.veiculo.findFirst({
                where: {
                    OR: [
                        { id: id as string },
                        { placa: id as string }
                    ]
                },
                include: {
                    jornadas: { orderBy: { dataInicio: 'desc' }, take: 5, include: { operador: { select: { nome: true } } } },
                    abastecimentos: { orderBy: { dataHora: 'desc' }, take: 5, include: { fornecedor: { select: { nome: true } } } },
                    ordensServico: { orderBy: { data: 'desc' }, take: 5, include: { fornecedor: { select: { nome: true } } } },
                    planosManutencao: true
                }
            });

            if (!veiculo) return res.status(404).json({ error: 'Veículo não encontrado.' });

            const [manutencaoTotal, abastecimentoTotal] = await Promise.all([
                prisma.ordemServico.aggregate({ _sum: { custoTotal: true }, where: { veiculoId: id } }),
                prisma.itemAbastecimento.aggregate({
                    _sum: { valorTotal: true, quantidade: true },
                    where: { abastecimento: { veiculoId: id }, produto: { tipo: 'COMBUSTIVEL' } }
                })
            ]);

            const inicioMes = new Date();
            inicioMes.setDate(1);
            inicioMes.setHours(0, 0, 0, 0);

            const jornadasMes = await prisma.jornada.findMany({
                where: { veiculoId: id, dataInicio: { gte: inicioMes }, kmFim: { not: null } },
                select: { kmInicio: true, kmFim: true }
            });

            const kmRodadoMes = jornadasMes.reduce((acc, j) => acc + ((j.kmFim ?? 0) - j.kmInicio), 0);
            const litrosTotal = Number(abastecimentoTotal._sum.quantidade || 0);

            res.json({
                ...veiculo,
                resumoFinanceiro: {
                    totalGastoManutencao: Number(manutencaoTotal._sum.custoTotal || 0),
                    totalGastoCombustivel: Number(abastecimentoTotal._sum.valorTotal || 0),
                    mediaConsumoGeral: litrosTotal > 0 ? (kmRodadoMes / litrosTotal) : 0,
                    kmRodadoMesAtual: kmRodadoMes
                }
            });
        } catch (error) { next(error); }
    }

    /**
     * Cria um novo veículo e inicializa o histórico de KM via Transação.
     */
    create = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            if (req.user?.role !== 'ADMIN') {
                return res.status(403).json({ error: 'Acesso negado.' });
            }

            const dados = req.body as VeiculoData;
            const kmInicial = Number(dados.kmAtual);

            if (isNaN(kmInicial) || kmInicial < 0) {
                return res.status(400).json({ error: 'É obrigatório informar o KM Atual válido.' });
            }

            const resultado = await prisma.$transaction(async (tx) => {
                const novoVeiculo = await tx.veiculo.create({
                    data: {
                        placa: dados.placa,
                        marca: dados.marca,
                        modelo: dados.modelo,
                        ano: dados.ano,
                        tipoCombustivel: dados.tipoCombustivel,
                        status: dados.status || 'ATIVO',
                        capacidadeTanque: dados.capacidadeTanque ?? null,
                        tipoVeiculo: dados.tipoVeiculo ?? null,
                        vencimentoCiv: dados.vencimentoCiv ? new Date(dados.vencimentoCiv) : null,
                        vencimentoCipp: dados.vencimentoCipp ? new Date(dados.vencimentoCipp) : null,
                        ultimoKm: kmInicial
                    },
                });

                await tx.historicoKm.create({
                    data: {
                        veiculoId: novoVeiculo.id,
                        km: kmInicial,
                        dataLeitura: new Date(),
                        origem: 'MANUAL',
                        origemId: null
                    }
                });

                return novoVeiculo;
            });

            res.status(201).json(resultado);
        } catch (error) { next(error); }
    }

    /**
     * ATUALIZAR VEÍCULO + CORREÇÃO DE KM (DRIFT)
     * Se o Admin mudar o KM no cadastro, isso corrige o 'ultimoKm' e cria histórico.
     */
    update = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            if (req.user?.role !== 'ADMIN') {
                return res.status(403).json({ error: 'Acesso negado.' });
            }

            const { id } = req.params;
            if (!id) return res.status(400).json({ error: 'ID inválido' });

            const dados = req.body as VeiculoData;

            // Transação para garantir consistência
            const updatedVeiculo = await prisma.$transaction(async (tx) => {

                // 1. Atualiza dados cadastrais
                const veiculoAtualizado = await tx.veiculo.update({
                    where: { id: id as string },
                    data: {
                        placa: dados.placa,
                        marca: dados.marca,
                        modelo: dados.modelo,
                        ano: dados.ano,
                        tipoCombustivel: dados.tipoCombustivel,
                        status: dados.status,
                        capacidadeTanque: dados.capacidadeTanque ?? null,
                        tipoVeiculo: dados.tipoVeiculo ?? null,
                        vencimentoCiv: dados.vencimentoCiv ? new Date(dados.vencimentoCiv) : null,
                        vencimentoCipp: dados.vencimentoCipp ? new Date(dados.vencimentoCipp) : null,
                        // Se o KM vier no payload, atualiza diretamente
                        ...(dados.kmAtual !== undefined ? { ultimoKm: Number(dados.kmAtual) } : {})
                    },
                });

                // 2. Se houve alteração de KM, registra no histórico como Ajuste Admin
                if (dados.kmAtual !== undefined) {
                    await tx.historicoKm.create({
                        data: {
                            veiculoId: id as string,
                            km: Number(dados.kmAtual),
                            dataLeitura: new Date(),
                            origem: 'AJUSTE_ADMIN',
                            origemId: req.user?.userId || null
                        }
                    });
                }

                return veiculoAtualizado;
            });

            res.status(200).json(updatedVeiculo);
        } catch (error) { next(error); }
    }

    /**
     * NANO-ENDPOINT: Atualiza apenas o status (Usado pela Inteligência de Ociosidade)
     */
    updateStatus = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            if (!['ADMIN', 'ENCARREGADO'].includes(req.user?.role || '')) {
                return res.status(403).json({ error: 'Acesso negado.' });
            }
            const { id } = req.params;
            const { status } = req.body;

            if (!id || !status) return res.status(400).json({ error: 'Parâmetros incompletos' });

            const veiculo = await prisma.veiculo.update({
                where: { id },
                data: { status }
            });

            res.json({ message: 'Status atualizado com sucesso', status: veiculo.status });
        } catch (error) { next(error); }
    }

    delete = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            if (req.user?.role !== 'ADMIN') {
                return res.status(403).json({ error: 'Acesso negado.' });
            }
            const { id } = req.params;
            if (!id) return res.status(400).json({ error: 'ID inválido' });

            // REGRA DE NEGÓCIO (007 & Dados): Nunca deletar dados orfãos (Folha Financeira BI)
            const countJornadas = await prisma.jornada.count({ where: { veiculoId: id as string } });
            const countAbastecimentos = await prisma.abastecimento.count({ where: { veiculoId: id as string } });

            if (countJornadas > 0 || countAbastecimentos > 0) {
                await prisma.veiculo.update({
                    where: { id: id as string },
                    data: { status: 'INATIVO' }
                });
                return res.status(200).json({ message: 'Veículo possui histórico de rodagem. Status foi alterado para INATIVO de forma segura, mantendo os cálculos de CPK intactos no BI.' });
            }

            await prisma.veiculo.delete({ where: { id: id as string } });
            res.status(200).json({ message: 'Veículo removido com sucesso.' });
        } catch (error) { next(error); }
    }

    /**
     * LISTAR PARA OPERAÇÃO (Dropdowns e selects rápidos)
     */
    listarParaOperacao = async (req: Request, res: Response, next: NextFunction) => {
        try {
            const veiculos = await prisma.veiculo.findMany({
                where: {
                    status: { not: 'INATIVO' }
                },
                select: {
                    id: true,
                    placa: true,
                    modelo: true,
                    marca: true,
                    tipoVeiculo: true,
                    status: true,
                    ultimoKm: true
                },
                orderBy: { placa: 'asc' }
            });
            res.json(veiculos);
        } catch (error) { next(error); }
    }

    /**
     * CÉREBRO: Listar veículos Ociosos (Paradões há mais de 3 dias sem jornada reportada)
     */
    listarOciosos = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            if (!['ADMIN', 'ENCARREGADO', 'COORDENADOR'].includes(req.user?.role || '')) {
                return res.status(403).json({ error: 'Acesso negado.' });
            }

            const limiteOciosidade = new Date();
            limiteOciosidade.setDate(limiteOciosidade.getDate() - 3);

            // Busca veículos base (ATIVOS ou DISPONIVEIS) que NÃO estão em manutenção oficial
            // e cuja última jornada fechada foi há mais de 3 dias (ou nunca tiveram).
            const veiculos = await prisma.veiculo.findMany({
                where: {
                    status: { notIn: ['INATIVO', 'EM_MANUTENCAO'] },
                },
                include: {
                    jornadas: { orderBy: { dataInicio: 'desc' }, take: 1 },
                }
            });

            const ociosos = veiculos.filter(v => {
                // Se o campo de atualização nativo (updatedAt ou na jornada) > 3 dias
                if (v.jornadas.length === 0) return true; // Nunca trabalhou
                
                const ultimaJornada = v.jornadas[0];
                const ultimaDataRegistro = ultimaJornada.dataFim || ultimaJornada.dataInicio;
                
                return new Date(ultimaDataRegistro) < limiteOciosidade;
            });

            const resultadosMapeados = ociosos.map(v => {
                const diasParado = v.jornadas.length > 0 
                  ? Math.floor((new Date().getTime() - new Date(v.jornadas[0].dataFim || v.jornadas[0].dataInicio).getTime()) / (1000 * 3600 * 24))
                  : 'N/A';

                return {
                    id: v.id,
                    placa: v.placa,
                    modelo: v.modelo,
                    diasParado,
                    ultimaMovimentacao: v.jornadas.length > 0 ? (v.jornadas[0].dataFim || v.jornadas[0].dataInicio) : null
                };
            });

            res.json(resultadosMapeados);
        } catch (error) { next(error); }
    }
}