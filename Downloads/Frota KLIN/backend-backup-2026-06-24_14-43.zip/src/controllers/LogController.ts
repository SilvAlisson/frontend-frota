import { Request, Response, NextFunction } from 'express';
import { prisma } from '../lib/prisma';
import { Prisma } from '@prisma/client';
import { AuthenticatedRequest } from '../middleware/auth';

// 🔐 Whitelists atualizadas para bater com o Painel de Elite
const NIVEIS_VALIDOS = ['CRITICAL', 'ERROR', 'WARNING', 'FRAUD_ATTEMPT', 'INFO'] as const;
const FONTES_VALIDAS = ['FRONTEND', 'BACKEND_JORNADAS', 'SISTEMA', 'SEGURANCA', 'UNKNOWN'] as const;

type LogLevel = typeof NIVEIS_VALIDOS[number];
type LogSource = typeof FONTES_VALIDAS[number];

export class LogController {

    /**
     * GET /api/v1/logs
     *  Lista os logs com trava de performance e extração máxima de dados
     */
    async index(req: AuthenticatedRequest, res: Response, next: NextFunction) {
        try {
            // Apenas Admin e Coordenador podem ver a caixa negra do sistema
            if (!['ADMIN', 'COORDENADOR'].includes(req.user?.role || '')) {
                return res.status(403).json({ error: 'Acesso restrito à auditoria de sistema.' });
            }

            const logs = await prisma.systemLog.findMany({
                // 🛡️ Trava de Performance: Traz apenas os 200 mais recentes
                take: 200, 
                orderBy: {
                    createdAt: 'desc'
                },
                include: {
                    user: {
                        select: { nome: true, role: true }
                    }
                    // Removemos o include veiculo daqui para evitar o erro 'never' do TypeScript
                }
            });

            //  Busca as placas separadamente (Altíssima Performance)
            const veiculoIds = [...new Set(logs.map(log => log.veiculoId).filter(Boolean))] as string[];
            
            let veiculosMap: Record<string, string> = {};
            
            // Se houver algum veículo citado nos logs, fazemos uma query única para pegar as placas
            if (veiculoIds.length > 0) {
                const veiculos = await prisma.veiculo.findMany({
                    where: { id: { in: veiculoIds } },
                    select: { id: true, placa: true }
                });
                
                // Transforma o array num dicionário super rápido: { "id_do_veiculo": "ABC1234" }
                veiculosMap = veiculos.reduce((acc, v) => ({ ...acc, [v.id]: v.placa }), {});
            }

            // Mapeamento para o formato "Elite" do Frontend (Nível Gerencial)
            const logsFormatados = logs.map(log => {
                
                //  Mantém o contexto como Objeto para o Frontend destrinchar!
                let contextoObj: Prisma.InputJsonValue | null = null;
                if (log.context) {
                    try {
                        // Tenta garantir que seja um objeto JSON real, não uma string de JSON
                        contextoObj = typeof log.context === 'string' 
                            ? JSON.parse(log.context) 
                            : log.context;
                    } catch (e) {
                        // Se for um texto simples que não dá parse, envelopa amigavelmente
                        contextoObj = { informacaoAdicional: String(log.context) };
                    }
                }

                return {
                    id: log.id,
                    nivel: log.level, // Mapeia o enum do DB para o frontend
                    acao: log.source, // Ex: "BACKEND_JORNADAS" (O frontend formata isso bonito)
                    detalhes: log.message + (log.stackTrace ? `\n\n[STACK TRACE]\n${log.stackTrace}` : ''),
                    contexto: contextoObj, //  Objeto Limpo com KMs, Fotos e IP!
                    usuario: log.user ? { nome: log.user.nome, role: log.user.role } : undefined,
                    veiculo: log.veiculoId ? veiculosMap[log.veiculoId] : undefined, // ✨ A Placa real do caminhão!
                    resolvido: log.resolved,
                    dataCriacao: log.createdAt,
                    dataResolucao: log.resolvedAt
                };
            });

            return res.json(logsFormatados);
        } catch (error) {
            next(error);
        }
    }

    /**
     * POST /api/v1/logs
     * Recebe um erro ou log diretamente do Frontend ou rotas internas
     */
    async create(req: AuthenticatedRequest, res: Response, next: NextFunction) {
        try {
            const { level, source, message, stackTrace, context, veiculoId } = req.body;
            const userId = req.user?.userId || null;

            // Sanitização contra injeção de alertas falsos
            const levelSafe: LogLevel = NIVEIS_VALIDOS.includes(level) ? level : 'ERROR';
            const sourceSafe: LogSource = FONTES_VALIDAS.includes(source) ? source : 'FRONTEND';

            //  Enriquecimento do contexto com IP real do usuário (Proxy tracking)
            let enrichedContext = context || {};
            if (typeof enrichedContext === 'object') {
                enrichedContext = {
                    ...enrichedContext,
                    _auditIp: req.ip || req.headers['x-forwarded-for'] || 'IP Desconhecido'
                };
            }

            const log = await prisma.systemLog.create({
                data: {
                    level: levelSafe,
                    source: sourceSafe,
                    message: message ? String(message).substring(0, 1000) : 'Falha Desconhecida',
                    stackTrace: stackTrace ? String(stackTrace).substring(0, 5000) : null,
                    context: enrichedContext, // Salva com o IP injetado para auditoria
                    veiculoId: veiculoId || null,
                    userId: userId,
                }
            });

            return res.status(201).json({ message: 'Log registrado com sucesso.', id: log.id });
        } catch (error) {
            console.error('[GRAVE] FALHA AO SALVAR LOG:', error);
            return res.status(200).json({ message: 'Erro interno ao salvar o log, mas requisição não travada.' });
        }
    }

    /**
     * PUT /api/v1/logs/:id/resolver
     * Admin marca o log como lido/resolvido
     */
    async resolver(req: AuthenticatedRequest, res: Response, next: NextFunction) {
        try {
            //  Ajuste de segurança: Permitido para Admin, Coordenador e Encarregado
            if (!['ADMIN', 'COORDENADOR', 'ENCARREGADO'].includes(req.user?.role || '')) {
                return res.status(403).json({ error: 'Permissão insuficiente para arquivar auditoria.' });
            }

            const { id } = req.params;

            const log = await prisma.systemLog.update({
                where: { id },
                data: {
                    resolved: true,
                    resolvedAt: new Date()
                }
            });

            return res.json({ message: 'Auditado com sucesso', log });
        } catch (error) {
            next(error);
        }
    }

    /**
     * PUT /api/v1/logs/resolver-todos
     * Marca TODOS os logs pendentes como lidos/resolvidos de uma só vez
     */
    async resolverTodos(req: AuthenticatedRequest, res: Response, next: NextFunction) {
        try {
            if (!['ADMIN', 'COORDENADOR', 'ENCARREGADO'].includes(req.user?.role || '')) {
                return res.status(403).json({ error: 'Permissão insuficiente para arquivar auditoria.' });
            }

            const result = await prisma.systemLog.updateMany({
                where: { resolved: false },
                data: {
                    resolved: true,
                    resolvedAt: new Date()
                }
            });

            return res.json({ message: `${result.count} logs auditados com sucesso.` });
        } catch (error) {
            next(error);
        }
    }
}