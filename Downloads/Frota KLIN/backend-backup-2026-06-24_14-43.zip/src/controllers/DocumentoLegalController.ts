import { Request, Response } from 'express';
import { prisma } from '../lib/prisma';
import { createDocumentoLegalSchema, renovarDocumentoLegalSchema } from '../schemas/documentoLegal.schemas';
import { z } from 'zod';
import { AuthenticatedRequest } from '../middleware/auth';

export class DocumentoLegalController {

    // LISTAR (Com inteligência de contexto e Permissão de Admin)
    async index(req: Request, res: Response) {
        try {
            const { categoria, veiculoId, status } = req.query;
            
            const userRole = (req as AuthenticatedRequest).user?.role;

            let whereClause: any = {};

            if (categoria && categoria !== 'TODOS') {
                whereClause.categoria = String(categoria);
            }
            
            if (veiculoId) {
                const veiculo = await prisma.veiculo.findUnique({
                    where: { id: String(veiculoId) }
                });

                if (veiculo) {
                    const tipo = veiculo.tipoVeiculo || '';

                    whereClause = {
                        ...whereClause,
                        OR: [
                            { veiculoId: null, tipoVeiculo: null },
                            { veiculoId: null, tipoVeiculo: tipo },
                            { veiculoId: String(veiculoId) }
                        ]
                    };
                }
            } else {
                if (['ADMIN', 'RH', 'COORDENADOR', 'ENCARREGADO'].includes(userRole ?? '')) {
                    // Admin vê tudo
                }
            }

            // Se não pedir status específico, retorna apenas os VIGENTES
            whereClause.status = status ? String(status) : 'VIGENTE';

            const documentos = await prisma.documentoLegal.findMany({
                where: whereClause,
                orderBy: [
                    { dataValidade: 'asc' },
                    { createdAt: 'desc' }
                ]
            });

            return res.json(documentos);
        } catch (error) {
            console.error('Erro ao listar documentos:', error);
            return res.status(500).json({ error: 'Erro interno ao buscar documentos' });
        }
    }

    // ✨ NOVO: BUSCAR UM ÚNICO DOCUMENTO PARA EDIÇÃO
    async show(req: Request, res: Response) {
        try {
            const { id } = req.params;
            const documento = await prisma.documentoLegal.findUnique({
                where: { id },
                include: {
                    renovacoes: {
                        orderBy: { createdAt: 'desc' }
                    },
                    documentoOrigem: true
                }
            });

            if (!documento) {
                return res.status(404).json({ error: 'Documento não encontrado' });
            }

            return res.json(documento);
        } catch (error) {
            console.error('Erro ao buscar documento:', error);
            return res.status(500).json({ error: 'Erro ao buscar dados do documento' });
        }
    }

    // CRIAR
    async create(req: Request, res: Response) {
        try {
            const data = createDocumentoLegalSchema.parse(req.body);

            const documento = await prisma.documentoLegal.create({
                data: {
                    titulo: data.titulo,
                    arquivoUrl: data.arquivoUrl,
                    categoria: data.categoria, 
                    descricao: data.descricao ?? null,
                    dataValidade: data.dataValidade ?? null,
                    tipoVeiculo: data.tipoVeiculo ? data.tipoVeiculo.toUpperCase() : null,
                    veiculoId: data.veiculoId ?? null
                }
            });

            return res.status(201).json(documento);

        } catch (error) {
            if (error instanceof z.ZodError) {
                return res.status(400).json({
                    message: 'Dados inválidos',
                    errors: (error as z.ZodError).issues
                });
            }
            console.error('Erro ao criar documento:', error);
            return res.status(500).json({ error: 'Erro ao salvar documento' });
        }
    }

    // ✨ NOVO: ATUALIZAR O DOCUMENTO
    async update(req: Request, res: Response) {
        try {
            const { id } = req.params;
            const { titulo, categoria, descricao, dataValidade } = req.body;

            // Atualiza apenas os campos permitidos na edição rápida
            const documentoAtualizado = await prisma.documentoLegal.update({
                where: { id },
                data: {
                    titulo,
                    categoria,
                    descricao: descricao ?? null,
                    dataValidade: dataValidade ?? null,
                }
            });

            return res.json(documentoAtualizado);
        } catch (error) {
            console.error('Erro ao atualizar documento:', error);
            return res.status(500).json({ error: 'Erro ao atualizar documento' });
        }
    }

    // ✨ RENOVAR O DOCUMENTO (Arquiva o antigo, cria o novo apontando para ele)
    async renovar(req: Request, res: Response) {
        try {
            const { id } = req.params; // ID do documento ANTIGO
            const data = renovarDocumentoLegalSchema.parse(req.body);

            // 1. Pega documento antigo
            const documentoAntigo = await prisma.documentoLegal.findUnique({
                where: { id }
            });

            if (!documentoAntigo) {
                return res.status(404).json({ error: 'Documento original não encontrado' });
            }

            // 2. Transação: Cria o novo e Arquiva o velho
            const renovacaoResult = await prisma.$transaction(async (tx) => {
                // Arquiva o Antigo
                await tx.documentoLegal.update({
                    where: { id },
                    data: { status: 'ARQUIVADO' }
                });

                // Cria o Novo apontando para o antigo como origem
                const novoDocumento = await tx.documentoLegal.create({
                    data: {
                        titulo: data.titulo,
                        arquivoUrl: data.arquivoUrl,
                        categoria: documentoAntigo.categoria,
                        descricao: data.descricao ?? null,
                        dataValidade: data.dataValidade ?? null,
                        tipoVeiculo: documentoAntigo.tipoVeiculo,
                        veiculoId: documentoAntigo.veiculoId,
                        status: 'VIGENTE',
                        documentoOrigemId: id
                    }
                });

                return novoDocumento;
            });

            return res.status(201).json(renovacaoResult);
        } catch (error) {
            if (error instanceof z.ZodError) {
                return res.status(400).json({
                    message: 'Dados inválidos',
                    errors: (error as z.ZodError).issues
                });
            }
            console.error('Erro ao renovar documento:', error);
            return res.status(500).json({ error: 'Erro ao renovar documento' });
        }
    }

    // DELETAR
    async delete(req: Request, res: Response) {
        const { id } = req.params;

        if (!id) {
            return res.status(400).json({ error: 'ID do documento é obrigatório' });
        }

        try {
            await prisma.documentoLegal.delete({
                where: { id }
            });
            return res.status(204).send();
        } catch (error) {
            console.error('Erro ao deletar documento:', error);
            return res.status(500).json({ error: 'Erro ao remover documento' });
        }
    }
}