import { Response, Request, NextFunction } from 'express';
import { prisma } from '../lib/prisma';
import { AuthenticatedRequest } from '../middleware/auth';

export class RHController {
    getKpis = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            if (!['ADMIN', 'RH', 'ENCARREGADO'].includes(req.user?.role || '')) {
                res.status(403).json({ error: 'Acesso negado.' });
                return;
            }

            const hoje = new Date();
            const limite30Dias = new Date();
            limite30Dias.setDate(hoje.getDate() + 30);

            // 1. Total Integrantes (Ativos)
            const totalIntegrantes = await prisma.user.count({
                where: { status: 'ATIVO' }
            });

            // 2. Treinamentos Críticos (Vencidos ou Vencendo em 30 dias)
            const treinamentosCriticos = await prisma.treinamento.count({
                where: {
                    dataVencimento: { not: null, lte: limite30Dias }
                }
            });

            // 3. CNHs a Vencer (dentro de 30 dias ou vencidas)
            const cnhsCriticas = await prisma.colaboradorProfile.count({
                where: {
                    cnhValidade: { not: null, lte: limite30Dias }
                }
            });

            // 4. Ações SST Pendentes
            const sstPendentes = await prisma.acaoSST.count({
                where: { status: { in: ['PENDENTE', 'ATRASADO'] } }
            });

            // 5. Distribuição por Cargos
            const cargosAtivos = await prisma.user.groupBy({
                by: ['role'],
                _count: { role: true },
                where: { status: 'ATIVO' }
            });
            const distribuicaoCargos = cargosAtivos.map(c => ({
                name: c.role,
                value: c._count.role
            }));

            // 6. Panorama SST (Pizza)
            const sstStatus = await prisma.acaoSST.groupBy({
                by: ['status'],
                _count: { status: true }
            });
            const panoramaSST = sstStatus.map(s => ({
                name: s.status,
                value: s._count.status
            }));

            res.json({
                kpis: {
                    totalIntegrantes,
                    treinamentosCriticos,
                    cnhsCriticas,
                    sstPendentes
                },
                graficos: {
                    distribuicaoCargos,
                    panoramaSST
                }
            });
        } catch (error) {
            next(error);
        }
    };

    getMatrizQualificacao = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            if (!['ADMIN', 'RH', 'ENCARREGADO'].includes(req.user?.role || '')) {
                res.status(403).json({ error: 'Acesso negado.' });
                return;
            }

            const usuarios = await prisma.user.findMany({
                where: { status: 'ATIVO' },
                include: {
                    profile: true,
                    cargo: {
                        include: {
                            requisitos: true
                        }
                    },
                    treinamentos: true
                }
            });

            const hoje = new Date();

            const matriz = usuarios.map(user => {
                const exigencias: any[] = [];

                // 1. CNH (Se preenchida no perfil, conta como exigência)
                if (user.profile?.cnhNumero) {
                    const validade = user.profile.cnhValidade;
                    let status = 'VÁLIDO';
                    if (!validade || validade < hoje) {
                        status = 'VENCIDO';
                    } else {
                        const diasParaVencer = Math.floor((validade.getTime() - hoje.getTime()) / (1000 * 3600 * 24));
                        if (diasParaVencer <= 30) status = 'VENCENDO';
                    }
                    exigencias.push({
                        tipo: 'CNH',
                        nome: `CNH Cat. ${user.profile.cnhCategoria || '-'}`,
                        validade: validade,
                        status
                    });
                }

                // 2. ASO, Fit Test e Treinamentos (Buscando pelo nome, ASO e Fit test costumam estar como treinamento)
                const treinamentosRelevantes = user.treinamentos.filter(t => 
                    t.nome.toUpperCase().includes('ASO') || 
                    t.nome.toUpperCase().includes('FIT TEST') ||
                    !user.cargo?.requisitos.some(req => req.nome.toUpperCase() === t.nome.toUpperCase()) // Adiciona treinamentos que ele tem mas não são obrigatórios
                );

                for (const t of treinamentosRelevantes) {
                    let status = 'VÁLIDO';
                    if (t.dataVencimento) {
                        if (t.dataVencimento < hoje) {
                            status = 'VENCIDO';
                        } else {
                            const diasParaVencer = Math.floor((t.dataVencimento.getTime() - hoje.getTime()) / (1000 * 3600 * 24));
                            if (diasParaVencer <= t.diasAntecedenciaAlerta) status = 'VENCENDO';
                        }
                    }
                    
                    exigencias.push({
                        tipo: t.nome.toUpperCase().includes('ASO') ? 'ASO' : (t.nome.toUpperCase().includes('FIT TEST') ? 'FIT_TEST' : 'TREINAMENTO'),
                        nome: t.nome,
                        validade: t.dataVencimento,
                        status
                    });
                }

                // 3. Treinamentos Obrigatórios do Cargo
                if (user.cargo?.requisitos) {
                    for (const req of user.cargo.requisitos) {
                        const tUser = user.treinamentos.find(t => t.nome.toUpperCase() === req.nome.toUpperCase());
                        let status = 'FALTANTE';
                        let validade = null;

                        if (tUser) {
                            status = 'VÁLIDO';
                            validade = tUser.dataVencimento;
                            if (tUser.dataVencimento) {
                                if (tUser.dataVencimento < hoje) {
                                    status = 'VENCIDO';
                                } else {
                                    const diasParaVencer = Math.floor((tUser.dataVencimento.getTime() - hoje.getTime()) / (1000 * 3600 * 24));
                                    if (diasParaVencer <= req.diasAntecedenciaAlerta) status = 'VENCENDO';
                                }
                            }
                        }

                        // Substituir ou adicionar na lista (já que pode ter sido pego no loop de "TreinamentosRelevantes" acima, vamos checar se já existe)
                        const existsIndex = exigencias.findIndex(e => e.nome.toUpperCase() === req.nome.toUpperCase());
                        if (existsIndex >= 0) {
                             exigencias[existsIndex].status = status;
                             exigencias[existsIndex].tipo = 'OBRIGATORIO';
                        } else {
                             exigencias.push({
                                tipo: 'OBRIGATORIO',
                                nome: req.nome,
                                validade,
                                status
                             });
                        }
                    }
                }

                return {
                    userId: user.id,
                    nome: user.nome,
                    cargo: user.cargo?.nome || 'Sem Cargo',
                    exigencias
                };
            });

            res.json(matriz);
        } catch (error) {
            next(error);
        }
    }
}
