import { Request, Response, NextFunction } from 'express';
import { prisma } from '../lib/prisma';
import bcrypt from 'bcrypt';
import crypto from 'crypto';
import { AuthenticatedRequest } from '../middleware/auth';
import { Prisma } from '@prisma/client';
import { z } from 'zod';
import { registerUserSchema } from '../schemas/auth.schemas';

// Extraímos o tipo do schema de registro
type RegisterUserData = z.infer<typeof registerUserSchema>['body'];

export class UserController {

    /**
     * Cria um novo utilizador.
     */
    create = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            // 1. Validação de Permissão Básica
            const currentUserRole = req.user?.role || '';
            if (!['ADMIN', 'RH'].includes(currentUserRole)) {
                res.status(403).json({ error: 'Acesso não autorizado.' });
                return;
            }

            const dados = req.body as RegisterUserData;

            // 2. Regras de Hierarquia
            if (currentUserRole === 'RH' && dados.role === 'ADMIN') {
                res.status(403).json({ error: 'RH não pode criar usuários Administradores.' });
                return;
            }
            if (dados.role === 'ADMIN' && currentUserRole !== 'ADMIN') {
                res.status(403).json({ error: 'Apenas ADMIN pode criar outro ADMIN.' });
                return;
            }

            // 3. Hash da Senha
            const salt = await bcrypt.genSalt(10);
            const hashedPassword = await bcrypt.hash(dados.password, salt);

            //  Gerar token inicial automaticamente para Operadores/Encarregados
            let initialLoginToken = null;
            if (['OPERADOR', 'ENCARREGADO'].includes(dados.role || '')) {
                initialLoginToken = crypto.randomBytes(32).toString('hex');
            }

            // 4. Criação no Banco
            const nomeNormalizado = dados.nome ? dados.nome.normalize("NFD").replace(/[\u0300-\u036f]/g, "") : dados.nome;

            const novoUser = await prisma.user.create({
                data: {
                    // Dados da tabela USER
                    nome: nomeNormalizado,
                    email: dados.email,
                    password: hashedPassword,
                    role: dados.role || 'OPERADOR',
                    matricula: dados.matricula ?? null,
                    image: dados.fotoUrl ?? null,
                    cargoId: dados.cargoId ?? null,
                    loginToken: initialLoginToken, // Já nasce com token!

                    // Dados da tabela COLABORADOR_PROFILE (Nested Write)
                    profile: {
                        create: {
                            cnhNumero: dados.cnhNumero ?? null,
                            cnhCategoria: dados.cnhCategoria ?? null,
                            cnhValidade: dados.cnhValidade ? new Date(dados.cnhValidade) : null,
                            dataAdmissao: dados.dataAdmissao ? new Date(dados.dataAdmissao) : null,
                        }
                    }
                },
                include: {
                    profile: true // Retorna o perfil criado para confirmação
                }
            });

            // 5. Retorno Seguro (Sem senha, mas COM token se existir)
            const { password: _, image, ...userSemSenha } = novoUser;
            res.status(201).json({ ...userSemSenha, fotoUrl: image });

        } catch (error) {
            next(error);
        }
    }

    list = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            const users = await prisma.user.findMany({
                select: {
                    id: true,
                    nome: true,
                    email: true,
                    role: true,
                    matricula: true,
                    image: true,
                    cargoId: true,
                    loginToken: true,

                    cargo: { select: { nome: true } },
                    profile: {
                        select: {
                            cnhNumero: true,
                            cnhCategoria: true,
                            cnhValidade: true
                        }
                    }
                },
                orderBy: { nome: 'asc' }
            });

            const userRole = req.user?.role || '';
            const isAdminOrManager = ['ADMIN', 'ENCARREGADO'].includes(userRole);

            const safeUsers = users.map(u => {
                // 🔐 007 Fix: Remoção segura de campos sensíveis sem cast 'as any'
                const { loginToken, image, ...rest } = u;
                if (!isAdminOrManager || (userRole === 'ENCARREGADO' && u.role === 'ADMIN')) {
                    return { ...rest, fotoUrl: image };
                }
                return { ...rest, loginToken, fotoUrl: image };
            });
            res.json(safeUsers);
        } catch (error) {
            next(error);
        }
    }

    getById = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            if (!['ADMIN', 'RH'].includes(req.user?.role || '')) {
                res.status(403).json({ error: 'Acesso negado.' });
                return;
            }

            const { id } = req.params;

            if (!id) {
                res.status(400).json({ error: 'ID não fornecido.' });
                return;
            }

            const user = await prisma.user.findUnique({
                where: { id },
                include: {
                    cargo: true,
                    profile: true // Inclui dados sensíveis (CNH, Admissão)
                }
            });

            if (!user) {
                res.status(404).json({ error: 'Usuário não encontrado' });
                return;
            }

            const userRole = req.user?.role || '';
            const isAdminOrManager = ['ADMIN', 'ENCARREGADO'].includes(userRole);

            // 🔐 007 Fix: Remoção segura de senha e token
            const { password, loginToken, image, ...userSafe } = user;
            
            const result = {
                ...userSafe,
                fotoUrl: image,
                // O token só é retornado para Admin/Encarregado, e nunca sobre o Admin se o solicitante for Encarregado
                ...(isAdminOrManager && !(userRole === 'ENCARREGADO' && user.role === 'ADMIN') ? { loginToken } : {})
            };
            
            res.json(result);
        } catch (error) {
            next(error);
        }
    }

    update = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            const currentUserRole = req.user?.role || '';
            if (!['ADMIN', 'RH'].includes(currentUserRole)) {
                res.status(403).json({ error: 'Acesso negado.' });
                return;
            }

            const { id } = req.params;

            if (!id) {
                res.status(400).json({ error: 'ID não fornecido.' });
                return;
            }

            const {
                nome, email, matricula, role, password,
                cargoId, cnhNumero, cnhCategoria, cnhValidade, dataAdmissao, fotoUrl
            } = req.body;

            // Segurança: RH vs ADMIN
            if (currentUserRole === 'RH') {
                const alvo = await prisma.user.findUnique({ where: { id }, select: { role: true } });

                if (alvo?.role === 'ADMIN') {
                    res.status(403).json({ error: 'RH não pode alterar dados de um Administrador.' });
                    return;
                }
                if (role === 'ADMIN') {
                    res.status(403).json({ error: 'RH não pode promover usuários a Administrador.' });
                    return;
                }
            }

            // Preparar objeto de update para o USUÁRIO (Tipagem Prisma explícita)
            // 🔐 007 Fix: Construção limpa sem iteração de chaves (evita erro TS7053)
            const nomeNormalizado = nome ? nome.normalize("NFD").replace(/[\u0300-\u036f]/g, "") : undefined;

            const dataToUpdateUser: Prisma.UserUpdateInput = {
                nome: nomeNormalizado !== undefined ? nomeNormalizado : undefined,
                email: email !== undefined ? email : undefined,
                role: role !== undefined ? role : undefined,
                matricula: matricula !== undefined ? (matricula || null) : undefined,
                image: fotoUrl !== undefined ? (fotoUrl || null) : undefined,
                // @ts-ignore - cargoId existe como escalar no schema mas o Prisma Client às vezes prefere 'cargo' no input
                cargoId: cargoId !== undefined ? (cargoId || null) : undefined,
            };

            // Se tiver senha nova
            if (password && password.trim() !== '') {
                dataToUpdateUser.password = await bcrypt.hash(password, 10);
            }

            // Dados para o PERFIL (ColaboradorProfile)
            const profileData = {
                cnhNumero: cnhNumero || null,
                cnhCategoria: cnhCategoria || null,
                cnhValidade: cnhValidade ? new Date(cnhValidade) : null,
                dataAdmissao: dataAdmissao ? new Date(dataAdmissao) : null
            };

            // Executa o Update com Nested Update no Profile
            const updated = await prisma.user.update({
                where: { id },
                data: {
                    ...dataToUpdateUser,
                    // Lógica inteligente para o Perfil:
                    // Se o usuário já tem perfil, atualiza. Se não tem (ex: Admin antigo), cria.
                    profile: {
                        upsert: {
                            create: profileData,
                            update: profileData
                        }
                    }
                },
                select: {
                    id: true,
                    nome: true,
                    email: true,
                    role: true,
                    matricula: true,
                    image: true,
                    profile: true // Retorna o perfil atualizado
                }
            });

            const { image, ...rest } = updated;
            res.json({ ...rest, fotoUrl: image });
        } catch (error) {
            next(error);
        }
    }

    /**
     * NANO-ENDPOINT: Atualiza apenas o status (Usado pela Inteligência de Ociosidade)
     */
    updateStatus = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            if (!['ADMIN', 'ENCARREGADO'].includes(req.user?.role || '')) {
                return res.status(403).json({ error: 'Acesso negado.' });
            }
            const { id } = req.params;
            const { status } = req.body;

            if (!id || !status) return res.status(400).json({ error: 'Parâmetros incompletos' });

            const user = await prisma.user.update({
                where: { id },
                data: { status }
            });

            res.json({ message: 'Status atualizado com sucesso', status: user.status });
        } catch (error) { next(error); }
    }

    delete = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            const currentUserRole = req.user?.role || '';
            if (!['ADMIN', 'RH'].includes(currentUserRole)) {
                res.status(403).json({ error: 'Acesso negado.' });
                return;
            }

            const { id } = req.params;

            if (!id) {
                res.status(400).json({ error: 'ID não fornecido.' });
                return;
            }

            if (req.user?.userId === id) {
                res.status(400).json({ error: 'Não pode remover a si mesmo.' });
                return;
            }

            const alvo = await prisma.user.findUnique({ where: { id }, select: { role: true, nome: true } });
            if (currentUserRole === 'RH') {
                if (alvo?.role === 'ADMIN') {
                    res.status(403).json({ error: 'RH não pode remover um Administrador.' });
                    return;
                }
            }

            // REGRA DE NEGÓCIO: Soft Delete Inteligente (007 Data Integrity)
            const countJornadas = await prisma.jornada.count({
                where: { OR: [{ operadorId: id }, { encarregadoId: id }] }
            });

            if (countJornadas > 0) {
                await prisma.user.update({
                    where: { id },
                    data: {
                        nome: `[INATIVO] ${alvo?.nome || 'Usuário'}`,
                        email: `inativo_${Date.now()}_${id}@klin.hidden`,
                        password: 'conta_inativada_por_seguranca',
                        loginToken: null
                    }
                });
                return res.json({ message: 'Colaborador possui histórico na frota. Seus acessos (Login e Tokens) foram revogados e a conta arquivada como INATIVA (Soft-Delete).' });
            }

            await prisma.user.delete({ where: { id } });
            res.json({ message: 'Usuário Inédito removido com sucesso (Sem rastro)' });
        } catch (error) {
            next(error);
        }
    }

    /**
     * Lista Encarregados e Admins para o Dropdown
     * Este método é leve e seguro para ser consumido pelo Operador.
     */
    listarEncarregados = async (req: Request, res: Response, next: NextFunction) => {
        try {
            const usuarios = await prisma.user.findMany({
                where: {
                    // Busca quem pode ser responsável pela liberação
                    role: { in: ['ENCARREGADO', 'ADMIN'] }
                },
                select: {
                    id: true,
                    nome: true,
                    role: true,
                    image: true,
                    cargo: { select: { nome: true } }
                },
                orderBy: { nome: 'asc' }
            });
            res.json(usuarios.map(({ image, ...u }) => ({ ...u, fotoUrl: image })));
        } catch (error) {
            next(error);
        }
    }

    /**
     * Retorna o Dossiê Completo do Integrante
     * Inclui Perfil, CNH, Treinamentos, Defeitos Registrados e Jornadas Paginadas
     */
    getDossie = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
        try {
            if (!['ADMIN', 'RH', 'COORDENADOR', 'ENCARREGADO'].includes(req.user?.role || '')) {
                res.status(403).json({ error: 'Acesso negado ao Dossiê.' });
                return;
            }

            const { id } = req.params;
            const page = Math.max(1, parseInt(req.query.page as string || '1'));
            const limit = 30; // 30 jornadas por página

            const user = await prisma.user.findUnique({
                where: { id },
                include: {
                    cargo: true,
                    profile: true,
                    treinamentos: {
                        orderBy: { dataVencimento: 'asc' }
                    },
                    defeitosRegistrados: {
                        take: 20, // últimos 20 defeitos registrados
                        orderBy: { createdAt: 'desc' },
                        include: { veiculo: { select: { placa: true } } }
                    }
                }
            });

            if (!user) {
                res.status(404).json({ error: 'Integrante não encontrado.' });
                return;
            }

            // Paginação para Jornadas
            const [jornadas, totalJornadas] = await Promise.all([
                prisma.jornada.findMany({
                    where: { operadorId: id },
                    orderBy: { dataInicio: 'desc' },
                    skip: (page - 1) * limit,
                    take: limit,
                    include: {
                        veiculo: { select: { placa: true } }
                    }
                }),
                prisma.jornada.count({ where: { operadorId: id } })
            ]);

            const { password, loginToken, image, ...userSafe } = user;
            const fotoUrl = image;
            const userRole = req.user?.role || '';
            const isAdminOrManager = ['ADMIN', 'ENCARREGADO'].includes(userRole);

            res.json({
                user: {
                    ...userSafe,
                    fotoUrl,
                    ...(isAdminOrManager && !(userRole === 'ENCARREGADO' && user.role === 'ADMIN') ? { loginToken } : {})
                },
                jornadas,
                pagination: {
                    page,
                    limit,
                    total: totalJornadas,
                    totalPages: Math.ceil(totalJornadas / limit)
                }
            });
        } catch (error) {
            next(error);
        }
    }
}
