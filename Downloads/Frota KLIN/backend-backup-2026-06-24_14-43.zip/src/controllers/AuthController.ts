import { Request, Response } from 'express';
import { prisma } from '../lib/prisma';
import crypto from 'crypto';
import { AuthenticatedRequest } from '../middleware/auth';
import { z } from 'zod';
import {
    loginWithTokenSchema,
    generateTokenSchema
} from '../schemas/auth.schemas';
import { auth } from '../auth';
import { toNodeHandler } from "better-auth/node";

type LoginTokenData = z.infer<typeof loginWithTokenSchema>['body'];
type GenerateTokenParams = z.infer<typeof generateTokenSchema>['params'];

export class AuthController {
    
    static async loginWithToken(req: Request, res: Response) {
        try {
            const { loginToken } = req.body as LoginTokenData;

            // 1. Busca pelo token dinâmico (hex padrão 007)
            let user = await prisma.user.findFirst({
                where: { loginToken },
                include: { profile: true }
            });

            // 2. Fallback: Se não encontrou pelo token, busca pela MATRÍCULA
            if (!user) {
                user = await prisma.user.findUnique({
                    where: { matricula: loginToken },
                    include: { profile: true }
                });
            }

            if (!user) return res.status(401).json({ error: 'Token ou Código inválido.' });

            // Cria a sessão com Better Auth
            // O ideal para QR code seria usar a API do better-auth para criar a sessão manualmente.
            // Para não quebrar o padrão antigo que retorna { token, user: {...} }, vamos manter a resposta
            // Porém o JWT antigo expirava em 365d. 
            // O frontend usa esse token manual: sessionStorage.setItem('authToken', res.data.token)
            // Se removermos o JWT manual agora, o app móvel quebrando QR Code precisaria atualizar a lógica de sessão.
            // Mas decidimos usar Better-Auth full stack! 
            // Cria a sessão com Prisma compatível com Better-Auth
            const sessionToken = crypto.randomBytes(32).toString('hex');
            const expiresAt = new Date(Date.now() + 1000 * 60 * 60 * 24 * 365); // 365 dias

            const session = await prisma.session.create({
                data: {
                    id: crypto.randomUUID(),
                    token: sessionToken,
                    expiresAt,
                    userId: user.id,
                    createdAt: new Date(),
                    updatedAt: new Date(),
                }
            });

            res.status(200).json({
                message: 'Login por token/código OK',
                token: session.token,
                user: {
                    id: user.id,
                    nome: user.nome,
                    email: user.email,
                    role: user.role,
                    fotoUrl: user.image, // 🔐 007 Fix: Mapeado de volta pro formato esperado no front (agora é image no DB)
                    loginToken: user.loginToken || user.matricula,

                    matricula: user.matricula,
                    cargoId: user.cargoId,
                    cnhNumero: user.profile?.cnhNumero || null,
                    cnhCategoria: user.profile?.cnhCategoria || null,
                    cnhValidade: user.profile?.cnhValidade || null,
                    dataAdmissao: user.profile?.dataAdmissao || null
                },
            });
        } catch (error) {
            console.error("Erro login token:", error);
            res.status(500).json({ error: 'Erro interno.' });
        }
    }

    static async generateToken(req: AuthenticatedRequest, res: Response) {
        try {
            const { id } = req.params as GenerateTokenParams;

            if (req.user?.role !== 'ADMIN' && req.user?.role !== 'ENCARREGADO' && req.user?.userId !== id) {
                return res.status(403).json({ error: 'Acesso negado. Apenas gestores podem gerar QR Code para terceiros.' });
            }

            const userToCheck = await prisma.user.findUnique({ where: { id } });
            if (!userToCheck) return res.status(404).json({ error: 'Usuário não encontrado.' });

            if (userToCheck.role !== 'OPERADOR' && userToCheck.role !== 'ENCARREGADO') {
                return res.status(400).json({ error: 'Apenas Operadores e Encarregados podem ter acesso via QR Code.' });
            }

            const token = crypto.randomBytes(32).toString('hex');

            await prisma.user.update({
                where: { id },
                data: { loginToken: token }
            });

            res.json({ loginToken: token });
        } catch (error) {
            console.error("Erro ao gerar token:", error);
            res.status(500).json({ error: 'Erro ao gerar token.' });
        }
    }
}