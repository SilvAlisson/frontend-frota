import { Request, Response } from 'express';
import { prisma } from '../lib/prisma';

export interface IDrillDownData {
    mes?: number;
    custo?: number;
    id?: string;
    name?: string;
    veiculoId?: string;
    value?: number;
    fornecedorNome?: string;
    dataInicio?: Date;
    kmInicio?: number;
    kmFim?: number | null;
    dataHora?: Date;
    custoTotal?: number;
    data?: Date;
}


export class DrillDownController {
    
    // Nível 1: Macro - Gastos Gerais agrupados por Veículo
    async getMacroGastos(req: Request, res: Response) {
        try {
            const { ano, mes, categoria } = req.query;
            let dateFilter = {};
            
            if (ano) {
                const year = Number(ano);
                if (mes) {
                    const month = Number(mes) - 1; // 0-indexed
                    dateFilter = {
                        gte: new Date(year, month, 1),
                        lt: new Date(year, month + 1, 1)
                    };
                } else {
                    dateFilter = {
                        gte: new Date(year, 0, 1),
                        lt: new Date(year + 1, 0, 1)
                    };
                }
            }

            let abastecimentos: { veiculoId: string; _sum: { custoTotal: any } }[] = [];
            let manutencoes: { veiculoId: string; _sum: { custoTotal: any } }[] = [];

            if (categoria === 'ADITIVO') {
                const itensAditivo = await prisma.itemAbastecimento.findMany({
                    where: {
                        produto: { tipo: 'ADITIVO' },
                        abastecimento: ano ? { dataHora: dateFilter } : {}
                    },
                    select: { valorTotal: true, abastecimento: { select: { veiculoId: true } } }
                });
                
                const groupedAditivos = new Map<string, number>();
                for (const item of itensAditivo) {
                    const vId = item.abastecimento?.veiculoId || '';
                    groupedAditivos.set(vId, (groupedAditivos.get(vId) || 0) + Number(item.valorTotal));
                }
                
                abastecimentos = Array.from(groupedAditivos.entries()).map(([veiculoId, total]) => ({ veiculoId, _sum: { custoTotal: total } }));
            } else {
                if (categoria !== 'MANUTENCAO') {
                    const abs = await prisma.abastecimento.groupBy({
                        by: ['veiculoId'],
                        _sum: { custoTotal: true },
                        where: ano ? { dataHora: dateFilter } : {}
                    });
                    abastecimentos = abs as { veiculoId: string; _sum: { custoTotal: any } }[];
                }

                if (categoria !== 'ABASTECIMENTO') {
                    const mans = await prisma.ordemServico.groupBy({
                        by: ['veiculoId'],
                        _sum: { custoTotal: true },
                        where: { status: 'CONCLUIDA', ...(ano ? { data: dateFilter } : {}) }
                    });
                    manutencoes = mans as { veiculoId: string; _sum: { custoTotal: any } }[];
                }
            }

            const veiculos = await prisma.veiculo.findMany({ select: { id: true, placa: true } });
            const veiculosMap = new Map(veiculos.map(v => [v.id, v.placa]));

            const custosMap = new Map<string, { name: string; veiculoId: string; value: number }>();

            abastecimentos.forEach(ab => {
                const placa = veiculosMap.get(ab.veiculoId) || 'Sem Placa (Dados Antigos)';
                const current = custosMap.get(placa) || { name: placa, veiculoId: ab.veiculoId, value: 0 };
                current.value += Number(ab._sum.custoTotal || 0);
                custosMap.set(placa, current);
            });

            manutencoes.forEach(man => {
                const veiculoId = man.veiculoId || '';
                const placa = veiculosMap.get(veiculoId) || 'Sem Placa (Dados Antigos)';
                const current = custosMap.get(placa) || { name: placa, veiculoId: veiculoId, value: 0 };
                current.value += Number(man._sum.custoTotal || 0);
                custosMap.set(placa, current);
            });

            // Remove o rótulo "Sem Placa" caso exista (registros órfãos que causam sujeira visual)
            custosMap.delete('Sem Placa (Dados Antigos)');

            const result = Array.from(custosMap.values()).sort((a, b) => (b.value || 0) - (a.value || 0));

            res.json(result);
        } catch (error) {
            console.error('Erro em getMacroGastos:', error);
            res.status(500).json({ error: 'Erro interno ao gerar drill-down macro' });
        }
    }

    // Nível 2: Veículo Específico - Divisão de Gastos
    async getVeiculoBreakdown(req: Request, res: Response) {
        try {
            const { veiculoId } = req.query;
            if (!veiculoId || typeof veiculoId !== 'string') {
                return res.status(400).json({ error: 'veiculoId é obrigatório' });
            }

            const { ano, mes } = req.query;
            let dateFilterAbast = {};
            let dateFilterMan = {};
            
            if (ano) {
                const year = Number(ano);
                let gte, lt;
                if (mes) {
                    const month = Number(mes) - 1;
                    gte = new Date(year, month, 1);
                    lt = new Date(year, month + 1, 1);
                } else {
                    gte = new Date(year, 0, 1);
                    lt = new Date(year + 1, 0, 1);
                }
                dateFilterAbast = { dataHora: { gte, lt } };
                dateFilterMan = { data: { gte, lt } };
            }

            const abastecimentoSum = await prisma.abastecimento.aggregate({
                _sum: { custoTotal: true },
                where: { veiculoId, ...dateFilterAbast }
            });

            const manutencaoSum = await prisma.ordemServico.aggregate({
                _sum: { custoTotal: true },
                where: { veiculoId, status: 'CONCLUIDA', ...dateFilterMan }
            });

            res.json([
                { name: 'Abastecimento', value: Number(abastecimentoSum._sum.custoTotal || 0) },
                { name: 'Manutenção', value: Number(manutencaoSum._sum.custoTotal || 0) }
            ]);

        } catch (error) {
            console.error('Erro em getVeiculoBreakdown:', error);
            res.status(500).json({ error: 'Erro interno ao buscar breakdown do veículo' });
        }
    }

    // Nível 3: Evolução Temporal
    async getEvolucaoTemporal(req: Request, res: Response) {
        try {
            const { veiculoId, categoria } = req.query;
            if (!veiculoId || typeof veiculoId !== 'string') {
                return res.status(400).json({ error: 'veiculoId é obrigatório' });
            }
            if (!categoria || (categoria !== 'ABASTECIMENTO' && categoria !== 'MANUTENCAO' && categoria !== 'ADITIVO')) {
                return res.status(400).json({ error: 'categoria inválida (ABASTECIMENTO, MANUTENCAO ou ADITIVO)' });
            }

            // Simplificação para mensal do ano corrente se não for passado nada
            const ano = req.query.ano ? Number(req.query.ano) : new Date().getFullYear();
            
            let data: IDrillDownData[] = [];

            if (categoria === 'ADITIVO') {
                const itensAditivo = await prisma.itemAbastecimento.findMany({
                    where: {
                        produto: { tipo: 'ADITIVO' },
                        abastecimento: { veiculoId, dataHora: { gte: new Date(ano, 0, 1), lt: new Date(ano + 1, 0, 1) } }
                    },
                    select: { valorTotal: true, id: true, abastecimento: { select: { dataHora: true } } }
                });

                data = itensAditivo.map(item => ({
                    mes: item.abastecimento?.dataHora.getMonth() || 0,
                    custo: Number(item.valorTotal),
                    id: item.id
                }));
            } else if (categoria === 'ABASTECIMENTO') {
                const abastecimentos = await prisma.abastecimento.findMany({
                    where: {
                        veiculoId,
                        dataHora: { gte: new Date(ano, 0, 1), lt: new Date(ano + 1, 0, 1) }
                    },
                    select: { dataHora: true, custoTotal: true, id: true }
                });

                data = abastecimentos.map(a => ({
                    mes: a.dataHora.getMonth(),
                    custo: Number(a.custoTotal),
                    id: a.id
                }));
            } else {
                const manutencoes = await prisma.ordemServico.findMany({
                    where: {
                        veiculoId,
                        status: 'CONCLUIDA',
                        data: { gte: new Date(ano, 0, 1), lt: new Date(ano + 1, 0, 1) }
                    },
                    select: { data: true, custoTotal: true, id: true }
                });

                data = manutencoes.map(m => ({
                    mes: m.data.getMonth(),
                    custo: Number(m.custoTotal),
                    id: m.id
                }));
            }

            // Agrupamento Mensal
            const meses = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
            const resultadoMensal = meses.map((m, index) => {
                const itensMes = data.filter(d => d.mes === index);
                return {
                    name: m,
                    mesIndex: index,
                    value: itensMes.reduce((acc, curr) => acc + (curr.custo || 0), 0),
                    ticketsCount: itensMes.length
                };
            });

            res.json(resultadoMensal);
        } catch (error) {
            console.error('Erro em getEvolucaoTemporal:', error);
            res.status(500).json({ error: 'Erro interno ao buscar evolução temporal' });
        }
    }

    public async getFornecedoresBreakdown(req: Request, res: Response) {
        try {
            const veiculoId = req.query.veiculoId as string;
            const categoria = req.query.categoria as string;
            const mesStr = req.query.mes as string;
            
            if (!veiculoId || !categoria || !mesStr) {
                return res.status(400).json({ error: 'Parâmetros veiculoId, categoria e mes são obrigatórios' });
            }

            const meses = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
            const mesIndex = meses.indexOf(mesStr);
            if (mesIndex === -1) {
                return res.status(400).json({ error: 'Mês inválido' });
            }

            const ano = req.query.ano ? Number(req.query.ano) : new Date().getFullYear();
            const startOfMonth = new Date(ano, mesIndex, 1);
            const endOfMonth = new Date(ano, mesIndex + 1, 1);

            let data: IDrillDownData[] = [];

            if (categoria === 'ADITIVO') {
                const itensAditivo = await prisma.itemAbastecimento.findMany({
                    where: {
                        produto: { tipo: 'ADITIVO' },
                        abastecimento: { veiculoId, dataHora: { gte: startOfMonth, lt: endOfMonth } }
                    },
                    include: { abastecimento: { include: { fornecedor: true } } }
                });

                data = itensAditivo.map(item => ({
                    fornecedorNome: item.abastecimento?.fornecedor?.nome || 'Desconhecido',
                    custo: Number(item.valorTotal)
                }));
            } else if (categoria === 'ABASTECIMENTO') {
                const abastecimentos = await prisma.abastecimento.findMany({
                    where: {
                        veiculoId,
                        dataHora: { gte: startOfMonth, lt: endOfMonth }
                    },
                    include: { fornecedor: true }
                });

                data = abastecimentos.map(a => ({
                    fornecedorNome: a.fornecedor.nome,
                    custo: Number(a.custoTotal)
                }));
            } else {
                const manutencoes = await prisma.ordemServico.findMany({
                    where: {
                        veiculoId,
                        status: 'CONCLUIDA',
                        data: { gte: startOfMonth, lt: endOfMonth }
                    },
                    include: { fornecedor: true }
                });

                data = manutencoes.map(m => ({
                    fornecedorNome: m.fornecedor.nome,
                    custo: Number(m.custoTotal)
                }));
            }

            // Agrupar por fornecedor
            const agrupado: Record<string, number> = {};
            for (const item of data) {
                const nome = item.fornecedorNome || 'Desconhecido';
                if (!agrupado[nome]) agrupado[nome] = 0;
                agrupado[nome] += (item.custo || 0);
            }

            const resultado = Object.keys(agrupado).map(key => ({
                name: key,
                value: agrupado[key]
            })).sort((a, b) => (b.value || 0) - (a.value || 0));

            res.json(resultado);
        } catch (error) {
            console.error('Erro em getFornecedoresBreakdown:', error);
            res.status(500).json({ error: 'Erro interno ao buscar fornecedores' });
        }
    }
    public async getKmMacro(req: Request, res: Response) {
        try {
            const { ano } = req.query;
            let dateFilter = {};
            if (ano) {
                const year = Number(ano);
                dateFilter = { gte: new Date(year, 0, 1), lt: new Date(year + 1, 0, 1) };
            }

            const jornadas = await prisma.jornada.findMany({
                where: { kmFim: { not: null }, ...(ano ? { dataInicio: dateFilter } : {}) },
                select: { veiculoId: true, kmInicio: true, kmFim: true }
            });

            const veiculos = await prisma.veiculo.findMany({ select: { id: true, placa: true } });
            const veiculosMap = new Map(veiculos.map(v => [v.id, v.placa]));

            const kmMap: Record<string, { name: string; veiculoId: string; value: number }> = {};

            for (const j of jornadas) {
                const placa = veiculosMap.get(j.veiculoId) || 'Sem Placa';
                if (placa === 'Sem Placa') continue;
                
                if (!kmMap[placa]) {
                    kmMap[placa] = { name: placa, veiculoId: j.veiculoId, value: 0 };
                }
                kmMap[placa].value += ((j.kmFim || 0) - j.kmInicio);
            }

            const result = Object.values(kmMap).sort((a, b) => (b.value || 0) - (a.value || 0));
            res.json(result);
        } catch (error) {
            console.error('Erro em getKmMacro:', error);
            res.status(500).json({ error: 'Erro ao gerar macro de KM' });
        }
    }

    public async getKmTemporal(req: Request, res: Response) {
        try {
            const veiculoId = req.query.veiculoId as string;
            const ano = req.query.ano ? Number(req.query.ano) : new Date().getFullYear();

            if (!veiculoId) return res.status(400).json({ error: 'veiculoId é obrigatório' });

            const jornadas = await prisma.jornada.findMany({
                where: { 
                    veiculoId, 
                    kmFim: { not: null },
                    dataInicio: { gte: new Date(ano, 0, 1), lt: new Date(ano + 1, 0, 1) }
                },
                select: { dataInicio: true, kmInicio: true, kmFim: true }
            });

            const meses = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
            const resultadoMensal = meses.map((m, index) => {
                const itensMes = jornadas.filter(d => d.dataInicio.getMonth() === index);
                return {
                    name: m,
                    mesIndex: index,
                    value: itensMes.reduce((acc, curr) => acc + ((curr.kmFim || 0) - curr.kmInicio), 0),
                    ticketsCount: itensMes.length
                };
            });

            res.json(resultadoMensal);
        } catch (error) {
            console.error('Erro em getKmTemporal:', error);
            res.status(500).json({ error: 'Erro ao gerar evolução temporal de KM' });
        }
    }

    public async getKmOperadores(req: Request, res: Response) {
        try {
            const veiculoId = req.query.veiculoId as string;
            const mesStr = req.query.mes as string;
            const ano = req.query.ano ? Number(req.query.ano) : new Date().getFullYear();

            if (!veiculoId || !mesStr) return res.status(400).json({ error: 'veiculoId e mes são obrigatórios' });

            const meses = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
            const mesIndex = meses.indexOf(mesStr);
            if (mesIndex === -1) return res.status(400).json({ error: 'Mês inválido' });

            const jornadas = await prisma.jornada.findMany({
                where: {
                    veiculoId,
                    kmFim: { not: null },
                    dataInicio: { gte: new Date(ano, mesIndex, 1), lt: new Date(ano, mesIndex + 1, 1) }
                },
                include: { operador: { select: { nome: true } } }
            });

            const agrupado: Record<string, number> = {};
            for (const j of jornadas) {
                const nome = j.operador?.nome || 'Desconhecido';
                if (!agrupado[nome]) agrupado[nome] = 0;
                agrupado[nome] += ((j.kmFim || 0) - j.kmInicio);
            }

            const resultado = Object.keys(agrupado).map(key => ({
                name: key,
                value: agrupado[key]
            })).sort((a, b) => (b.value || 0) - (a.value || 0));

            res.json(resultado);
        } catch (error) {
            console.error('Erro em getKmOperadores:', error);
            res.status(500).json({ error: 'Erro ao buscar operadores por KM' });
        }
    }

    public async getEficienciaMacro(req: Request, res: Response) {
        try {
            const { ano } = req.query;
            let dateFilterDate = {};
            if (ano) {
                const year = Number(ano);
                dateFilterDate = { gte: new Date(year, 0, 1), lt: new Date(year + 1, 0, 1) };
            }

            // KM por veículo
            const jornadas = await prisma.jornada.findMany({
                where: { kmFim: { not: null }, ...(ano ? { dataInicio: dateFilterDate } : {}) },
                select: { veiculoId: true, kmInicio: true, kmFim: true }
            });

            const kmPorVeiculo = new Map<string, number>();
            for (const j of jornadas) {
                const vId = j.veiculoId;
                kmPorVeiculo.set(vId, (kmPorVeiculo.get(vId) || 0) + ((j.kmFim || 0) - j.kmInicio));
            }

            // Litros por veículo
            const itensCombustivel = await prisma.itemAbastecimento.findMany({
                where: {
                    produto: { tipo: 'COMBUSTIVEL' },
                    abastecimento: ano ? { dataHora: dateFilterDate } : {}
                },
                select: { quantidade: true, abastecimento: { select: { veiculoId: true } } }
            });

            const litrosPorVeiculo = new Map<string, number>();
            for (const item of itensCombustivel) {
                const vId = item.abastecimento?.veiculoId || '';
                litrosPorVeiculo.set(vId, (litrosPorVeiculo.get(vId) || 0) + Number(item.quantidade));
            }

            const veiculos = await prisma.veiculo.findMany({ select: { id: true, placa: true } });
            
            const result: IDrillDownData[] = [];
            for (const v of veiculos) {
                const km = kmPorVeiculo.get(v.id) || 0;
                const litros = litrosPorVeiculo.get(v.id) || 0;
                if (km > 0 && litros > 0) {
                    result.push({
                        name: v.placa,
                        veiculoId: v.id,
                        value: km / litros
                    });
                }
            }

            result.sort((a, b) => (b.value || 0) - (a.value || 0));
            res.json(result);
        } catch (error) {
            console.error('Erro em getEficienciaMacro:', error);
            res.status(500).json({ error: 'Erro ao gerar macro de Eficiencia' });
        }
    }

    public async getEficienciaTemporal(req: Request, res: Response) {
        try {
            const veiculoId = req.query.veiculoId as string;
            const ano = req.query.ano ? Number(req.query.ano) : new Date().getFullYear();

            if (!veiculoId) return res.status(400).json({ error: 'veiculoId é obrigatório' });

            const jornadas = await prisma.jornada.findMany({
                where: { veiculoId, kmFim: { not: null }, dataInicio: { gte: new Date(ano, 0, 1), lt: new Date(ano + 1, 0, 1) } },
                select: { dataInicio: true, kmInicio: true, kmFim: true }
            });

            const itensCombustivel = await prisma.itemAbastecimento.findMany({
                where: {
                    produto: { tipo: 'COMBUSTIVEL' },
                    abastecimento: { veiculoId, dataHora: { gte: new Date(ano, 0, 1), lt: new Date(ano + 1, 0, 1) } }
                },
                select: { quantidade: true, abastecimento: { select: { dataHora: true } } }
            });

            const kmPorMes = new Array(12).fill(0);
            for (const j of jornadas) {
                const mes = j.dataInicio.getMonth();
                kmPorMes[mes] += ((j.kmFim || 0) - j.kmInicio);
            }

            const litrosPorMes = new Array(12).fill(0);
            for (const item of itensCombustivel) {
                const mes = item.abastecimento?.dataHora.getMonth() || 0;
                litrosPorMes[mes] += Number(item.quantidade);
            }

            const meses = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
            const resultadoMensal = meses.map((m, index) => {
                const km = kmPorMes[index];
                const litros = litrosPorMes[index];
                const kml = litros > 0 ? km / litros : 0;
                return {
                    name: m,
                    mesIndex: index,
                    value: kml,
                    ticketsCount: 1
                };
            });

            res.json(resultadoMensal);
        } catch (error) {
            console.error('Erro em getEficienciaTemporal:', error);
            res.status(500).json({ error: 'Erro ao buscar evolução temporal de eficiência' });
        }
    }

    public async getCustoKmMacro(req: Request, res: Response) {
        try {
            const { ano } = req.query;
            let dateFilterDate = {};
            if (ano) {
                const year = Number(ano);
                dateFilterDate = { gte: new Date(year, 0, 1), lt: new Date(year + 1, 0, 1) };
            }

            // KM por veículo
            const jornadas = await prisma.jornada.findMany({
                where: { kmFim: { not: null }, ...(ano ? { dataInicio: dateFilterDate } : {}) },
                select: { veiculoId: true, kmInicio: true, kmFim: true }
            });

            const kmPorVeiculo = new Map<string, number>();
            for (const j of jornadas) {
                const vId = j.veiculoId;
                kmPorVeiculo.set(vId, (kmPorVeiculo.get(vId) || 0) + ((j.kmFim || 0) - j.kmInicio));
            }

            // Abastecimentos e Aditivos
            const abastecimentos = await prisma.abastecimento.findMany({
                where: ano ? { dataHora: dateFilterDate } : {},
                select: { veiculoId: true, custoTotal: true }
            });

            const custoAbastPorVeiculo = new Map<string, number>();
            for (const a of abastecimentos) {
                const vId = a.veiculoId;
                custoAbastPorVeiculo.set(vId, (custoAbastPorVeiculo.get(vId) || 0) + Number(a.custoTotal));
            }

            // Manutenções
            const manutencoes = await prisma.ordemServico.findMany({
                where: { status: 'CONCLUIDA', ...(ano ? { data: dateFilterDate } : {}) },
                select: { veiculoId: true, custoTotal: true }
            });

            const custoManutPorVeiculo = new Map<string, number>();
            for (const m of manutencoes) {
                const vId = m.veiculoId || '';
                custoManutPorVeiculo.set(vId, (custoManutPorVeiculo.get(vId) || 0) + Number(m.custoTotal));
            }

            const veiculos = await prisma.veiculo.findMany({ select: { id: true, placa: true } });
            
            const result: IDrillDownData[] = [];
            for (const v of veiculos) {
                const km = kmPorVeiculo.get(v.id) || 0;
                const totalCusto = (custoAbastPorVeiculo.get(v.id) || 0) + (custoManutPorVeiculo.get(v.id) || 0);
                
                if (km > 0 && totalCusto > 0) {
                    result.push({
                        name: v.placa,
                        veiculoId: v.id,
                        value: totalCusto / km
                    });
                }
            }

            result.sort((a, b) => (b.value || 0) - (a.value || 0));
            res.json(result);
        } catch (error) {
            console.error('Erro em getCustoKmMacro:', error);
            res.status(500).json({ error: 'Erro ao gerar macro de Custo/KM' });
        }
    }

    public async getCustoKmTemporal(req: Request, res: Response) {
        try {
            const veiculoId = req.query.veiculoId as string;
            const ano = req.query.ano ? Number(req.query.ano) : new Date().getFullYear();

            if (!veiculoId) return res.status(400).json({ error: 'veiculoId é obrigatório' });

            const jornadas = await prisma.jornada.findMany({
                where: { veiculoId, kmFim: { not: null }, dataInicio: { gte: new Date(ano, 0, 1), lt: new Date(ano + 1, 0, 1) } },
                select: { dataInicio: true, kmInicio: true, kmFim: true }
            });

            const abastecimentos = await prisma.abastecimento.findMany({
                where: { veiculoId, dataHora: { gte: new Date(ano, 0, 1), lt: new Date(ano + 1, 0, 1) } },
                select: { dataHora: true, custoTotal: true }
            });

            const manutencoes = await prisma.ordemServico.findMany({
                where: { veiculoId, status: 'CONCLUIDA', data: { gte: new Date(ano, 0, 1), lt: new Date(ano + 1, 0, 1) } },
                select: { data: true, custoTotal: true }
            });

            const kmPorMes = new Array(12).fill(0);
            for (const j of jornadas) {
                const mes = j.dataInicio.getMonth();
                kmPorMes[mes] += ((j.kmFim || 0) - j.kmInicio);
            }

            const custoPorMes = new Array(12).fill(0);
            for (const a of abastecimentos) {
                const mes = a.dataHora.getMonth();
                custoPorMes[mes] += Number(a.custoTotal);
            }
            for (const m of manutencoes) {
                const mes = m.data?.getMonth();
                if (mes !== undefined) {
                    custoPorMes[mes] += Number(m.custoTotal);
                }
            }

            const meses = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
            const resultadoMensal = meses.map((m, index) => {
                const km = kmPorMes[index];
                const custo = custoPorMes[index];
                const custokm = km > 0 ? custo / km : 0;
                return {
                    name: m,
                    mesIndex: index,
                    value: custokm,
                    ticketsCount: 1
                };
            });

            res.json(resultadoMensal);
        } catch (error) {
            console.error('Erro em getCustoKmTemporal:', error);
            res.status(500).json({ error: 'Erro ao buscar evolução temporal de Custo/KM' });
        }
    }

    public async getCustoKmCategorias(req: Request, res: Response) {
        try {
            const veiculoId = req.query.veiculoId as string;
            const mesStr = req.query.mes as string;
            
            if (!veiculoId || !mesStr) {
                return res.status(400).json({ error: 'Parâmetros veiculoId e mes são obrigatórios' });
            }

            const meses = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
            const mesIndex = meses.indexOf(mesStr);
            if (mesIndex === -1) {
                return res.status(400).json({ error: 'Mês inválido' });
            }

            const ano = req.query.ano ? Number(req.query.ano) : new Date().getFullYear();
            const startOfMonth = new Date(ano, mesIndex, 1);
            const endOfMonth = new Date(ano, mesIndex + 1, 1);

            let totalCombustivel = 0;
            let totalAditivo = 0;
            let totalManutencao = 0;

            const itensAbastecimento = await prisma.itemAbastecimento.findMany({
                where: {
                    abastecimento: { veiculoId, dataHora: { gte: startOfMonth, lt: endOfMonth } }
                },
                include: { produto: true }
            });

            for (const item of itensAbastecimento) {
                if (item.produto?.tipo === 'ADITIVO') {
                    totalAditivo += Number(item.valorTotal);
                } else if (item.produto?.tipo === 'COMBUSTIVEL') {
                    totalCombustivel += Number(item.valorTotal);
                }
            }

            const manutencoes = await prisma.ordemServico.aggregate({
                _sum: { custoTotal: true },
                where: { veiculoId, status: 'CONCLUIDA', data: { gte: startOfMonth, lt: endOfMonth } }
            });
            totalManutencao = Number(manutencoes._sum.custoTotal || 0);

            const result = [
                { name: 'Combustível', value: totalCombustivel },
                { name: 'Aditivos', value: totalAditivo },
                { name: 'Manutenção', value: totalManutencao }
            ].filter(i => i.value > 0).sort((a, b) => (b.value || 0) - (a.value || 0));

            res.json(result);
        } catch (error) {
            console.error('Erro em getCustoKmCategorias:', error);
            res.status(500).json({ error: 'Erro ao buscar categorias do Custo/KM' });
        }
    }

    public async getFornecedorTickets(req: Request, res: Response) {
        try {
            const veiculoId = req.query.veiculoId as string;
            const categoria = req.query.categoria as string;
            const mesStr = req.query.mes as string;
            const fornecedorNome = req.query.fornecedorNome as string;
            const ano = req.query.ano ? Number(req.query.ano) : new Date().getFullYear();
            
            if (!veiculoId || !categoria || !mesStr || !fornecedorNome) {
                return res.status(400).json({ error: 'Parâmetros veiculoId, categoria, mes e fornecedorNome são obrigatórios' });
            }

            const meses = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
            const mesIndex = meses.indexOf(mesStr);
            if (mesIndex === -1) {
                return res.status(400).json({ error: 'Mês inválido' });
            }

            const startOfMonth = new Date(ano, mesIndex, 1);
            const endOfMonth = new Date(ano, mesIndex + 1, 1);

            let tickets: { id: string; data: Date; servicoProduto?: string; valor: number }[] = [];

            if (categoria === 'ADITIVO') {
                const itens = await prisma.itemAbastecimento.findMany({
                    where: {
                        produto: { tipo: 'ADITIVO' },
                        abastecimento: {
                            veiculoId,
                            dataHora: { gte: startOfMonth, lt: endOfMonth },
                            fornecedor: { nome: fornecedorNome }
                        }
                    },
                    include: { abastecimento: { include: { veiculo: true } }, produto: true }
                });
                tickets = itens.map((i: Record<string, any>) => ({
                    id: i.id,
                    data: i.abastecimento?.dataHora,
                    placa: i.abastecimento?.veiculo?.placa,
                    servicoProduto: i.produto?.nome || 'Aditivo',
                    valor: Number(i.valorTotal)
                }));
            } else if (categoria === 'ABASTECIMENTO') {
                const abs = await prisma.abastecimento.findMany({
                    where: {
                        veiculoId,
                        dataHora: { gte: startOfMonth, lt: endOfMonth },
                        fornecedor: { nome: fornecedorNome }
                    },
                    include: { veiculo: true, itens: { include: { produto: true } } }
                });
                tickets = abs.map((a: Record<string, any>) => ({
                    id: a.id,
                    data: a.dataHora,
                    placa: a.veiculo?.placa,
                    servicoProduto: a.itens.filter((i: Record<string, any>) => i.produto?.tipo === 'COMBUSTIVEL').map((i: Record<string, any>) => i.produto?.nome).join(', ') || 'Combustível',
                    valor: Number(a.custoTotal)
                }));
            } else {
                const mans = await prisma.ordemServico.findMany({
                    where: {
                        veiculoId,
                        status: 'CONCLUIDA',
                        data: { gte: startOfMonth, lt: endOfMonth },
                        fornecedor: { nome: fornecedorNome }
                    },
                    include: { veiculo: true, itens: { include: { produto: true } } }
                });
                tickets = mans.map((m: Record<string, any>) => ({
                    id: m.id,
                    data: m.data,
                    placa: m.veiculo?.placa,
                    servicoProduto: m.itens.map((i: Record<string, any>) => i.produto?.nome || 'Manutenção').join(', ') || 'Manutenção',
                    valor: Number(m.custoTotal)
                }));
            }

            res.json(tickets);
        } catch (error) {
            console.error('Erro em getFornecedorTickets:', error);
            res.status(500).json({ error: 'Erro interno ao buscar tickets do fornecedor' });
        }
    }
}

