import { prisma } from './lib/prisma';

async function main() {
  const users = await prisma.user.findMany({
    select: { id: true, email: true, nome: true, role: true }
  });
  console.log("Users in DB:", JSON.stringify(users, null, 2));
}

main().catch(console.error);
