import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { env } from '../config/env';

// 🔐 007 Fix: Usa env validado em vez de process.env direto com fallback ''
// Antes: accessKeyId: '' poderia silenciosamente inicializar o cliente sem credenciais
export const R2_BUCKET_NAME = env.CLOUDFLARE_R2_BUCKET_NAME;
export const R2_PUBLIC_DOMAIN = env.CLOUDFLARE_R2_PUBLIC_DOMAIN;

const endpoint = env.CLOUDFLARE_R2_ENDPOINT ?? `https://${env.CLOUDFLARE_ACCOUNT_ID}.r2.cloudflarestorage.com`;

export const s3Client = new S3Client({
  region: 'auto',
  endpoint: endpoint,
  credentials: {
    accessKeyId: env.CLOUDFLARE_R2_ACCESS_KEY_ID,
    secretAccessKey: env.CLOUDFLARE_R2_SECRET_ACCESS_KEY,
  },
});

/**
 * Gera um link temporário assinado que autoriza o navegador do usuário
 * a enviar (fazer upload via método HTTP PUT) diretamente pro Cloudflare R2
 * sem passar pelo seu backend.
 */
export async function generatePresignedUploadUrl(fileName: string, contentType: string) {
  const command = new PutObjectCommand({
    Bucket: R2_BUCKET_NAME,
    Key: fileName,
    ContentType: contentType, // Obrigatório para evitar que a foto não seja renderizada via browser como texto.
  });

  // O link será válido por 5 minutos
  const presignedUrl = await getSignedUrl(s3Client, command, { expiresIn: 300 });

  // Ex: https://pub-12345.r2.dev/minha-foto.png
  const publicUrl = `${R2_PUBLIC_DOMAIN}/${fileName}`;

  return { presignedUrl, publicUrl };
}
