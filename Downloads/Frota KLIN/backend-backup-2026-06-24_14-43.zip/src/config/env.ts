import 'dotenv/config';
import { z } from 'zod';

const envSchema = z.object({
    PORT: z.coerce.number().default(3001),

    TOKEN_SECRET: z.string({ error: "TOKEN_SECRET é obrigatório no .env" }),

    // URL do Pooler (Porta 6543) - Usada pela aplicação em produção
    DATABASE_URL: z.string({ error: "DATABASE_URL é obrigatório no .env" }),

    // URL Direta (Porta 5432) - Obrigatória para o Prisma Migrate funcionar
    DIRECT_URL: z.string({ error: "DIRECT_URL é obrigatória para migrações (schema.prisma)" }),

    // CORS — Em produção deve ser um domínio específico, nunca '*'
    CORS_ORIGINS: z.string().default('*'),

    // 🔐 007 Fix: Variáveis R2 obrigatórias validadas no startup
    // Sem isso, o servidor subia silenciosamente e falhas só apareciam no primeiro upload
    CLOUDFLARE_ACCOUNT_ID: z.string({ error: "CLOUDFLARE_ACCOUNT_ID é obrigatório no .env" }),
    CLOUDFLARE_R2_BUCKET_NAME: z.string({ error: "CLOUDFLARE_R2_BUCKET_NAME é obrigatório no .env" }),
    CLOUDFLARE_R2_ACCESS_KEY_ID: z.string({ error: "CLOUDFLARE_R2_ACCESS_KEY_ID é obrigatório no .env" }),
    CLOUDFLARE_R2_SECRET_ACCESS_KEY: z.string({ error: "CLOUDFLARE_R2_SECRET_ACCESS_KEY é obrigatório no .env" }),
    CLOUDFLARE_R2_ENDPOINT: z.string().optional(),
    CLOUDFLARE_R2_PUBLIC_DOMAIN: z.string({ error: "CLOUDFLARE_R2_PUBLIC_DOMAIN é obrigatório no .env" }),

    // 🔐 007 Fix: Resend obrigatório — sem validação, emails falhavam silenciosamente
    RESEND_API_KEY: z.string({ error: "RESEND_API_KEY é obrigatório no .env" }),
    
    /** 
     * URL do Frontend para links de e-mail e QR Code. 
     * ⚠️ IMPORTANTE: Em produção, isto DEVE ser o domínio real (ex: https://frota.klin.com.br)
     * Se manter localhost, os links em e-mails e QR Codes não funcionarão fora do servidor.
     */
    FRONTEND_URL: z.string().default('http://localhost:5173'),

    NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),

    // IA - Google Gemini (Opcional: sistema sobe mesmo sem a chave, mas IA fica indisponível)
    GEMINI_API_KEY: z.string().optional(),
});

const _env = envSchema.safeParse(process.env);

if (!_env.success) {
    console.error("❌ Erro fatal: Variáveis de ambiente inválidas:", _env.error.format());
    throw new Error("Variáveis de ambiente inválidas.");
}

export const env = _env.data;