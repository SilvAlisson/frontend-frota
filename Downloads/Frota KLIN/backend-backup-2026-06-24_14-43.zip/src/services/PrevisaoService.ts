import { prisma } from '../lib/prisma';

export class PrevisaoService {
    /**
     * Calcula a média de KM rodado por dia nos últimos 30 dias.
     */
    static async calcularMediaDiaria(veiculoId: string): Promise<number> {
        const trintaDiasAtras = new Date();
        trintaDiasAtras.setDate(trintaDiasAtras.getDate() - 30);

        const jornadas = await prisma.jornada.findMany({
            where: {
                veiculoId,
                dataInicio: { gte: trintaDiasAtras },
                kmFim: { not: null }
            },
            select: { kmInicio: true, kmFim: true }
        });

        const kmTotal = jornadas.reduce((acc, j) => acc + ((j.kmFim || 0) - j.kmInicio), 0);

        // Retorna média (mínimo 1km para evitar divisão por zero)
        return Math.max(kmTotal / 30, 1);
    }

    /**
     * OTIMIZAÇÃO: Calcula a média diária de MÚLTIPLOS veículos em apenas DUAS queries.
     */
    static async calcularMediasDiariasBulk(veiculoIds: string[]): Promise<Map<string, number>> {
        const mediasMap = new Map<string, number>();
        if (veiculoIds.length === 0) return mediasMap;

        const trintaDiasAtras = new Date();
        trintaDiasAtras.setDate(trintaDiasAtras.getDate() - 30);

        const jornadas = await prisma.jornada.findMany({
            where: {
                veiculoId: { in: veiculoIds },
                dataInicio: { gte: trintaDiasAtras },
                kmFim: { not: null }
            },
            select: { veiculoId: true, kmInicio: true, kmFim: true }
        });

        const kmPorVeiculo: Record<string, number> = {};
        for (const j of jornadas) {
            kmPorVeiculo[j.veiculoId] = (kmPorVeiculo[j.veiculoId] || 0) + ((j.kmFim || 0) - j.kmInicio);
        }

        for (const vId of veiculoIds) {
            const total = kmPorVeiculo[vId] || 0;
            mediasMap.set(vId, Math.max(total / 30, 1));
        }

        return mediasMap;
    }

    /**
     * Estima em quantos dias o veículo atingirá o KM da próxima manutenção
     * RENOMEADO: de estimarDiasParaKm para estimarDiasParaManutencao
     */
    static async estimarDiasParaManutencao(veiculoId: string, kmAlvo: number, kmAtual: number, mediaDiariaPréCalculada?: number): Promise<number | null> {
        if (kmAlvo <= kmAtual) return 0;

        const kmRestante = kmAlvo - kmAtual;
        const mediaDiaria = mediaDiariaPréCalculada !== undefined ? mediaDiariaPréCalculada : await this.calcularMediaDiaria(veiculoId);

        return Math.ceil(kmRestante / mediaDiaria);
    }
}