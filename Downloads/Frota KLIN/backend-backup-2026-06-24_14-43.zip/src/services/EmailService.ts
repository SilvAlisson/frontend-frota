import { Resend } from 'resend';

// Inicializa o Resend com a chave que vamos colocar no .env
const resend = new Resend(process.env.RESEND_API_KEY);

class EmailService {
  async sendPasswordResetEmail(to: string, resetToken: string, userName: string) {
    console.log(`⏳ A preparar envio via Resend (HTTP) para: ${to}...`);

    const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:5173';
    const resetLink = `${frontendUrl}/redefinir-senha?token=${resetToken}`;

    const htmlContent = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e2e8f0; border-radius: 10px; background-color: #ffffff;">
        <div style="text-align: center; margin-bottom: 20px;">
           <h1 style="color: #0284c7; margin: 0;">KLIN Frota</h1>
        </div>
        <h2 style="color: #0f172a; text-align: center;">Recuperação de Palavra-passe</h2>
        <p style="color: #334155; font-size: 16px;">Olá, <strong>${userName}</strong>.</p>
        <p style="color: #334155; font-size: 16px;">Recebemos um pedido para redefinir a palavra-passe da sua conta no sistema de Gestão de Frota.</p>
        <div style="text-align: center; margin: 35px 0;">
          <a href="${resetLink}" style="background-color: #0284c7; color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: bold; font-size: 16px; display: inline-block; box-shadow: 0 4px 6px -1px rgba(2, 132, 199, 0.2);">
            Redefinir Palavra-passe
          </a>
        </div>
        <p style="color: #64748b; font-size: 14px; text-align: center;">Este link é válido por <strong>1 hora</strong>. Se não solicitou esta alteração, por favor ignore este e-mail.</p>
        <hr style="border: 0; border-top: 1px solid #e2e8f0; margin: 30px 0;" />
        <p style="color: #94a3b8; font-size: 12px; text-align: center;">Equipa de Sistema - Frota KLIN</p>
      </div>
    `;

    try {
      const { data, error } = await resend.emails.send({
        from: 'KLIN Frota <onboarding@resend.dev>', // O e-mail de testes padrão do Resend
        to: [to],
        subject: 'Redefinição de Palavra-passe - KLIN Frota',
        html: htmlContent,
      });

      if (error) {
        console.error('❌ Erro da API do Resend:', error);
        throw new Error('Falha no envio do e-mail de recuperação.');
      }

      console.log(`✅ E-mail enviado com sucesso via Resend para: ${to} (ID: ${data?.id})`);
    } catch (error) {
      console.error('❌ ERRO FATAL AO ENVIAR E-MAIL RESEND:', error);
      throw new Error('Falha no envio do e-mail de recuperação.');
    }
  }
}

export default new EmailService();