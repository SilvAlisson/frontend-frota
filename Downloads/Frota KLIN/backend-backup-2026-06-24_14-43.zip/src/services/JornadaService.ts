import { prisma } from '../lib/prisma';
import { Jornada, Veiculo, User } from '@prisma/client';

// ============================================================================
// ⚙️ MOTOR DE PARÂMETROS DE AUDITORIA (BUSINESS RULES)
// ============================================================================
const RULES = {
    CRON_HORAS_TOLERANCIA: 14, // Tempo para considerar uma jornada "abandonada"
    MAX_RETRIES: 3,            // Tentativas antes de desistir e pedir intervenção manual
    BATCH_SIZE: 50,            // Lote de processamento para não sobrecarregar a RAM
    
    // Regras Físicas e Legais
    LEGAL_MAX_HORAS_TURNO: 14,      // Limite máximo de horas de trabalho contínuo (CLT/Tacógrafo)
    FISICA_MAX_KMH: 110,            // Velocidade média máxima impossível (indica erro de digitação de odómetro)
    FISICA_MAX_KM_DIARIO: 900,      // Máximo que um camião costuma rodar em 24h
    TOLERANCIA_MICRO_MOVIMENTO: 15  // KM de manobra em pátio/oficina (irrelevante para punição)
};

export class JornadaService {

    /**
     * Calcula a média de KM diário do veículo baseada nos últimos 30 dias.
     * Fallback super seguro para quando não há dados.
     */
    private static async getMediaRodagemDiaria(veiculoId: string): Promise<number> {
        const limiteData = new Date();
        limiteData.setDate(limiteData.getDate() - 30);

        try {
            const historico = await prisma.jornada.findMany({
                where: {
                    veiculoId,
                    dataFim: { gte: limiteData },
                    kmFim: { gte: 0 },
                    kmInicio: { gte: 0 }
                },
                select: { kmInicio: true, kmFim: true },
                take: 10
            });

            if (historico.length < 3) return 150; // Fallback corporativo padrão

            let totalKm = 0;
            let validos = 0;

            for (const j of historico) {
                if (typeof j.kmFim === 'number' && typeof j.kmInicio === 'number' && j.kmFim > j.kmInicio) {
                    totalKm += (j.kmFim - j.kmInicio);
                    validos++;
                }
            }

            if (validos === 0) return 150;
            const media = Math.ceil(totalKm / validos);
            return media > 10 ? media : 150;
        } catch {
            return 150;
        }
    }

    /**
     * Gatilho Principal (Cron Job)
     */
    static async fecharJornadasVencidas() {
        console.log('\n🛡️ [CRON] Iniciando Motor de Resolução de Jornadas Pendentes...');

        const dataLimite = new Date();
        dataLimite.setHours(dataLimite.getHours() - RULES.CRON_HORAS_TOLERANCIA);

        // Busca apenas as jornadas abandonadas
        const jornadasAbandonadas = await prisma.jornada.findMany({
            where: {
                dataInicio: { lt: dataLimite },
                dataFim: null,
                tentativasAutoFechamento: { lt: RULES.MAX_RETRIES }
            },
            take: RULES.BATCH_SIZE,
            include: { veiculo: true, operador: true }
        });

        if (jornadasAbandonadas.length === 0) {
            console.log('✅ [CRON] Frota perfeitamente sincronizada. Nenhuma jornada abandonada.');
            return;
        }

        console.log(`⚠️ [CRON] Processando lote de ${jornadasAbandonadas.length} jornadas abandonadas...`);

        for (const jornada of jornadasAbandonadas) {
            try {
                await this.resolverConflitoDeJornada(jornada);
                console.log(`✔️  [CRON] Jornada ID ${jornada.id} resolvida com sucesso.`);
            } catch (error: unknown) {
                const err = error instanceof Error ? error : new Error(String(error));
                console.error(`🚨 [CRON] Falha ao resolver jornada ID ${jornada.id}: ${err.message}`);
                
                // Registra o erro na Dead Letter Queue para análise manual do Gestor
                await prisma.jornada.update({
                    where: { id: jornada.id },
                    data: {
                        tentativasAutoFechamento: { increment: 1 },
                        erroAutoFechamento: err.message
                    }
                });
            }
        }
    }

    /**
     * O Motor Lógico (Resolução Simplificada)
     */
    private static async resolverConflitoDeJornada(jornada: Jornada & { veiculo: Veiculo, operador: User }) {
        await prisma.$transaction(async (tx) => {
            const dataInicio = new Date(jornada.dataInicio);
            const obsAntiga = jornada.observacoes ? `${jornada.observacoes} | ` : '';

            // O sistema fecha apenas o TEMPO da jornada (14 horas após o início)
            // e deixa o KM em aberto para o próximo operador preencher no Início de Turno dele.
            const dataFimForcada = new Date(dataInicio);
            dataFimForcada.setHours(dataFimForcada.getHours() + RULES.LEGAL_MAX_HORAS_TURNO);
            
            // Não pode fechar no futuro
            const dataFimDefinitiva = dataFimForcada > new Date() ? new Date() : dataFimForcada;

            await tx.jornada.update({
                where: { id: jornada.id },
                data: {
                    dataFim: dataFimDefinitiva,
                    // kmFim continua null propositalmente!
                    observacoes: obsAntiga + "⚠️ [SISTEMA] Encerramento Administrativo Automático (14h excedidas). KM Final pendente de fechamento pelo próximo operador.",
                    tentativasAutoFechamento: 0,
                    erroAutoFechamento: null
                }
            });
        });
    }
}