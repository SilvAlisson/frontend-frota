import { GoogleGenAI, Type, Tool } from '@google/genai';
import { env } from '../config/env';
import { prisma } from '../lib/prisma';

// Inicialização com o novo SDK
const ai = env.GEMINI_API_KEY ? new GoogleGenAI({ apiKey: env.GEMINI_API_KEY }) : null;
const MODELS_TO_TRY = ['gemini-3.5-flash', 'gemini-2.5-flash', 'gemini-2.0-flash'];

const SYSTEM_INSTRUCTION = `Você é a "Kia" (Klin Inteligência Artificial), a analista de dados sênior e Chief Operating Officer (COO) virtual do sistema Frota KLIN da empresa KLIN Soluções.

SUAS CAPACIDADES: Você opera como um Agente Autônomo de Inteligência. Você tem à disposição um catálogo gigante de ferramentas (APIs) para extrair métricas do banco de dados PostgreSQL.

REGRAS ABSOLUTAS:
1. INTENT DETECTION: Identifique o que o usuário quer saber e ESCOLHA AS FERRAMENTAS CERTAS. Nunca adivinhe ou invente dados operacionais.
2. MULTI-TOOL (RACIOCÍNIO EM CADEIA): Para perguntas amplas (ex: "Faça um raio-x completo da frota"), você DEVE chamar múltiplas ferramentas em paralelo ou em sequência antes de dar a resposta final.
3. DETECÇÃO DE GARGALOS: Se você notar que o custo com CORRETIVAS está maior que PREVENTIVAS, ou que há documentos JÁ VENCIDOS, destaque isso em VERMELHO e emita um alerta gerencial.
4. SÍNTESE ANALÍTICA: As ferramentas retornam arrays JSON crus. É o seu trabalho interpretar, cruzar os dados, calcular porcentagens quando necessário, e escrever uma resposta fluída, executiva e bonita em Markdown.
5. FORMATAÇÃO: Formate valores em R$ (ex: R$ 5.430,00) e datas no padrão DD/MM/YYYY.
6. UI GENERATIVA: Ao mencionar QUALQUER veículo específico na sua resposta (ex: na lista de defeitos, maiores custos, etc), OBRIGATORIAMENTE insira a tag: [WIDGET:VEICULO:PLACA_AQUI] (ex: O veículo [WIDGET:VEICULO:SKH2G80] teve o maior custo). Não use espaços na placa.
7. SEGURANÇA: Jamais exponha queries SQL, nomes de campos internos (ex: veiculoId), senhas ou chaves.`;

// ============================================================================
// 🛠️ CATÁLOGO MASSIVO DE FERRAMENTAS DA KIA
// ============================================================================
const tools: Tool[] = [
    {
        functionDeclarations: [
            // --- 1. VISÃO GERAL E STATUS ---
            { name: 'get_fleet_overview', description: 'Retorna uma contagem sumarizada do status atual (Ativo/Manutenção/Inativo) dos veículos e operadores.' },
            { name: 'get_active_journeys', description: 'Retorna a lista de jornadas (viagens) que estão em andamento NESTE EXATO MOMENTO (na rua).' },
            { 
                name: 'get_operator_status', 
                description: 'Busca o status (Ativo, Férias, Atestado) e cargo de um colaborador específico pelo NOME.',
                parameters: { type: Type.OBJECT, properties: { nome: { type: Type.STRING, description: 'Nome ou parte do nome do colaborador' } }, required: ['nome'] } as any
            },
            { 
                name: 'get_vehicle_info', 
                description: 'Retorna dados cadastrais, status atual e último KM de um veículo específico pela placa.',
                parameters: { type: Type.OBJECT, properties: { placa: { type: Type.STRING, description: 'Placa contínua (ex: ABC1234)' } }, required: ['placa'] } as any
            },

            // --- 2. CUSTOS E FORNECEDORES ---
            { 
                name: 'get_maintenance_costs_ranking', 
                description: 'Retorna o ranking financeiro (Top 10) de veículos que mais gastaram com Manutenção (Oficina).',
                parameters: { type: Type.OBJECT, properties: { meses: { type: Type.INTEGER, description: 'Meses retroativos. Padrão: 3.' } } } as any
            },
            { 
                name: 'get_fuel_consumption_ranking', 
                description: 'Retorna o ranking financeiro (Top 10) de veículos que mais gastaram com Combustível.',
                parameters: { type: Type.OBJECT, properties: { meses: { type: Type.INTEGER, description: 'Meses retroativos. Padrão: 3.' } } } as any
            },
            { 
                name: 'get_top_suppliers_spending', 
                description: 'Cruza contas e retorna para QUAIS FORNECEDORES (Postos, Oficinas, etc) a empresa mais enviou dinheiro no período.',
                parameters: { type: Type.OBJECT, properties: { meses: { type: Type.INTEGER, description: 'Meses retroativos. Padrão: 3.' } } } as any
            },

            // --- 3. PRODUTIVIDADE E EFICIÊNCIA ---
            { 
                name: 'get_vehicle_km_ranking', 
                description: 'Retorna os veículos que mais rodaram (maior KM percorrido) em jornadas fechadas.',
                parameters: { type: Type.OBJECT, properties: { meses: { type: Type.INTEGER, description: 'Meses retroativos. Padrão: 3.' } } } as any
            },
            { 
                name: 'get_operator_productivity', 
                description: 'Retorna o ranking dos operadores (motoristas) que mais trabalharam (Volume de viagens e KM rodado).',
                parameters: { type: Type.OBJECT, properties: { meses: { type: Type.INTEGER, description: 'Meses retroativos. Padrão: 3.' } } } as any
            },
            { 
                name: 'get_fuel_efficiency_metrics', 
                description: 'Analisa a eficiência (KM/L) calculando a relação entre Litros abastecidos e KM percorrido na frota.',
                parameters: { type: Type.OBJECT, properties: { placa: { type: Type.STRING, description: 'Opcional: Placa para ver média de 1 veículo específico.' } } } as any
            },

            // --- 4. MANUTENÇÃO E DEFEITOS ---
            { name: 'get_open_defects', description: 'Retorna todos os defeitos reportados pelos motoristas que ainda estão com status ABERTO.' },
            { 
                name: 'get_maintenance_type_ratio', 
                description: 'Retorna o balanço gerencial: Quantas Ordens de Serviço foram PREVENTIVAS vs CORRETIVAS vs LAVAGEM. Muito útil para ver se a frota quebra muito.',
                parameters: { type: Type.OBJECT, properties: { meses: { type: Type.INTEGER, description: 'Meses retroativos. Padrão: 3.' } } } as any
            },
            { name: 'get_preventive_maintenance_alerts', description: 'Retorna veículos que estão a menos de 500km de estourar a próxima revisão ou que já estouraram o KM/Data.' },
            { name: 'get_defect_categories_stats', description: 'Retorna onde a frota mais quebra (Ex: 40% dos defeitos são PNEU, 20% MOTOR).' },
            { 
                name: 'get_most_washed_vehicles', 
                description: 'Retorna o ranking dos veículos que mais foram LAVADOS (Ordens de Serviço do tipo Lavagem) em um período.',
                parameters: { type: Type.OBJECT, properties: { meses: { type: Type.INTEGER, description: 'Meses retroativos. Padrão: 3.' } } } as any
            },
            { 
                name: 'get_defects_ranking_by_vehicle', 
                description: 'Retorna o ranking de veículos que MAIS QUEBRARAM (maior volume de Defeitos Reportados). Pode filtrar por categoria específica de peça (ex: PNEU, ILUMINACAO, MOTOR, FREIO).',
                parameters: { type: Type.OBJECT, properties: { 
                    meses: { type: Type.INTEGER, description: 'Meses retroativos. Padrão: 3.' },
                    categoria: { type: Type.STRING, description: 'Opcional: Filtrar por categoria (PNEU, FREIO, MOTOR, ILUMINACAO, CARROCERIA, OLEO).' }
                } } as any
            },

            // --- 5. COMPLIANCE, SST E ANOMALIAS ---
            { name: 'get_sst_actions_status', description: 'Retorna o status dos programas de Saúde e Segurança (PGR, PCA), focando nas pendentes ou atrasadas.' },
            { name: 'get_already_expired_compliance', description: 'ALERTA CRÍTICO: Retorna documentos de veículos e treinamentos de equipe que JÁ VENCERAM no passado e estão irregulares hoje.' },
            { 
                name: 'get_expiring_documents', 
                description: 'Retorna documentos que vão vencer NO FUTURO (próximos X dias).',
                parameters: { type: Type.OBJECT, properties: { dias: { type: Type.INTEGER, description: 'Dias para frente. Padrão: 30.' } } } as any
            },
            { 
                name: 'get_expiring_trainings', 
                description: 'Retorna treinamentos que vão vencer NO FUTURO (próximos X dias).',
                parameters: { type: Type.OBJECT, properties: { dias: { type: Type.INTEGER, description: 'Dias para frente. Padrão: 30.' } } } as any
            },
            { 
                name: 'get_anomalous_journeys', 
                description: 'Verifica jornadas com suspeita de fraude (observações estranhas), erros de fechamento do sistema/robô (abandono de jornada) ou onde o operador NÃO ABRIU O KM (kmInicio igual a kmFim).',
                parameters: { type: Type.OBJECT, properties: { meses: { type: Type.INTEGER, description: 'Meses retroativos. Padrão: 3.' } } } as any
            },
            { 
                name: 'get_idle_operators', 
                description: 'Verifica operadores ativos que não abrem jornada (não rodam) há muitos dias. Excelente para achar operadores "nó cego" ou ociosos.',
                parameters: { type: Type.OBJECT, properties: { dias: { type: Type.INTEGER, description: 'Mínimo de dias sem rodar. Padrão: 15.' } } } as any
            },
        ]
    }
];

// ============================================================================
// 🗃️ MOTOR DE EXECUÇÃO (QUERIES DE ALTA PERFORMANCE)
// ============================================================================

function getDataLimite(meses: number): Date {
    const d = new Date();
    d.setMonth(d.getMonth() - Math.min(Math.max(meses, 1), 24));
    return d;
}

const apiAgentes = {
    // 1. GERAL
    get_fleet_overview: async () => {
        const [veiculos, ops] = await Promise.all([
            prisma.veiculo.groupBy({ by: ['status'], _count: true }),
            prisma.user.groupBy({ by: ['status'], _count: true, where: { role: 'OPERADOR' } })
        ]);
        return { veiculos: veiculos.map(s => ({ status: s.status, total: s._count })), operadores: ops.map(s => ({ status: s.status, total: s._count })) };
    },
    get_active_journeys: async () => {
        const jornadas = await prisma.jornada.findMany({
            where: { dataFim: null },
            select: { dataInicio: true, kmInicio: true, veiculo: { select: { placa: true } }, operador: { select: { nome: true } } },
            orderBy: { dataInicio: 'asc' }
        });
        return jornadas.map(j => ({
            placa: j.veiculo.placa, operador: j.operador.nome, dataInicio: j.dataInicio,
            horasRodando: Math.floor((new Date().getTime() - j.dataInicio.getTime()) / (1000 * 3600))
        }));
    },
    get_operator_status: async (args: any) => {
        return await prisma.user.findFirst({
            where: { nome: { contains: args?.nome || '', mode: 'insensitive' } },
            select: { nome: true, role: true, status: true, matricula: true, jornadasComoOperador: { select: { dataFim: true }, orderBy: { dataInicio: 'desc' }, take: 1 } }
        }) || { erro: "Operador não encontrado." };
    },
    get_vehicle_info: async (args: any) => {
        return await prisma.veiculo.findUnique({
            where: { placa: args?.placa || '' },
            select: { placa: true, modelo: true, status: true, ultimoKm: true, tipoCombustivel: true }
        }) || { erro: "Veículo não encontrado." };
    },

    // 2. FINANCEIRO
    get_maintenance_costs_ranking: async (args: any) => {
        const limite = getDataLimite(args?.meses || 3);
        const calc = await prisma.ordemServico.groupBy({
            by: ['veiculoId'], _sum: { custoTotal: true },
            where: { data: { gte: limite }, status: 'CONCLUIDA', veiculoId: { not: null } },
            orderBy: { _sum: { custoTotal: 'desc' } }, take: 10
        });
        const v = await prisma.veiculo.findMany({ where: { id: { in: calc.map(c => c.veiculoId!) } }, select: { id: true, placa: true } });
        return calc.map(c => ({ placa: v.find(x => x.id === c.veiculoId)?.placa, custoR$: Number(c._sum.custoTotal) }));
    },
    get_fuel_consumption_ranking: async (args: any) => {
        const limite = getDataLimite(args?.meses || 3);
        const calc = await prisma.abastecimento.groupBy({
            by: ['veiculoId'], _sum: { custoTotal: true },
            where: { dataHora: { gte: limite }, status: 'APROVADO' },
            orderBy: { _sum: { custoTotal: 'desc' } }, take: 10
        });
        const v = await prisma.veiculo.findMany({ where: { id: { in: calc.map(c => c.veiculoId!) } }, select: { id: true, placa: true } });
        return calc.map(c => ({ placa: v.find(x => x.id === c.veiculoId)?.placa, custoR$: Number(c._sum.custoTotal) }));
    },
    get_top_suppliers_spending: async (args: any) => {
        const limite = getDataLimite(args?.meses || 3);
        // Junta custos de Oficinas (OS) e Postos (Abastecimento)
        const [os, ab] = await Promise.all([
            prisma.ordemServico.groupBy({ by: ['fornecedorId'], _sum: { custoTotal: true }, where: { data: { gte: limite }, status: 'CONCLUIDA' } }),
            prisma.abastecimento.groupBy({ by: ['fornecedorId'], _sum: { custoTotal: true }, where: { dataHora: { gte: limite }, status: 'APROVADO' } })
        ]);
        const consolidado: Record<string, number> = {};
        os.forEach(x => consolidado[x.fornecedorId] = (consolidado[x.fornecedorId] || 0) + Number(x._sum.custoTotal));
        ab.forEach(x => consolidado[x.fornecedorId] = (consolidado[x.fornecedorId] || 0) + Number(x._sum.custoTotal));
        
        const f = await prisma.fornecedor.findMany({ where: { id: { in: Object.keys(consolidado) } }, select: { id: true, nome: true, tipo: true } });
        return f.map(fornecedor => ({
            fornecedor: fornecedor.nome, tipo: fornecedor.tipo,
            totalRecebidoR$: consolidado[fornecedor.id]
        })).sort((a, b) => b.totalRecebidoR$ - a.totalRecebidoR$).slice(0, 15);
    },

    // 3. PRODUTIVIDADE E EFICIÊNCIA
    get_vehicle_km_ranking: async (args: any) => {
        const limite = getDataLimite(args?.meses || 3);
        const res: any[] = await prisma.$queryRaw`
            SELECT v.placa, SUM(j."kmFim" - j."kmInicio") as km_rodado 
            FROM "Jornada" j JOIN "Veiculo" v ON j."veiculoId" = v.id 
            WHERE j."dataInicio" >= ${limite} AND j."kmFim" > j."kmInicio"
            GROUP BY v.placa ORDER BY km_rodado DESC LIMIT 10
        `;
        return res.map(r => ({ placa: r.placa, kmRodado: Number(r.km_rodado) }));
    },
    get_operator_productivity: async (args: any) => {
        const limite = getDataLimite(args?.meses || 3);
        const res: any[] = await prisma.$queryRaw`
            SELECT u.nome, COUNT(j.id) as total_viagens, SUM(j."kmFim" - j."kmInicio") as km_rodado 
            FROM "Jornada" j JOIN "User" u ON j."operadorId" = u.id 
            WHERE j."dataInicio" >= ${limite} AND j."kmFim" > j."kmInicio"
            GROUP BY u.nome ORDER BY total_viagens DESC LIMIT 10
        `;
        return res.map(r => ({ operador: r.nome, viagens: Number(r.total_viagens), kmTotal: Number(r.km_rodado) }));
    },
    get_fuel_efficiency_metrics: async (args: any) => {
        const limit = new Date(); limit.setMonth(limit.getMonth() - 1); // Último mês para não pesar
        let whereClause = { dataHora: { gte: limit }, status: 'APROVADO' } as any;
        if (args?.placa) whereClause = { ...whereClause, veiculo: { placa: args.placa } };

        const abastecimentos = await prisma.itemAbastecimento.groupBy({
            by: ['abastecimentoId'], _sum: { quantidade: true },
            where: { abastecimento: whereClause }
        });
        return { 
            insightBruto: "A IA deve cruzar a quantidade total em litros retornada com o KM médio rodado no período para achar KM/L.", 
            amostraLitrosNoMes: abastecimentos.map(a => ({ idAbast: a.abastecimentoId, litros: Number(a._sum.quantidade) })).slice(0, 20) 
        };
    },

    // 4. MANUTENÇÃO
    get_open_defects: async () => {
        const def = await prisma.defeitoVeiculo.findMany({
            where: { status: 'ABERTO' }, orderBy: { createdAt: 'desc' },
            select: { descricao: true, categoria: true, createdAt: true, veiculo: { select: { placa: true } }, operador: { select: { nome: true } } }
        });
        return def.map(d => ({ ...d, diasAberto: Math.floor((new Date().getTime() - d.createdAt.getTime()) / 86400000) }));
    },
    get_maintenance_type_ratio: async (args: any) => {
        const limite = getDataLimite(args?.meses || 3);
        const ratio = await prisma.ordemServico.groupBy({
            by: ['tipo'], _count: true, _sum: { custoTotal: true },
            where: { data: { gte: limite }, status: 'CONCLUIDA' }
        });
        return ratio.map(r => ({ tipo: r.tipo, quantidadeOS: r._count, custoTotal: Number(r._sum.custoTotal) }));
    },
    get_preventive_maintenance_alerts: async () => {
        const planos = await prisma.planoManutencao.findMany({
            include: { veiculo: { select: { placa: true, ultimoKm: true } } }
        });
        const hoje = new Date();
        return planos.filter(p => {
            const estouroKm = p.kmProximaManutencao && p.veiculo.ultimoKm && (p.kmProximaManutencao - p.veiculo.ultimoKm <= 500);
            const estouroData = p.dataProximaManutencao && p.dataProximaManutencao <= new Date(hoje.getTime() + 15 * 86400000); // 15 dias
            return estouroKm || estouroData;
        }).map(p => ({
            placa: p.veiculo.placa, servico: p.descricao, kmAtual: p.veiculo.ultimoKm, 
            trocaPrevistaKm: p.kmProximaManutencao, trocaPrevistaData: p.dataProximaManutencao
        }));
    },
    get_defect_categories_stats: async () => {
        const stats = await prisma.defeitoVeiculo.groupBy({ by: ['categoria'], _count: true, orderBy: { _count: { categoria: 'desc' } } });
        return stats.map(s => ({ categoria: s.categoria, quantidadeHistorica: s._count }));
    },
    get_most_washed_vehicles: async (args: any) => {
        const limite = getDataLimite(args?.meses || 3);
        const calc = await prisma.ordemServico.groupBy({
            by: ['veiculoId'], _count: true,
            where: { data: { gte: limite }, status: 'CONCLUIDA', tipo: 'LAVAGEM', veiculoId: { not: null } },
            orderBy: { _count: { veiculoId: 'desc' } }, take: 10
        });
        const v = await prisma.veiculo.findMany({ where: { id: { in: calc.map(c => c.veiculoId!) } }, select: { id: true, placa: true } });
        return calc.map(c => ({ placa: v.find(x => x.id === c.veiculoId)?.placa, totalLavagens: c._count }));
    },
    get_defects_ranking_by_vehicle: async (args: any) => {
        const limite = getDataLimite(args?.meses || 3);
        const whereClause: any = { createdAt: { gte: limite }, veiculoId: { not: null } };
        if (args?.categoria) {
            whereClause.categoria = args.categoria.toUpperCase();
        }
        const calc = await prisma.defeitoVeiculo.groupBy({
            by: ['veiculoId'], _count: true,
            where: whereClause,
            orderBy: { _count: { veiculoId: 'desc' } }, take: 10
        });
        const v = await prisma.veiculo.findMany({ where: { id: { in: calc.map(c => c.veiculoId!) } }, select: { id: true, placa: true } });
        return calc.map(c => ({ placa: v.find(x => x.id === c.veiculoId)?.placa, totalDefeitos: c._count, categoriaFiltrada: args?.categoria || 'GERAL' }));
    },

    // 5. COMPLIANCE E ANOMALIAS
    get_already_expired_compliance: async () => {
        const hoje = new Date();
        const [docs, treinos] = await Promise.all([
            prisma.documentoLegal.findMany({ where: { dataValidade: { lt: hoje }, status: 'VIGENTE' }, select: { titulo: true, dataValidade: true, veiculo: { select: { placa: true } } } }),
            prisma.treinamento.findMany({ where: { dataVencimento: { lt: hoje } }, select: { nome: true, dataVencimento: true, user: { select: { nome: true } } } })
        ]);
        return {
            documentosIrregulares: docs.map(d => ({ placa: d.veiculo?.placa, doc: d.titulo, venceuEm: d.dataValidade })),
            colaboradoresIrregulares: treinos.map(t => ({ nome: t.user.nome, treinamento: t.nome, venceuEm: t.dataVencimento }))
        };
    },
    get_expiring_documents: async (args: any) => {
        const d = new Date(); d.setDate(d.getDate() + (args?.dias || 30));
        return await prisma.documentoLegal.findMany({
            where: { dataValidade: { gte: new Date(), lte: d }, status: 'VIGENTE' },
            select: { titulo: true, dataValidade: true, veiculo: { select: { placa: true } } }
        });
    },
    get_expiring_trainings: async (args: any) => {
        const d = new Date(); d.setDate(d.getDate() + (args?.dias || 30));
        return await prisma.treinamento.findMany({
            where: { dataVencimento: { gte: new Date(), lte: d } },
            select: { nome: true, dataVencimento: true, user: { select: { nome: true } } }
        });
    },
    get_sst_actions_status: async () => {
        return await prisma.acaoSST.findMany({ where: { status: { in: ['PENDENTE', 'ATRASADO'] } }, select: { acao: true, programa: true, status: true, vencimento: true } });
    },
    get_anomalous_journeys: async (args: any) => {
        const limite = getDataLimite(args?.meses || 3);
        const res: any[] = await prisma.$queryRaw`
            SELECT j.id, j."dataInicio", j."kmInicio", j."kmFim", j."erroAutoFechamento", j.observacoes, v.placa, u.nome as operador
            FROM "Jornada" j
            JOIN "Veiculo" v ON j."veiculoId" = v.id
            JOIN "User" u ON j."operadorId" = u.id
            WHERE j."dataInicio" >= ${limite}
            AND (j."erroAutoFechamento" IS NOT NULL 
                 OR j.observacoes LIKE '%👻%' 
                 OR (j."kmFim" IS NOT NULL AND j."kmInicio" = j."kmFim"))
            ORDER BY j."dataInicio" DESC
            LIMIT 20
        `;
        return res.map(r => ({
            data: r.dataInicio, placa: r.placa, operador: r.operador, 
            kmInicio: r.kmInicio, kmFim: r.kmFim, 
            erro: r.erroAutoFechamento, suspeitaFraude: r.observacoes?.includes('👻')
        }));
    },
    get_idle_operators: async (args: any) => {
        const limiteDias = args?.dias || 15;
        const hoje = new Date();
        const limiteData = new Date(hoje.getTime() - limiteDias * 86400000);

        const operadores = await prisma.user.findMany({
            where: { role: 'OPERADOR', status: 'ATIVO' },
            select: { nome: true, jornadasComoOperador: { orderBy: { dataInicio: 'desc' }, take: 1, select: { dataInicio: true } } }
        });

        const ociosos = operadores.filter(o => {
            if (o.jornadasComoOperador.length === 0) return true; // Nunca rodou
            return o.jornadasComoOperador[0].dataInicio <= limiteData;
        }).map(o => {
            const ultimaData = o.jornadasComoOperador.length > 0 ? o.jornadasComoOperador[0].dataInicio : null;
            const diasSemRodar = ultimaData ? Math.floor((hoje.getTime() - ultimaData.getTime()) / 86400000) : 'Nunca rodou';
            return { operador: o.nome, ultimaJornada: ultimaData, diasSemRodar };
        });

        return ociosos.sort((a, b) => {
            if (a.diasSemRodar === 'Nunca rodou') return -1;
            if (b.diasSemRodar === 'Nunca rodou') return 1;
            return (b.diasSemRodar as number) - (a.diasSemRodar as number);
        }).slice(0, 15);
    }
};

// ============================================================================
// 🤖 SERVIÇO PRINCIPAL (ORQUESTRADOR E LOOP AGÊNTICO)
// ============================================================================
export class IAService {

    private checkAvailability() {
        if (!ai) throw new Error('IA indisponível. Verifique GEMINI_API_KEY.');
    }

    private formatarHistorico(h?: { role: string, text: string }[]) {
        return Array.isArray(h) ? h.map(m => ({ role: m.role === 'user' ? 'user' : 'model', parts: [{ text: m.text }] })) : [];
    }

    private async executarFerramenta(nome: string, args: any) {
        console.log(`[KIA-TOOL] ${nome} executada.`);
        try {
            if (nome in apiAgentes) return await (apiAgentes as any)[nome](args);
            return { erro: "Ferramenta inexistente." };
        } catch (e) {
            console.error(`[KIA-TOOL] DB Error (${nome}):`, e);
            return { erro: "Falha de execução SQL." };
        }
    }

    // Método Legacy Síncrono (Mantido para Dashboard Insights)
    public async gerarResposta(pergunta: string, contexto: string, historico?: { role: string, text: string }[]): Promise<string> {
        this.checkAvailability();
        let ultimoErro: any;

        for (const modelName of MODELS_TO_TRY) {
            try {
                const chat = ai!.chats.create({ model: modelName, history: this.formatarHistorico(historico), config: { systemInstruction: SYSTEM_INSTRUCTION } });
                const res = await chat.sendMessage({ message: `[CONTEXTO: ${contexto}]\n\nUser: ${pergunta}` });
                return res.text || '';
            } catch (error) {
                console.warn(`[KIA] Falha síncrona no modelo ${modelName}. Tentando o próximo...`);
                ultimoErro = error;
            }
        }
        
        console.error('[KIA] Falha em todos os modelos:', ultimoErro);
        return 'Erro de processamento após tentar todos os modelos disponíveis.';
    }

    // NOVO MOTOR DE STREAMING COM RACIOCÍNIO CONTÍNUO (MULTI-TOOL LOOP)
    public async gerarRespostaStream(
        pergunta: string,
        contexto: string,
        historico: { role: string, text: string }[] | undefined,
        onData: (chunk: string) => void
    ): Promise<void> {
        this.checkAvailability();
        let ultimoErro: any;

        for (const modelName of MODELS_TO_TRY) {
            try {
                console.log(`[KIA] Inicializando motor de Raciocínio com modelo: ${modelName}`);
                const chat = ai!.chats.create({
                    model: modelName,
                    history: this.formatarHistorico(historico),
                    config: { systemInstruction: SYSTEM_INSTRUCTION, tools: tools }
                });

                const promptFinal = `[Contexto Local da UI: ${contexto}]\n\nPergunta Operacional: ${pergunta}`;
                let mensagemAtual: any = { message: promptFinal };
                const MAX_ITERACOES = 4; // Impede loops infinitos da IA

                for (let iteracao = 0; iteracao < MAX_ITERACOES; iteracao++) {
                    const responseStream = await chat.sendMessageStream(mensagemAtual);
                    let chamadasPendentes: any[] = [];

                    for await (const chunk of responseStream) {
                        if (chunk.functionCalls && chunk.functionCalls.length > 0) {
                            chamadasPendentes.push(...chunk.functionCalls);
                        } else if (chamadasPendentes.length === 0) {
                            // Só escreve na tela se não estiver raciocinando com ferramentas
                            try { if (chunk.text) onData(chunk.text); } catch (e) { /* silent */ }
                        }
                    }

                    // Se a IA não pediu ferramentas, significa que ela formulou a resposta final e acabou o turno.
                    if (chamadasPendentes.length === 0) return;

                    // Execução PARALELA de todas as ferramentas que a KIA pediu
                    console.log(`[KIA] Loop ${iteracao + 1}: Executando ${chamadasPendentes.length} queries em paralelo...`);
                    const resolucoes = await Promise.all(chamadasPendentes.map(fc => this.executarFerramenta(fc.name, fc.args)));

                    // Formatação blindada do novo SDK Google
                    const partesResposta = chamadasPendentes.map((fc, idx) => ({
                        functionResponse: {
                            id: fc.id, // ID obrigatório para amarrar o fluxo
                            name: fc.name,
                            response: { resultado: JSON.parse(JSON.stringify(resolucoes[idx])) } // JSON limpo para não quebrar o Protobuf
                        }
                    }));

                    // Prepara a devolução dos dados para a KIA ler na próxima iteração
                    mensagemAtual = { message: partesResposta };
                }
                return;
            } catch (error: unknown) {
                console.warn(`[KIA] Falha no modelo ${modelName}. Tentando o próximo fallback... Erro:`, (error as Error)?.message || 'Unknown');
                ultimoErro = error;
            }
        }

        console.error('[IAService - Agente] Falha fatal após esgotar Fallbacks:', ultimoErro);
        onData('\n\n⚠️ **Aviso:** Os servidores de IA estão sobre alta demanda no momento e todas as rotas alternativas falharam. Por favor, tente novamente em alguns instantes.');
    }

    public montarContextoFrota(dados: Record<string, unknown>): string { return JSON.stringify(dados, null, 2); }
}

export const iaService = new IAService();