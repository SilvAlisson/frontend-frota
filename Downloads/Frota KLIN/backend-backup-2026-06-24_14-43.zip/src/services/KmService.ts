import { prisma } from '../lib/prisma';
import { Prisma } from '@prisma/client';

export class KmService {

    /**
     * Registra um novo KM no histórico e atualiza o "cache" no cadastro do veículo.
     */
    static async registrarKm(veiculoId: string, km: number, origem: 'JORNADA' | 'ABASTECIMENTO' | 'MANUTENCAO' | 'MANUAL', origemId?: string, tx?: Prisma.TransactionClient) {
        if (!veiculoId || !km) return;

        const db = tx || prisma;

        try {
            // 1. Grava no histórico imutável (Auditoria - Nunca deletamos nada aqui)
            await db.historicoKm.create({
                data: {
                    veiculoId,
                    km,
                    origem,
                    origemId: origemId ?? null,
                    dataLeitura: new Date()
                }
            });

            // 2. Atualiza a "Verdade Oficial" no cadastro do veículo.
            // A inteligência agora está no Controller, que decide quando atualizar isso.
            // Aqui fazemos apenas uma atualização simples se o valor for novo.
            // (A correção pesada de retrocesso é feita pelo JornadaController agora)
            await db.veiculo.update({
                where: { id: veiculoId },
                data: { ultimoKm: km }
            });

        } catch (error) {
            console.error(`[WARN] Falha ao registrar histórico de KM para o veículo ${veiculoId}`, error);
        }
    }

    /**
     * Busca o KM ATUAL REAL do veículo de forma INTELIGENTE.
     * * CORREÇÃO CRÍTICA:
     * Antes usávamos Math.max(), o que impedia a correção de erros de digitação 
     * (um erro de 900.000km ficava "preso" para sempre como o maior valor).
     * * NOVA LÓGICA (Hierarquia de Confiança):
     * 1. Tabela Veículo (A verdade oficial editável pelos gestores)
     * 2. Última Jornada Fechada (Fallback se o veículo estiver zerado)
     */
    static async getUltimoKMRegistrado(veiculoId: string): Promise<number> {
        try {
            // NÍVEL 1: A Fonte da Verdade (Corrigida pelos Controllers)
            const veiculo = await prisma.veiculo.findUnique({
                where: { id: veiculoId },
                select: { ultimoKm: true }
            });

            // Se o veículo tem um KM registrado, confiamos nele (pois foi validado/corrigido na edição de jornada)
            if (veiculo?.ultimoKm && veiculo.ultimoKm > 0) {
                return veiculo.ultimoKm;
            }

            // NÍVEL 2: Fallback Inteligente (Cronológico, não Máximo)
            // Se o veículo está zerado, buscamos a última jornada FECHADA pela data (não pelo maior KM)
            const ultimaJornada = await prisma.jornada.findFirst({
                where: { 
                    veiculoId, 
                    kmFim: { not: null },
                    // Ignora jornadas que foram marcadas como erro ou canceladas (se houver essa flag no futuro)
                },
                orderBy: { dataFim: 'desc' }, // Pega a mais recente no tempo
                select: { kmFim: true }
            });

            if (ultimaJornada?.kmFim) {
                return ultimaJornada.kmFim;
            }

            // Se não achou nada, o veículo é 0km
            return 0;

        } catch (error) {
            console.error(`[CRITICAL] Falha ao validar KM do veículo ${veiculoId}:`, error);
            // Em caso de erro de banco, retorna 0 para não travar a operação
            return 0;
        }
    }
}