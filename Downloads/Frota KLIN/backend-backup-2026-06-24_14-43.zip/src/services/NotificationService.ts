import webpush from 'web-push';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Configuração das VAPID Keys
const publicVapidKey = process.env.VAPID_PUBLIC_KEY || '';
const privateVapidKey = process.env.VAPID_PRIVATE_KEY || '';
const subject = process.env.VAPID_SUBJECT || 'mailto:admin@klinambiental.com.br';

if (publicVapidKey && privateVapidKey) {
  webpush.setVapidDetails(subject, publicVapidKey, privateVapidKey);
} else {
  console.warn("⚠️ VAPID Keys não configuradas. As notificações Push não funcionarão.");
}

export class NotificationService {
  /**
   * Salva a subscription de um dispositivo no banco
   */
  async subscribe(userId: string, subscription: { endpoint: string; keys: { p256dh: string; auth: string; } }) {
    const existing = await prisma.pushSubscription.findUnique({
      where: { endpoint: subscription.endpoint }
    });

    if (existing) {
      // Já existe, só atualiza quem é o dono caso mude
      if (existing.userId !== userId) {
        await prisma.pushSubscription.update({
          where: { endpoint: subscription.endpoint },
          data: { userId }
        });
      }
      return existing;
    }

    return await prisma.pushSubscription.create({
      data: {
        endpoint: subscription.endpoint,
        p256dh: subscription.keys.p256dh,
        auth: subscription.keys.auth,
        userId
      }
    });
  }

  /**
   * Remove a subscription quando o usuário desloga ou revoga
   */
  async unsubscribe(endpoint: string) {
    try {
      await prisma.pushSubscription.delete({
        where: { endpoint }
      });
    } catch (e) {
      // Ignorar se não existir
    }
  }

  /**
   * Envia uma notificação para todos os ADMINS e ENCARREGADOS
   */
  async notifyGestores(title: string, body: string, url: string = '/') {
    // Busca todos os gestores e suas subscriptions
    const gestores = await prisma.user.findMany({
      where: { role: { in: ['ADMIN', 'ENCARREGADO'] } },
      include: { pushSubscriptions: true }
    });

    const payload = JSON.stringify({
      title,
      body,
      url,
      icon: '/icons/icon-192x192.png',
      badge: '/icons/icon-192x192.png'
    });

    for (const admin of gestores) {
      for (const sub of admin.pushSubscriptions) {
        const pushSubscription = {
          endpoint: sub.endpoint,
          keys: {
            p256dh: sub.p256dh,
            auth: sub.auth
          }
        };

        try {
          await webpush.sendNotification(pushSubscription, payload);
          console.log(`✅ Push enviado para Gestor: ${admin.nome} (${admin.email})`);
        } catch (error: unknown) {
          const err = error as Error & { statusCode?: number };
          console.error(`❌ Falha ao enviar Push para ${admin.nome}:`, err.message);
          // Se o erro for 410 (Gone) ou 404, o usuário revogou a permissão no browser
          if (err.statusCode === 410 || err.statusCode === 404) {
            await this.unsubscribe(sub.endpoint);
          }
        }
      }
    }
  }
}
