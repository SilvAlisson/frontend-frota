import { z } from 'zod';

// 1. O Objeto Base Puro
const baseDocumentoSchema = z.object({
    titulo: z.string().min(3, "O título deve ter pelo menos 3 caracteres"),
    descricao: z.string().optional(),
    arquivoUrl: z.url({ message: "URL do arquivo inválida" }), 
    categoria: z.string().default("GERAL").transform(v => v.toUpperCase()),
    dataValidade: z.coerce.date().nullable().optional(),
    tipoVeiculo: z.string().optional().transform(v => v ? v.toUpperCase() : undefined),
    veiculoId: z.string().optional(),
});

type ValidacaoTemporalInput = {
    dataValidade?: Date | null;
};

// 2. Regra de validação temporal isolada e tipada
const validacaoTemporal = (data: ValidacaoTemporalInput) => {
    if (!data.dataValidade) return true;
    const hoje = new Date();
    hoje.setHours(0, 0, 0, 0);
    return data.dataValidade > hoje;
};

const mensagemErroTemporal = { 
    message: "A validade não pode estar no passado ou expirar hoje.", 
    path: ["dataValidade"] 
};

// 3. Aplicação do Refine no Create (Criação)
export const createDocumentoLegalSchema = baseDocumentoSchema
    .refine(validacaoTemporal, mensagemErroTemporal);

// 4. Aplicação do Partial + Refine no Update (Atualização)
export const updateDocumentoLegalSchema = baseDocumentoSchema
    .partial()
    .refine(validacaoTemporal, mensagemErroTemporal);

// 5. Esquema de Renovação
export const renovarDocumentoLegalSchema = z.object({
    titulo: z.string().min(3, "O título deve ter pelo menos 3 caracteres"),
    arquivoUrl: z.url({ message: "URL do arquivo inválida" }),
    dataValidade: z.coerce.date().nullable().optional(),
    descricao: z.string().optional()
}).refine(validacaoTemporal, mensagemErroTemporal);