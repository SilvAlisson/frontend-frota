import { z } from 'zod';

// --- LOGIN ---
export const loginSchema = z.object({
    body: z.object({
        email: z.string({ error: "Email inválido" }).email({ message: "Formato de email inválido" }),
        password: z.string({ error: "Senha obrigatória" }).min(1, { message: "Senha obrigatória" }),
    })
});

// --- REGISTER ---
export const registerUserSchema = z.object({
    body: z.object({
        nome: z.string({ error: "Nome obrigatório" }).min(3, { message: "Mínimo 3 caracteres" }),

        email: z.string({ error: "Email inválido" }).email({ message: "Email inválido" }),

        password: z.string({ error: "Senha obrigatória" })
            .min(6, { message: "Senha muito curta" })
            .regex(/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d@$!%*#?&^_-]{6,}$/, { message: "Senha deve conter pelo menos uma letra e um número" }),

        role: z.enum(['ADMIN', 'ENCARREGADO', 'OPERADOR', 'RH', 'COORDENADOR'], {
            error: "Função inválida"
        }).optional().default('OPERADOR'),

        matricula: z.string().optional().nullable().transform(v => v || null),
        cargoId: z.string().optional().nullable().transform(v => v || null),
        fotoUrl: z.string().optional().nullable().transform(v => v || null),

        cnhNumero: z.string().optional().nullable().transform(v => v || null),
        cnhCategoria: z.string().optional().nullable().transform(v => v || null),

        cnhValidade: z.coerce.date().optional().nullable(),
        dataAdmissao: z.coerce.date().optional().nullable(),
    })
});

export const loginWithTokenSchema = z.object({
    body: z.object({
        loginToken: z.string({ error: "Token obrigatório" }).min(10, { message: "Token inválido" })
    })
});

export const generateTokenSchema = z.object({
    params: z.object({
        id: z.string({ error: "ID do usuário necessário" })
    })
});

// --- 🔐 007 Fix: Schemas para Recuperação de Senha ---
export const forgotPasswordSchema = z.object({
    body: z.object({
        email: z.string({ error: "Email obrigatório" }).email({ message: "Formato de email inválido" }),
    })
});

export const resetPasswordSchema = z.object({
    body: z.object({
        token: z.string({ error: "Token obrigatório" }),
        newPassword: z.string({ error: "Nova senha obrigatória" }).min(8, { message: "Senha deve ter no mínimo 8 caracteres" }),
    })
});