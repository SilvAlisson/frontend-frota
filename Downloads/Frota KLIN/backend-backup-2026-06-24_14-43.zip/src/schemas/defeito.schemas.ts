import { z } from 'zod';

export const registrarDefeitoSchema = z.object({
  body: z.object({
    veiculoId: z.string({ error: 'Veículo obrigatório' }).min(1),
    descricao: z.string({ error: 'Descrição obrigatória' }).min(5, 'A descrição deve ter pelo menos 5 caracteres'),
    categoria: z.enum(['PNEU', 'FREIO', 'MOTOR', 'ILUMINACAO', 'CARROCERIA', 'OLEO', 'OUTRO'], {
      error: 'Categoria inválida',
    }),
    fotoUrl: z.string({ error: 'Foto obrigatória' }).url('A URL da foto é inválida'),
  }),
});

export const resolverDefeitoSchema = z.object({
  body: z.object({
    resolucao: z.string().optional().nullable(), // Observação do encarregado
  }),
});
