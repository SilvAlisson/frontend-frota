import { z } from 'zod';

// Helper para converter string vazia em null (limpeza de dados do input)
const emptyToNull = z.string().optional().nullable().transform(v => v === '' ? null : v);

// --- 1. INICIAR JORNADA (POST) ---
export const iniciarJornadaSchema = z.object({
    body: z.object({
        veiculoId: z.string({ error: "Veículo obrigatório" }).min(1, "Veículo obrigatório"),
        
        // Pode vir como 'encarregadoId' ou 'operadorId' dependendo do payload, 
        // mas no controller geralmente mapeia para o operador da jornada.
        // Se o frontend envia 'operadorId', ajuste aqui ou garanta que o controller leia o certo.
        encarregadoId: z.string().optional(), 
        operadorId: z.string().optional(), 

        kmInicio: z.coerce.number({ error: "KM inválido" })
            .nonnegative("KM deve ser positivo"),

        actionCreatedAt: z.string().or(z.date()).optional(), // OFFLINE PWA

        observacoes: emptyToNull,
        fotoInicioUrl: emptyToNull,
    })
});

// --- 2. FINALIZAR JORNADA (PUT /finalizar/:id) ---
export const finalizarJornadaSchema = z.object({
    params: z.object({
        id: z.string({ error: "ID da jornada obrigatório" })
    }),
    body: z.object({
        kmFim: z.coerce.number({ error: "KM final inválido" })
            .nonnegative("KM deve ser positivo"),

        actionCreatedAt: z.string().or(z.date()).optional(), // OFFLINE PWA

        observacoes: emptyToNull,
        fotoFimUrl: emptyToNull,
    })
});

// --- 3. EDITAR JORNADA (PUT /:id) - NOVO! ---
// Usado pelo FormEditarJornada.tsx que criamos
export const updateJornadaSchema = z.object({
    params: z.object({
        id: z.string({ error: "ID da jornada obrigatório" })
    }),
    body: z.object({
        veiculoId: z.string().optional(),
        operadorId: z.string().optional(),
        
        // Aceita string ISO ou Date
        dataInicio: z.string().or(z.date()).optional(),
        kmInicio: z.coerce.number().nonnegative().optional(),
        
        dataFim: z.string().or(z.date()).nullable().optional(),
        kmFim: z.coerce.number().nullable().optional(),
        
        observacoes: emptyToNull,
        
        // Flag especial para corrigir o KM do veículo ao salvar
        atualizarOdometroVeiculo: z.boolean().optional()
    })
});

// --- 4. BUSCA / HISTÓRICO (GET) ---
export const buscaJornadaSchema = z.object({
    query: z.object({
        dataInicio: z.string().optional(),
        dataFim: z.string().optional(),
        veiculoId: z.string().optional(),
        operadorId: z.string().optional()
    })
});