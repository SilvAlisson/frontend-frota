import { GoogleGenAI } from '@google/genai';
import * as dotenv from 'dotenv';
dotenv.config();

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

async function checkModels() {
    try {
        console.log("Fetching models...");
        // Em @google/genai a listagem costuma ser via getModels ou similar, 
        // mas vamos tentar usar o fetch bruto ou o que estiver na API.
        // O SDK novo costuma expor a propriedade `models` (Models service).
        const response = await ai.models.list();
        for await (const model of response) {
            if (model.name.includes("gemini")) {
                console.log(model.name);
            }
        }
    } catch (e) {
        console.error("Erro listando modelos:", e);
    }
}

checkModels();
